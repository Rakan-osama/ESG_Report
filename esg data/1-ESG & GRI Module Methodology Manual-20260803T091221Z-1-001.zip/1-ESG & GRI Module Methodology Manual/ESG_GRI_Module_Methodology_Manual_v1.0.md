# ESG & GRI MODULE METHODOLOGY MANUAL
## دليل منهجية موديول الاستدامة والإفصاح الرقمي وفق معايير GRI

**Deliverable Reference:** MR-01 (Methodology Requirement 1 of 16)
**Module:** ESG Intelligence & GRI Digital Reporting Module
**Document ID:** EEG-ESG-MET-001
**Version:** 1.0 (Draft for technical approval)
**Prepared by:** ESG/GRI Technical Domain Lead — Extreme Energy Solutions
**Reviewed by:** [Not specified]
**Approved by:** [Not specified]
**Status:** Draft — Not released for development
**Effective date:** [Not specified — effective upon technical sign-off]
**Next review:** Annually, or upon any GRI Standard revision affecting the module

---

## DOCUMENT CONTROL AND AUTHORITY

### 0.1 Purpose of this manual

This manual is the **controlling methodology document** of the module. It defines what the module must do, on what methodological basis, under what rules, and with what constraints. It is the mandatory predecessor to all other deliverables (MR-02 Standards Register, MR-03 Disclosure Master Matrix, MR-04 Data Dictionary, MR-05 Calculation Book, and the remainder of the deliverable set).

No database schema, screen, workflow, validation rule, or report template may be built before this manual is technically approved.

### 0.2 Order of precedence

Where a conflict arises, the following order applies:

| Rank | Source | Notes |
|---|---|---|
| 1 | Applicable law and regulatory reporting obligations of the reporting organization | Local disclosure law, listing rules, CBAM/CSRD or equivalent where applicable |
| 2 | The official text of the applicable GRI Standards (current effective versions) | GRI 1: Foundation 2021, GRI 2: General Disclosures 2021, GRI 3: Material Topics 2021, applicable Sector Standards, applicable Topic Standards |
| 3 | This Methodology Manual (MR-01) | Binding methodological interpretation |
| 4 | MR-02 to MR-16 (registers, matrices, dictionaries, templates) | Must be consistent with MR-01 |
| 5 | System design, UI/UX, and technical implementation decisions | Must not alter methodology |

### 0.3 Division of responsibility

| Role | Responsible for | Not responsible for |
|---|---|---|
| ESG/GRI Technical Domain Lead | Interpretation of GRI requirements, applicability rules, materiality methodology, indicator definitions, formulas, validation logic content, output content, bilingual terminology, technical acceptance | Software architecture, coding, infrastructure |
| Software Development Lead | Data model, workflow engine, permissions, audit trail, performance, security, exports | Interpreting or inventing ESG/GRI requirements |

**Rule:** the developer shall not interpret a GRI requirement. Any requirement not defined in MR-01 to MR-16 is a **methodology gap** to be raised as a formal query to the ESG/GRI Technical Domain Lead and resolved in writing before implementation.

### 0.4 Copyright and licensing constraint (binding design constraint)

GRI Standards content is copyright-protected. The module shall be designed so that GRI-protected text (disclosure wording, requirements text, guidance text) is stored in a **separately controlled content layer**, not hard-coded into screens or code, so that it can be:

- restricted, redacted, or replaced by reference (standard code + disclosure number + official link) at deployment level;
- switched between "internal use" mode and "licensed commercial" mode;
- fully removed if a licence is not obtained.

Commercial distribution of the module with embedded GRI content requires prior clearance under GRI's licensing arrangements. No unofficial Arabic translation of GRI text shall be published as if it were an official GRI translation.

---

## 1. OBJECTIVE OF THE MODULE

### 1.1 Primary objective

To convert sustainability reporting from a fragmented spreadsheet-and-email exercise into a controlled digital process that produces **auditable, traceable, and assurance-ready** sustainability information, and a GRI content index and report that can withstand external assurance.

### 1.2 Functional objectives

The module shall:

1. Define the reporting organization, its legal entities, sites, and reporting period.
2. Maintain a versioned library of GRI Standards and their applicability rules.
3. Execute and document the material topic determination process in line with GRI 3.
4. Generate, assign, and track data requests to accountable owners.
5. Capture quantitative and qualitative data with units, periods, boundaries, and evidence.
6. Apply defined validation rules before data can progress.
7. Route data through defined review and approval stages with segregation of duties.
8. Record reasons for omission with justification and approval.
9. Measure completeness, evidence coverage, and data quality.
10. Produce gap analysis, materiality report, GRI content index, report content, dashboards, and an audit/assurance pack.
11. Maintain an immutable audit trail and controlled restatement process.
12. Support Arabic and English content, and future structured export (taxonomy tagging, XBRL/iXBRL).

### 1.3 Explicit non-objectives

The module does **not**:

- issue any certification, rating, score, or endorsement of GRI conformance;
- replace external assurance or perform an assurance conclusion;
- replace professional judgement of the reporting organization's management or its highest governance body;
- calculate a GHG inventory in place of a dedicated ISO 14064-1:2018 / GHG Protocol inventory process — where GHG figures are used, the module consumes and controls them, and requires the underlying inventory methodology and evidence to be attached.

### 1.4 Prohibited system outputs (hard constraint)

The module shall never generate, display, print, or export any of the following, in any language:

- "GRI Certified", "GRI Approved", "GRI Compliance Certificate", "GRI Score", "GRI Rating", "GRI Audited";
- any use of the GRI name or logo implying endorsement, certification, or verification of the organization's report;
- any statement of conformance to GRI that is not the exact statement of use permitted by GRI 1.

GRI does not certify, verify, or approve reports. Any internal scoring produced by the module shall be labelled as an internal readiness/quality indicator of the reporting organization, not a GRI outcome (see §9 of the project brief and Annex D).

---

## 2. REPORTING TYPES SUPPORTED BY THE MODULE

The module supports exactly two claim routes defined by GRI 1: Foundation 2021, plus a third internal state.

| Route | System code | Basis | Claim permitted |
|---|---|---|---|
| Reporting **in accordance with** the GRI Standards | `IN_ACCORDANCE` | All nine requirements of GRI 1 Section 3 satisfied | Full statement of use |
| Reporting **with reference to** the GRI Standards | `WITH_REFERENCE` | Content index published, statement of use provided, GRI notified | Limited statement of use |
| Internal ESG data collection / readiness only | `INTERNAL_ONLY` | Not a GRI claim | No GRI claim of any kind |

### 2.1 The nine requirements and their system controls

To report in accordance with the GRI Standards, an organization must comply with **all nine** requirements in Section 3 of GRI 1: Foundation 2021; failure on any one of them removes the right to the "in accordance" claim, in which case the "with reference" route may still be available.

| # | GRI 1 requirement | System control implemented by the module | Blocking rule |
|---|---|---|---|
| R1 | Apply the reporting principles (accuracy, balance, clarity, comparability, completeness, sustainability context, timeliness, verifiability) | Principle attestation checklist per reporting cycle, each item linked to system evidence (validation pass rate, prior-period comparatives, evidence coverage, period dates, review completion) | Cycle cannot be closed with unattested principles |
| R2 | Report all disclosures in GRI 2: General Disclosures 2021 | GRI 2 disclosure set auto-generated for every cycle; each disclosure must reach `Approved`, `Published`, or a valid `Omitted` state | Any GRI 2 disclosure in `Not Started` / `In Progress` blocks the claim |
| R3 | Determine material topics in line with GRI 3 | Materiality engine must contain a completed, approved assessment version linked to the cycle | No approved materiality version → claim blocked |
| R4 | Report disclosures 3-1, 3-2 and 3-3 of GRI 3 | 3-1 (process) and 3-2 (list) at cycle level; 3-3 mandatory per material topic | Any material topic without an approved 3-3 blocks the claim |
| R5 | Report Topic Standard disclosures for each material topic | Topic Standard mapping mandatory per material topic; where no GRI Topic Standard exists, the organization reports its own management information and this must be documented | Unmapped material topic blocks the claim |
| R6 | Provide reasons for omission where a disclosure or requirement cannot be complied with | Omission object with reason, explanation, approver, date; omission not permitted where GRI prohibits it (Annex C) | Invalid or unapproved omission blocks the claim |
| R7 | Publish a GRI content index | Content index generated from system data only, containing all mandatory elements | Incomplete index blocks publication as "in accordance" |
| R8 | Provide a statement of use | Statement generated from controlled template with organization legal name and exact period dates | Free-text editing of the statement is prohibited |
| R9 | Notify GRI of the use of the GRI Standards and the statement of use | Notification task, recipient, date sent, evidence of notification stored | Cycle cannot be marked `Published (in accordance)` without notification evidence |

### 2.2 Reporting with reference to the GRI Standards

The "with reference" route requires the organization to publish a GRI content index, provide the applicable statement of use, and notify GRI. It does **not** entitle the organization to the "in accordance" statement.

System rules:

1. The module shall still enforce evidence, review, and validation controls on all reported disclosures, regardless of route.
2. Selected disclosures must be reported in full; partial reporting of a disclosure without a reason for omission is not permitted in the content index.
3. The module shall not display any wording suggesting the report is "in accordance" anywhere in the report body, index, dashboard, or export.

### 2.3 Claim engine — computed, never selected

The reporting route shall be **computed by the system**, not chosen by the user. The user may declare a *target* route at cycle setup (`target_claim`), but the *effective* route (`effective_claim`) is derived from the requirement checks in §2.1.

```
IF all_nine_requirements_passed = TRUE
    THEN effective_claim = IN_ACCORDANCE
ELSE IF content_index_complete AND statement_of_use_present AND gri_notified
    THEN effective_claim = WITH_REFERENCE
ELSE effective_claim = INTERNAL_ONLY
```

The system shall display, at all times, a **claim eligibility panel** listing each of the nine requirements with status (Met / Not met / Not applicable) and the specific blocking items. Failure reasons must be actionable (disclosure code, topic, entity, owner).

### 2.4 Statement of use

The statement of use shall be produced from a locked template with only three variable fields: legal name of the organization, period start date, period end date, and the GRI 1 version used. Users may not edit the wording. Both routes have distinct templates and shall not be interchangeable.

---

## 3. DISTINCTION BETWEEN THE FIVE CORE CONCEPTS

The module treats these as **five different objects with different lifecycles**. Conflating them is the most common cause of unusable ESG software.

| Concept | Question answered | Primary driver | Typical output | Performed by | Independence required | System object |
|---|---|---|---|---|---|---|
| **ESG assessment** | Where does the organization stand against a chosen ESG framework, rating logic, or client requirement? | Internal decision-making, investor/lender request, gap identification | ESG gap report, scorecard, improvement plan | Advisory team or internal ESG function | No | `esg_assessments` |
| **Sustainability reporting** | What are the organization's most significant impacts, and how are they managed? | GRI Standards requirements and disclosure obligations | Sustainability report, GRI content index, disclosures | Reporting organization (supported by advisory) | No | `esg_reporting_cycles` |
| **Materiality assessment** | Which topics represent the organization's most significant impacts on the economy, environment and people, including human rights? | GRI 3 process | Impact register, material topic list, threshold decision, approvals | Reporting organization with stakeholder input | No | `esg_material_topics`, `esg_impacts` |
| **ESG maturity assessment** | How capable is the organization's ESG management system (policy, responsibility, targets, controls, monitoring)? | Internal management development | Maturity level per dimension, roadmap | Advisory or internal | No | `esg_maturity_assessments` |
| **External assurance** | Is the reported information free from material misstatement against stated criteria, at limited or reasonable assurance? | Assurance engagement standard and agreed criteria | Assurance statement / conclusion issued by the assurance provider | Independent, impartial, competent assurance provider | **Yes — mandatory** | `esg_assurance_engagements`, `esg_assurance_findings` |

### 3.1 Methodological consequences for the module

1. A **material topic** is not a data point and not a KPI. It is a management object with impacts, policies, actions, targets, and results (GRI 3-3).
2. An **ESG assessment score** is never a GRI outcome and shall never be displayed inside GRI reporting outputs.
3. **Maturity** measures management capability; **completeness** measures disclosure coverage. They are separate scores and must never be summed or averaged together.
4. **Assurance** is a separate engagement over selected information. The module records assurance scope, criteria, level, provider, findings and status — it does not generate an assurance conclusion.

### 3.2 Impartiality and separation rule (binding)

The module shall enforce, by design:

- **Separate roles** for preparation (data owner, contributor, ESG reviewer) and assurance (assurance provider).
- **Read-only access** for the assurance provider over in-scope data, evidence, and audit trail; the assurance provider shall never be able to create, edit, approve, or delete client data. Findings are recorded as a separate object and answered by the client.
- **Entity-level segregation**: where an advisory entity prepares the report, the assurance/verification of the same information shall be performed by a separate impartial and competent body with no conflict of interest. The system shall record the identity of the preparing party and the assuring party and flag any case where they belong to the same legal entity or the same personnel.
- **System Administrator** privileges do not carry ESG technical approval authority. Administrative rights and methodological approval rights shall be separate permission sets.

---

## 4. ESG PROJECT LIFECYCLE — END TO END

Nine phases, each with entry criteria, exit criteria, and a system gate. The system shall prevent progression when exit criteria are not met.

| Phase | Name | Key activities | Exit criteria (system gate) |
|---|---|---|---|
| **P0** | Engagement setup | Client, scope of services, roles, confidentiality, route target | Client, cycle, and role assignments created; target claim declared |
| **P1** | Reporting boundary definition | Legal entities, sites, consolidation approach, period, value chain map | Boundary approved and locked for the cycle (§5) |
| **P2** | Standards applicability | GRI 1/2/3 versions, applicable Sector Standards, candidate Topic Standards | Applicable standards set approved; version IDs recorded |
| **P3** | Context and stakeholder analysis | Activities, geographies, value chain, stakeholder mapping and engagement | Stakeholder register and engagement records complete |
| **P4** | Impact identification and assessment | Impact register, severity and likelihood assessment, evidence | All impacts scored with documented basis |
| **P5** | Material topic determination and approval | Prioritization, threshold, sector reconciliation, governance approval | Material topic list approved and versioned (§6) |
| **P6** | Data planning and collection | Disclosure mapping, data requests, owners, deadlines, data entry, evidence upload | All in-scope disclosures at `Submitted` or valid `Omission Requested` |
| **P7** | Validation, review and internal approval | Automated validation, department review, ESG technical review, management approval | All in-scope disclosures `Approved` or `Omitted (approved)` |
| **P8** | External assurance (if engaged) | Scope agreement, evidence access, findings, resolution | All findings closed or formally accepted; assurance status recorded |
| **P9** | Reporting, approval and publication | Content index, report build, governance approval, GRI notification, period lock | Cycle `Published`; period locked; restatement channel opened |

Restatement (§10) is not a phase; it is a controlled re-opening of a locked period.

---

## 5. REPORTING BOUNDARY METHODOLOGY

### 5.1 Definitions to be configured per cycle

| Element | Requirement | System field |
|---|---|---|
| Reporting organization | Legal name as registered | `organization.legal_name` |
| Entities included | All entities included in the sustainability reporting, and any differences versus financial reporting entities (GRI 2-2) | `esg_legal_entities`, `included_flag`, `difference_vs_financial_reporting` |
| Consolidation approach | Control / financial control / operational control / equity share — declared once, applied consistently | `boundary.consolidation_basis` |
| Sites | Each operational location with country, activity type, ownership, start/end of inclusion | `esg_sites` |
| Reporting period | Start and end dates; alignment with financial reporting period; publication frequency (GRI 2-3) | `reporting_cycle.period_start/end` |
| Value chain coverage | Upstream / own operations / downstream coverage per topic | `boundary.value_chain_scope` |
| Exclusions | Any excluded entity/site with documented reason and approval | `boundary_exclusions` |

### 5.2 Rules

1. The boundary is **approved and locked before data collection begins**. Any change after lock requires a boundary change record with reason, approver, date, and an automatic impact assessment on already-collected data.
2. The consolidation basis shall be applied consistently across all quantitative indicators. Where an indicator uses a different basis (e.g. GHG operational control versus headcount legal entity), this shall be declared at indicator level in the Data Dictionary (MR-04).
3. Entities acquired or disposed of during the period shall be recorded with inclusion dates; partial-period data shall be flagged and the treatment documented.
4. Where GHG data is reported, the organizational and operational boundaries shall be consistent with the underlying inventory prepared under ISO 14064-1:2018 and/or the GHG Protocol Corporate Standard, and the inventory boundary documentation shall be attached as evidence.
5. Differences between the sustainability reporting boundary and the financial reporting boundary shall be explained (GRI 2-2) and are a mandatory content-index element.

---

## 6. MATERIALITY DETERMINATION METHODOLOGY

The module implements the four-step process of GRI 3: Material Topics 2021: (1) understand the organization's context; (2) identify actual and potential impacts; (3) assess the significance of the impacts; (4) prioritize the most significant impacts for reporting.

**Impact materiality only.** GRI materiality is determined by significance of impacts on the economy, environment and people, including human rights — not by financial effect on the organization. Financial materiality may be recorded as an optional attribute for double-materiality alignment (ESRS/ISSB), but it shall never drive the GRI material topic decision.

### 6.1 Step 1 — Context

Mandatory captured elements: activities, products and services, business relationships, value chain map, geographies and countries of operation, sites, workforce composition, affected communities, regulatory environment, sector context, prior-period topics, and relevant Sector Standards.

### 6.2 Step 2 — Impact identification

Each impact is a record, not a topic. Minimum fields:

| Field | Values |
|---|---|
| Impact description | Free text (specific, not topic-level) |
| Nature | Actual / Potential |
| Direction | Positive / Negative |
| Involvement | Caused by / Contributed to / Directly linked through business relationships |
| Value chain location | Upstream / Own operations / Downstream |
| Affected stakeholders | Link to stakeholder groups |
| Human rights impact | Yes / No; if yes, right(s) affected |
| Duration and reversibility | Short / Medium / Long term; Reversible / Difficult to remediate / Irremediable |
| Source of identification | Stakeholder engagement / grievance / audit / regulator / media / sector standard / expert input |
| Evidence | Document reference (mandatory) |
| Impact owner | Internal accountable function |

**Rule:** an impact without a documented source and evidence reference cannot be scored.

### 6.3 Step 3 — Significance assessment

Severity is assessed on three dimensions; likelihood applies to potential impacts only.

| Dimension | Scale | Anchors (to be finalized per client sector) |
|---|---|---|
| Scale (how grave) | 1–5 | 1 = negligible; 3 = significant harm/benefit to affected parties; 5 = severe, life-altering or irreversible harm |
| Scope (how widespread) | 1–5 | 1 = few individuals/limited area; 3 = a defined group/site catchment; 5 = widespread, multiple communities/regions |
| Irremediable character (negative impacts only) | 1–5 | 1 = fully and quickly remediable; 3 = remediable with significant cost/time; 5 = cannot be remediated |
| Likelihood (potential impacts only) | 1–5 | 1 = rare; 3 = possible within the reporting horizon; 5 = expected/recurring |

Computation rules:

```
Severity (negative, actual)    = (Scale + Scope + Irremediability) / 3
Severity (negative, potential) = ((Scale + Scope + Irremediability) / 3) × Likelihood_factor
Significance (positive)        = (Scale + Scope) / 2  [× Likelihood_factor if potential]
```

`Likelihood_factor` is a configurable mapping (e.g. 1→0.2, 2→0.4, 3→0.6, 4→0.8, 5→1.0) and shall be documented per cycle.

**Human rights override (mandatory rule):** for potential negative human rights impacts, severity takes precedence over likelihood. An impact scoring severity ≥ 4 on human rights shall be automatically flagged as candidate-material regardless of likelihood, and can only be excluded by explicit documented justification approved at governance level.

### 6.4 Step 4 — Prioritization and threshold

1. Impacts are ranked by significance score and grouped into candidate topics.
2. A **materiality threshold** is set per cycle and documented (fixed score cut-off, top-N, or natural break). The chosen method and rationale are mandatory fields.
3. **Sector Standard reconciliation (mandatory):** every likely material topic listed in an applicable Sector Standard must be explicitly marked as material, or not material with a documented reason. Unaddressed sector topics are a validation error.
4. **Prior-period comparison:** every topic material in the previous cycle must be carried forward as material, or explicitly de-listed with documented reason (comparability under GRI 1 reporting principles).
5. Aggregation of impacts into topics must be traceable: each material topic must be linked to at least one scored impact.

### 6.5 Approval and versioning

| Step | Role | System control |
|---|---|---|
| Prepare impact register and scoring | ESG Programme Manager | Draft state |
| Technical review | ESG Technical Reviewer | Review state, comments recorded |
| Management review | Executive Approver | Changes recorded with justification |
| Governance approval | Highest governance body (or delegated committee) | Approval date, approver, meeting reference stored as evidence |

The approved material topic list is **versioned and immutable**. Changes create a new version with a change log. The cycle references a specific materiality version ID.

### 6.6 Prohibited practice (explicit)

The module shall not permit a materiality determination based solely on an averaged stakeholder survey score. The stakeholder survey is one input. The following are also required and shall be enforced as mandatory inputs before an assessment can be approved: impact analysis, value chain analysis, sector standard review, human rights consideration, and documented management/governance decision. A survey-only assessment shall be rejected by validation.

---

## 7. DATA COLLECTION AND VERIFICATION METHODOLOGY

### 7.1 Data request generation

Data requests are generated from the intersection of: applicable disclosures × boundary (entities/sites) × repetition rules × reporting period. Each request carries: disclosure ID, requested value definition, unit, period, entity/site, evidence requirement, data owner, contributor, due date, and review chain.

### 7.2 Evidence hierarchy

| Rank | Evidence type | Data quality implication |
|---|---|---|
| 1 | Primary metered/measured records (invoices, meter readings, payroll systems, HR systems, laboratory reports) | Highest |
| 2 | Verified internal system reports (ERP extracts, signed management reports) | High |
| 3 | Third-party statements not independently verified | Medium |
| 4 | Documented estimates based on approved methodology | Low — must be flagged (§9) |
| 5 | Undocumented estimates or verbal confirmation | **Not acceptable** — cannot be submitted |

Every quantitative datapoint in assurance scope shall have at least one evidence record with: document type, issuer, period covered, entity/site coverage, upload date, uploader, and version.

### 7.3 Review model — segregation of duties

Minimum three-stage review, with a **four-eyes rule**: the person who entered a datapoint may not approve it.

| Stage | Performed by | Checks |
|---|---|---|
| Stage 1 — Departmental review | Department Reviewer | Correctness of source, completeness of coverage, arithmetic, evidence attached |
| Stage 2 — ESG technical review | ESG Technical Reviewer | Conformance with GRI requirement, unit and boundary correctness, methodology consistency, comparability with prior period, adequacy of narrative |
| Stage 3 — Management approval | Executive Approver / Data Owner | Accountability for the reported figure |

### 7.4 Validation gate order

Automated validation runs before a datapoint can move from `In Progress` to `Submitted`, and again before `Approved`:

1. Mandatory field completeness
2. Data type, unit, and range checks
3. Internal consistency (components vs totals, percentages ≤ 100%)
4. Cross-disclosure consistency
5. Period and boundary coverage checks
6. Evidence presence and validity checks
7. Year-on-year variance checks against configured thresholds
8. Duplicate detection

Rules that block progression are `HARD`; rules that require explanation are `SOFT`. Every SOFT rule override requires a written justification and is recorded in the audit trail. The full rule catalogue is delivered as MR-11.

### 7.5 Data quality rating

Each datapoint receives a quality rating built from six dimensions (completeness, accuracy, consistency, timeliness, traceability, verifiability). The rating drives dashboard reporting and assurance scoping (Annex D). It is an internal indicator and shall never be labelled as a GRI result.

### 7.6 Traceability requirement

For any reported figure, the system shall be able to reproduce, in one view: the value, the formula applied, the input values, the units and conversion factors, the entity/site coverage, the evidence, the person who entered it, the reviewers, the approvers, all edits with timestamps, and any restatement history. This is the minimum condition for the module to be described as assurance-ready.

---

## 8. TREATMENT OF DATA GAPS

### 8.1 Decision sequence (mandatory order)

```
1. Is the data available from a primary source?           → collect it
2. Is it available for part of the boundary/period?       → collect partial + disclose coverage %
3. Can it be reliably estimated using an approved method? → estimate per §9 + flag as estimated
4. None of the above                                       → reason for omission per §8.2
```

Progression to steps 3 and 4 requires documented justification. The system shall record the attempted steps.

### 8.2 Reasons for omission

Only the reasons permitted by GRI 1 may be used:

| Code | Reason | Mandatory accompanying explanation |
|---|---|---|
| `NOT_APPLICABLE` | Not applicable | Why the disclosure or requirement is not applicable |
| `LEGAL_PROHIBITION` | Legal prohibitions | The specific legal prohibition |
| `CONFIDENTIALITY` | Confidentiality constraints | The specific confidentiality constraint |
| `INFO_UNAVAILABLE` | Information unavailable / incomplete | The specific information that is missing, the steps being taken, and the expected timeframe for availability |

Rules:

1. Reasons for omission are **not permitted** for the disclosures GRI 1 excludes from omission (see Annex C). The system shall block omission on those disclosures entirely.
2. `INFO_UNAVAILABLE` requires a linked remediation action with owner and target date, and shall be carried forward to the next cycle as an open item.
3. Every omission requires: reason code, explanation text, requester, approver, approval date. Unapproved omissions are treated as incomplete for claim eligibility.
4. Omissions must appear in the GRI content index exactly as approved; the index shall be generated from omission records, never typed manually.
5. Excessive omission is a reporting-quality risk: the system shall display omission count and share per standard, and shall warn where omissions materially undermine completeness.

---

## 9. ESTIMATES AND ASSUMPTIONS

### 9.1 Estimation hierarchy

| Rank | Method | Example |
|---|---|---|
| 1 | Pro-rata from measured partial data | 10 of 12 months metered → extrapolate 2 months |
| 2 | Activity-based calculation using documented factors | Fuel litres × published emission factor |
| 3 | Benchmark/proxy from comparable site or period | Comparable site intensity applied to a similar site |
| 4 | Supplier/third-party average data | Sector average factor |
| 5 | Expert judgement | Only with documented reasoning and approval |

### 9.2 Mandatory documentation per estimate

Method used, rationale for selection, source of factors or proxies (with full reference and year), assumptions, calculation shown, coverage share of the estimated portion, uncertainty rating (Low / Medium / High), preparer, reviewer, approver.

### 9.3 Rules

1. Every estimated value carries a persistent `is_estimated = TRUE` flag that follows it into every output, dashboard, index and export.
2. Where the estimated portion of an indicator exceeds a configurable threshold (default 20% of the reported value), a narrative disclosure of the estimation approach is mandatory.
3. Assumptions shall be re-tested each cycle. An assumption reused from a previous cycle without review is a validation warning.
4. Estimation factors are held in a versioned reference table with source and validity period — never hard-coded and never edited in place.
5. Replacement of an estimate by actual data in a later cycle triggers assessment of a possible restatement (§10).

---

## 10. RESTATEMENT METHODOLOGY

Restatements of previously reported information, with the reasons and effect, are a disclosure requirement under GRI 2-4. The module treats restatement as a controlled, evidenced, and versioned process.

### 10.1 Triggers

| Trigger | Example |
|---|---|
| Error correction | Calculation, unit, or data entry error identified after publication |
| Methodology change | Change in calculation method, factor set, or consolidation basis |
| Boundary change | Merger, acquisition, disposal, outsourcing, or site reclassification |
| Improved data | Estimate replaced by measured data |
| Definition change | Change to indicator scope or classification |
| Standard change | New GRI version altering the required basis |

### 10.2 Significance thresholds

Restatement is required where the change is material to users. Default configurable thresholds:

- Quantitative: change ≥ 5% of the previously reported value for a material indicator, or cumulative change ≥ 5% of a base year value for GHG indicators (consistent with base-year recalculation practice under the GHG Protocol / ISO 14064-1:2018);
- Qualitative: any change that alters the interpretation of performance, trend, or target progress, regardless of size.

Below-threshold changes shall be logged but need not be restated; the log is retained as evidence of the decision.

### 10.3 Process

1. Raise restatement request (trigger, affected periods, affected indicators, reason).
2. Impact quantification (previous value, revised value, difference, %).
3. Technical review and approval by ESG Technical Reviewer and Executive Approver.
4. System creates a **new version** of the affected period's data. The original published values remain immutable and retrievable.
5. Auto-generation of the GRI 2-4 disclosure content (item restated, reason, effect).
6. Recalculation of dependent indicators, intensities, base years and target progress.
7. Communication of the restatement in the next report and, where significant, in a published correction notice.

**Hard rule:** no user, including administrators, may edit data in a locked published period. Locked-period changes are only possible through a restatement record.

---

## 11. KPI AND TARGET METHODOLOGY

### 11.1 KPI definition rules

Every KPI must exist in the Data Dictionary (MR-04) with: definition, purpose, formula, numerator, denominator, unit, boundary, frequency, data source, owner, base year, and linkage to at least one material topic and one disclosure. A KPI not linked to a material topic shall not appear in GRI reporting outputs.

### 11.2 Target definition fields

| Field | Rule |
|---|---|
| Target statement | Specific and measurable |
| Type | Absolute / Intensity / Qualitative milestone |
| Baseline value and base year | Mandatory; baseline must trace to approved reported data |
| Target value and target year | Mandatory |
| Interim milestones | Recommended for targets beyond 3 years |
| Scope and boundary | Entities/sites covered |
| Basis and rationale | Scientific, regulatory, sectoral, or internal — with reference |
| Owner | Accountable function |
| Approval | Approver and date |
| Status | On track / At risk / Off track / Achieved / Revised / Withdrawn |

### 11.3 Progress calculation

```
Absolute reduction target progress (%) = (Baseline − Current) / (Baseline − Target) × 100
Intensity target progress (%)          = (Baseline_intensity − Current_intensity) / (Baseline_intensity − Target_intensity) × 100
```

Progress calculations shall use approved data only, and shall be automatically re-run after any restatement affecting the baseline or current value.

### 11.4 Rules

1. Targets may not be silently amended. Any change to baseline, target value, or scope creates a new target version with reason, approver, and date, and the previous version remains visible.
2. Where a target is revised or withdrawn, the reason is a mandatory disclosure input.
3. Target progress narrative is linked to GRI 3-3 (effectiveness of actions and lessons learned) for the relevant material topic.
4. Achievement claims require evidence and approval; the system shall not auto-publish "Achieved" without approval.

---

## 12. REPORT APPROVAL METHODOLOGY

### 12.1 Pre-approval checklist (system-enforced)

The cycle cannot enter approval until all of the following are green:

1. Boundary approved and locked.
2. Material topics approved (governance level) and versioned.
3. All in-scope disclosures `Approved` or `Omitted (approved)`.
4. All HARD validation rules passed; all SOFT overrides justified.
5. Evidence coverage above the configured minimum for assurance-scope items.
6. All assurance findings closed or formally accepted.
7. Restatements (if any) documented and disclosed under GRI 2-4.
8. Content index generated and complete.
9. Claim eligibility panel showing the intended route as `Eligible`.

### 12.2 Approval chain

| Level | Role | Approves |
|---|---|---|
| 1 | Data Owner | Accuracy of departmental data |
| 2 | ESG Technical Reviewer | Methodological conformance with GRI |
| 3 | Executive Approver / Management | Content, narrative, targets, disclosures |
| 4 | Highest governance body (or delegated committee) | The reported information, including material topics (GRI 2-14) |

Where the highest governance body does not review and approve the reported information, that fact and the reason shall be disclosed (GRI 2-14). The system shall require an explicit statement either way.

### 12.3 Publication and lock

On publication the system shall: lock the period; freeze all datapoints, evidence, and approvals; generate immutable PDF/Excel outputs; store the content index; record the GRI notification (Requirement 9); and open the restatement channel as the only route for subsequent change.

### 12.4 External assurance interaction

The module records: assurance provider, independence confirmation, assurance level (limited / reasonable), criteria applied, scope of information assured, findings and resolutions, and the assurance statement as an attachment. Disclosure 2-5 (external assurance) shall be populated from these records. The system shall not generate, draft, or infer the assurance conclusion.

### 12.5 Post-publication corrections

Any correction after publication follows §10. Silent replacement of a published file is prohibited; superseded outputs shall be retained and marked as superseded, with the date and reason.

---

## ANNEXES

### Annex A — Claim eligibility rule set (for development)

Each of R1–R9 is implemented as an independent boolean check with an evidence pointer, an owner, and a failure message. The claim panel is recalculated on every state change. No manual override of the claim result is permitted at any permission level.

### Annex B — Disclosure status model

`Not Started` → `Not Applicable` | `Data Requested` → `In Progress` → `Submitted` → `Returned for Correction` (→ `In Progress`) | `Under ESG Review` → `Approved` → `Assurance Review` → `Finding Raised` (→ `In Progress`) → `Closed` → `Published`. Parallel branch: `Omission Requested` → `Omission Approved` / `Omission Rejected`.

Transition rules, permitted roles per transition, and mandatory fields per transition are delivered in MR-09.

### Annex C — Omission prohibition list (to be finalized against GRI 1 text in MR-03)

Reasons for omission are not permitted for the general disclosures covering organizational details, entities included in the sustainability reporting, reporting period/frequency and contact point, restatements of information, and external assurance; nor for the GRI 3 disclosures on the process to determine material topics and the list of material topics. The exact disclosure codes shall be confirmed line-by-line against the effective GRI 1: Foundation 2021 text and locked in the Disclosure Master Matrix (MR-03), and enforced as a hard system rule.

### Annex D — Data quality scoring model

| Dimension | Definition | Scoring basis |
|---|---|---|
| Completeness | All required fields, entities, periods covered | Coverage % |
| Accuracy | Traceable to reliable source, no arithmetic error | Evidence rank + validation results |
| Consistency | Same definition, unit, and boundary as prior periods | Deviation flags |
| Timeliness | Data relates to the reporting period and delivered on time | Date checks |
| Traceability | Full lineage from figure to source document | Evidence completeness |
| Verifiability | Sufficient for a third party to re-perform | Composite of the above |

Ratings are internal indicators. Labels permitted: "Internal Data Quality Rating". Labels prohibited: any use of "GRI".

### Annex E — Prohibited labels and outputs

See §1.4. This list shall be implemented as a blocked-terms check across all report templates, narrative fields, and AI-generated text, in Arabic and English.

### Annex F — Core bilingual glossary (extract; full glossary is MR-16)

| English | العربية | Note |
|---|---|---|
| In accordance with the GRI Standards | وفقًا لمعايير GRI | Only after all nine requirements are met |
| With reference to the GRI Standards | بالرجوع إلى معايير GRI | Limited claim |
| Material topic | موضوع جوهري | Impact-based, not financial materiality |
| Impact | تأثير | On economy, environment and people, including human rights |
| Severity | خطورة التأثير | Scale, scope, irremediable character |
| Reason for omission | سبب الحذف | Four permitted reasons only |
| Statement of use | بيان الاستخدام | Locked template |
| GRI content index | فهرس محتوى GRI | System-generated only |
| Restatement | إعادة عرض البيانات | GRI 2-4 |
| External assurance | التأكيد الخارجي المستقل | Independent provider only |

### Annex G — Standards version watchlist (status as at July 2026)

The module shall treat all of the following as **data, not code**. Version records, effective dates, and supersession links are maintained in the GRI Standards Master Register (MR-02).

| Standard | Status / effective date | Implication for the module |
|---|---|---|
| GRI 1: Foundation 2021 | Effective 1 January 2023 | Basis of the nine requirements and reporting principles |
| GRI 2: General Disclosures 2021 | Effective 1 January 2023 | Mandatory disclosure set for `IN_ACCORDANCE` |
| GRI 3: Material Topics 2021 | Effective 1 January 2023 | Materiality engine basis (3-1, 3-2, 3-3) |
| GRI 101: Biodiversity 2024 | Effective for reports published on or after 1 January 2026; supersedes GRI 304: Biodiversity 2016 | Where biodiversity is material, GRI 101 applies now |
| GRI 102: Climate Change 2025 | Effective 1 January 2027; early adoption encouraged; will supersede GRI 305: Emissions 2016 and GRI 201-2 | Both old and new versions must be supportable in parallel until the effective date |
| GRI 103: Energy 2025 | Effective 1 January 2027; early adoption encouraged; will supersede GRI 302: Energy 2016 | As above |
| Sector Standards | Published: Oil and Gas, Coal, Agriculture/Aquaculture/Fishing, Mining. Reporting sections aligned to the new climate and energy Standards made available from 1 January 2026. Others under development | Sector list must be configurable; never hard-coded |

**Design rule:** every disclosure record must carry a standard version ID and an effective/withdrawn date. A reporting cycle resolves the applicable version by publication date and by any early-adoption election recorded for that cycle. Early adoption is an explicit, evidenced election at cycle level.

### Annex H — Acceptance criteria for this deliverable

This manual is accepted only when it is (a) signed by the ESG/GRI Technical Domain Lead, (b) reviewed against the effective GRI Standards text, (c) accompanied by the completed decision on all `[Not specified]` fields, and (d) referenced consistently by MR-02 through MR-16.

---

## REFERENCES

1. Global Reporting Initiative, *GRI 1: Foundation 2021* (effective 1 January 2023) — Section 3 (nine requirements for reporting in accordance), Section 4 (reporting principles), reasons for omission.
2. Global Reporting Initiative, *GRI 2: General Disclosures 2021* (effective 1 January 2023).
3. Global Reporting Initiative, *GRI 3: Material Topics 2021* (effective 1 January 2023) — four-step process for determining material topics; Disclosures 3-1, 3-2, 3-3.
4. Global Reporting Initiative, *GRI 101: Biodiversity 2024* (effective 1 January 2026).
5. Global Reporting Initiative, *GRI 102: Climate Change 2025* and *GRI 103: Energy 2025* (effective 1 January 2027; early adoption permitted).
6. Global Reporting Initiative, Sector Program and Content Index Template resources.
7. Global Reporting Initiative, Trademarks and Copyright Policy; Software and Tools Licensing Program.
8. ISO 14064-1:2018, *Greenhouse gases — Part 1: Specification with guidance at the organization level for quantification and reporting of greenhouse gas emissions and removals* — where GHG data is consumed by the module.
9. ISO 14064-3:2019, *Greenhouse gases — Part 3: Specification with guidance for the verification and validation of greenhouse gas statements* — where GHG statements are assured.
10. WBCSD/WRI, *GHG Protocol Corporate Accounting and Reporting Standard* (revised edition) — base-year recalculation practice.

---

**END OF DOCUMENT — MR-01 v1.0**
