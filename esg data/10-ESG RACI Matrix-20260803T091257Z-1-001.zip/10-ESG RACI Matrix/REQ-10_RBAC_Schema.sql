-- =====================================================================
-- ESG Intelligence & GRI Digital Reporting Module
-- REQUIREMENT 10 - Roles, Authority & Access Control
-- Reference data model, constraints and seed data
-- Target dialect: PostgreSQL 14+
-- Document ID: ESG-GRI-MOD/REQ-10/SQL   Version 1.0
--
-- SCOPE NOTE: this script covers the access-control layer only. Content
-- tables (esg_datapoints, esg_material_topics, ...) are referenced but
-- defined in the main data model specification.
-- =====================================================================

CREATE SCHEMA IF NOT EXISTS esg;
SET search_path = esg, public;

-- ---------------------------------------------------------------------
-- 1. CONTROLLED VOCABULARIES
-- ---------------------------------------------------------------------
CREATE TYPE role_class      AS ENUM ('governance','programme','content','data','review','assurance','support','system');
CREATE TYPE scope_type      AS ENUM ('organization','legal_entity','site','department','topic','disclosure_set','engagement');
CREATE TYPE assignment_stat AS ENUM ('pending','active','suspended','expired');
CREATE TYPE control_type    AS ENUM ('hard_block','alert','logged_exception','workflow_block');
CREATE TYPE ai_status       AS ENUM ('ai_suggested','human_reviewed','accepted','rejected','modified');
CREATE TYPE session_type    AS ENUM ('normal','break_glass','assurance_read_only');

-- ---------------------------------------------------------------------
-- 2. ROLE REGISTER
-- ---------------------------------------------------------------------
CREATE TABLE esg_roles (
    role_code               VARCHAR(8)  PRIMARY KEY,
    role_name_en            VARCHAR(120) NOT NULL,
    role_name_ar            VARCHAR(120) NOT NULL,
    role_class              role_class   NOT NULL,
    default_scope_type      scope_type   NOT NULL,
    requires_appointment    BOOLEAN      NOT NULL DEFAULT TRUE,
    requires_impartiality   BOOLEAN      NOT NULL DEFAULT FALSE,
    can_approve_content     BOOLEAN      NOT NULL DEFAULT FALSE,
    can_write_client_data   BOOLEAN      NOT NULL DEFAULT FALSE,
    is_delegatable          BOOLEAN      NOT NULL DEFAULT TRUE,
    dual_authorization      BOOLEAN      NOT NULL DEFAULT FALSE,
    mvp                     BOOLEAN      NOT NULL DEFAULT TRUE
);

INSERT INTO esg_roles VALUES
('HGB','Highest Governance Body / Sustainability Committee','أعلى جهة حوكمة / لجنة الاستدامة','governance','organization',TRUE,TRUE,TRUE,FALSE,FALSE,TRUE,TRUE),
('EA' ,'Executive Approver','المعتمد التنفيذي','governance','organization',TRUE,TRUE,TRUE,FALSE,TRUE,TRUE,TRUE),
('EPM','ESG Programme Manager','مدير برنامج الاستدامة','programme','disclosure_set',TRUE,FALSE,FALSE,FALSE,TRUE,FALSE,TRUE),
('ETR','ESG Technical Reviewer','المراجع الفني للاستدامة','review','disclosure_set',TRUE,FALSE,TRUE,FALSE,TRUE,FALSE,TRUE),
('MTO','Material Topic Owner','مالك الموضوع الجوهري','content','topic',TRUE,FALSE,FALSE,TRUE,TRUE,FALSE,TRUE),
('IMO','Impact Owner','مالك التأثير','content','topic',TRUE,FALSE,FALSE,TRUE,TRUE,FALSE,FALSE),
('TGO','Target Owner','مالك الهدف','content','topic',TRUE,FALSE,FALSE,TRUE,TRUE,FALSE,FALSE),
('SEO','Stakeholder Engagement Owner','مالك مشاركة أصحاب المصلحة','content','organization',TRUE,FALSE,FALSE,TRUE,TRUE,FALSE,TRUE),
('DO' ,'Data Owner','مالك البيانات','data','site',TRUE,FALSE,TRUE,TRUE,TRUE,FALSE,TRUE),
('DC' ,'Data Contributor','مُدخل البيانات','data','site',TRUE,FALSE,FALSE,TRUE,TRUE,FALSE,TRUE),
('DR' ,'Department Reviewer','مراجع الإدارة','review','department',TRUE,FALSE,FALSE,FALSE,TRUE,FALSE,TRUE),
('RED','Report Editor','محرر التقرير','content','organization',TRUE,FALSE,FALSE,TRUE,TRUE,FALSE,TRUE),
('TRR','Translation & Terminology Reviewer','مراجع الترجمة والمصطلحات','review','organization',TRUE,FALSE,FALSE,TRUE,TRUE,FALSE,TRUE),
('AIR','AI Output Reviewer','مراجع مخرجات الذكاء الاصطناعي','review','organization',TRUE,FALSE,FALSE,TRUE,TRUE,FALSE,TRUE),
('AC' ,'Assurance Coordinator','منسق التأكيد','assurance','engagement',TRUE,TRUE,FALSE,FALSE,TRUE,FALSE,TRUE),
('EAP','External Assurance Provider','جهة التأكيد الخارجي','assurance','engagement',TRUE,TRUE,FALSE,FALSE,FALSE,FALSE,TRUE),
('SA' ,'System Administrator','مسؤول النظام','system','organization',TRUE,FALSE,FALSE,FALSE,FALSE,TRUE,TRUE),
('OBS','Read-only Observer (Internal Audit)','مراقب بصلاحية قراءة','support','organization',TRUE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE);

-- Design invariant: system and assurance roles never approve ESG content.
ALTER TABLE esg_roles ADD CONSTRAINT ck_role_no_system_approval
    CHECK (NOT (role_class IN ('system','assurance') AND can_approve_content));

-- Design invariant: the assurance provider never writes client data.
ALTER TABLE esg_roles ADD CONSTRAINT ck_eap_read_only
    CHECK (NOT (role_code = 'EAP' AND can_write_client_data));

-- ---------------------------------------------------------------------
-- 3. ROLE ASSIGNMENTS (scope-bound, time-bound, evidenced)
-- ---------------------------------------------------------------------
CREATE TABLE esg_role_assignments (
    assignment_id           BIGSERIAL PRIMARY KEY,
    user_id                 BIGINT      NOT NULL,
    role_code               VARCHAR(8)  NOT NULL REFERENCES esg_roles(role_code),
    scope_type              scope_type  NOT NULL,
    scope_id                BIGINT      NOT NULL,
    reporting_cycle_id      BIGINT      NOT NULL,
    client_org_id           BIGINT      NOT NULL,
    effective_from          DATE        NOT NULL,
    effective_to            DATE,
    is_backup               BOOLEAN     NOT NULL DEFAULT FALSE,
    is_delegated            BOOLEAN     NOT NULL DEFAULT FALSE,
    delegated_by            BIGINT,
    delegation_expiry       DATE,
    appointment_evidence_id BIGINT,
    impartiality_decl_id    BIGINT,
    granted_by              BIGINT      NOT NULL,
    second_authorizer       BIGINT,
    status                  assignment_stat NOT NULL DEFAULT 'pending',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_period       CHECK (effective_to IS NULL OR effective_to >= effective_from),
    CONSTRAINT ck_delegation   CHECK (NOT is_delegated OR (delegated_by IS NOT NULL AND delegation_expiry IS NOT NULL)),
    CONSTRAINT ck_no_self_grant CHECK (granted_by <> user_id),
    CONSTRAINT uq_assignment   UNIQUE (user_id, role_code, scope_type, scope_id, reporting_cycle_id, effective_from)
);

CREATE INDEX ix_assign_lookup ON esg_role_assignments (reporting_cycle_id, role_code, status);
CREATE INDEX ix_assign_user   ON esg_role_assignments (user_id, status);

-- SOD-02 / FLD-19: privileged roles require a distinct second authorizer,
-- and appointment evidence must exist before activation.
CREATE OR REPLACE FUNCTION fn_assignment_guard() RETURNS TRIGGER AS $$
DECLARE r RECORD;
BEGIN
    SELECT * INTO r FROM esg_roles WHERE role_code = NEW.role_code;

    IF r.dual_authorization AND (NEW.second_authorizer IS NULL
        OR NEW.second_authorizer = NEW.granted_by
        OR NEW.second_authorizer = NEW.user_id) THEN
        RAISE EXCEPTION 'SOD-02/FLD-19: role % requires a distinct second authorizer', NEW.role_code;
    END IF;

    IF r.requires_appointment AND NEW.status = 'active' AND NEW.appointment_evidence_id IS NULL THEN
        RAISE EXCEPTION 'P5: appointment evidence is mandatory before activating role %', NEW.role_code;
    END IF;

    IF r.requires_impartiality AND NEW.status = 'active' AND NEW.impartiality_decl_id IS NULL THEN
        RAISE EXCEPTION 'SOD-04: impartiality declaration is mandatory before activating role %', NEW.role_code;
    END IF;

    IF NOT r.is_delegatable AND NEW.is_delegated THEN
        RAISE EXCEPTION 'DEL-03: role % may not be delegated', NEW.role_code;
    END IF;

    -- DEL-05: delegation chain depth limited to one level
    IF NEW.is_delegated AND EXISTS (
        SELECT 1 FROM esg_role_assignments d
        WHERE d.user_id = NEW.delegated_by
          AND d.role_code = NEW.role_code
          AND d.reporting_cycle_id = NEW.reporting_cycle_id
          AND d.is_delegated AND d.status = 'active') THEN
        RAISE EXCEPTION 'DEL-05: delegation chain depth exceeds one level';
    END IF;

    -- SOD-04: preparation and assurance may not coexist for the same client and cycle
    IF NEW.role_code IN ('EAP','AC') AND EXISTS (
        SELECT 1 FROM esg_role_assignments a
        JOIN esg_roles ro ON ro.role_code = a.role_code
        WHERE a.user_id = NEW.user_id
          AND a.client_org_id = NEW.client_org_id
          AND a.reporting_cycle_id = NEW.reporting_cycle_id
          AND a.status = 'active'
          AND ro.role_class IN ('content','data','programme','review')) THEN
        RAISE EXCEPTION 'SOD-04: conflict of interest - preparation role held for the same client and cycle';
    END IF;

    IF NEW.role_code IN ('DC','DR','DO','ETR','MTO','EPM','RED') AND EXISTS (
        SELECT 1 FROM esg_role_assignments a
        WHERE a.user_id = NEW.user_id
          AND a.client_org_id = NEW.client_org_id
          AND a.reporting_cycle_id = NEW.reporting_cycle_id
          AND a.role_code IN ('EAP','AC')
          AND a.status = 'active') THEN
        RAISE EXCEPTION 'SOD-04: conflict of interest - assurance role held for the same client and cycle';
    END IF;

    -- SOD-13: conflicting review chain roles on the same scope
    IF NEW.role_code IN ('DC','DR','DO','ETR') AND EXISTS (
        SELECT 1 FROM esg_role_assignments a
        WHERE a.user_id = NEW.user_id
          AND a.scope_type = NEW.scope_type AND a.scope_id = NEW.scope_id
          AND a.reporting_cycle_id = NEW.reporting_cycle_id
          AND a.role_code IN ('DC','DR','DO','ETR')
          AND a.role_code <> NEW.role_code
          AND a.status = 'active') THEN
        RAISE EXCEPTION 'SOD-13: conflicting role already held on this scope';
    END IF;

    RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER tr_assignment_guard
    BEFORE INSERT OR UPDATE ON esg_role_assignments
    FOR EACH ROW EXECUTE FUNCTION fn_assignment_guard();

-- DEL-02: expiry reverts authority automatically (scheduled job calls this)
CREATE OR REPLACE FUNCTION fn_expire_delegations() RETURNS INTEGER AS $$
DECLARE n INTEGER;
BEGIN
    UPDATE esg_role_assignments
       SET status = 'expired'
     WHERE is_delegated AND status = 'active' AND delegation_expiry < CURRENT_DATE;
    GET DIAGNOSTICS n = ROW_COUNT;
    RETURN n;
END; $$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- 4. PERMISSION MATRIX (sheet 03 loaded as data, never as code)
-- ---------------------------------------------------------------------
CREATE TABLE esg_object_registry (
    object_name   VARCHAR(64) PRIMARY KEY,
    data_class    VARCHAR(20) NOT NULL,   -- master | library | content | process | reporting | assurance | system
    soft_delete   BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE esg_permissions (
    role_code     VARCHAR(8)  NOT NULL REFERENCES esg_roles(role_code),
    object_name   VARCHAR(64) NOT NULL REFERENCES esg_object_registry(object_name),
    can_create    BOOLEAN NOT NULL DEFAULT FALSE,
    can_read      BOOLEAN NOT NULL DEFAULT FALSE,
    can_update    BOOLEAN NOT NULL DEFAULT FALSE,
    can_delete    BOOLEAN NOT NULL DEFAULT FALSE,
    can_approve   BOOLEAN NOT NULL DEFAULT FALSE,
    scope_limited BOOLEAN NOT NULL DEFAULT FALSE,   -- R* in the matrix
    technical_only BOOLEAN NOT NULL DEFAULT FALSE,  -- load only, activation needs ETR
    notes         TEXT,
    PRIMARY KEY (role_code, object_name)
);

-- Hard invariant: the administrator never approves, and never touches content objects.
CREATE OR REPLACE FUNCTION fn_permission_guard() RETURNS TRIGGER AS $$
DECLARE cls VARCHAR(20);
BEGIN
    SELECT data_class INTO cls FROM esg_object_registry WHERE object_name = NEW.object_name;

    IF NEW.role_code = 'SA' AND NEW.can_approve THEN
        RAISE EXCEPTION 'SOD-02: System Administrator may not hold approval rights';
    END IF;

    IF NEW.role_code = 'SA' AND cls IN ('content','reporting','assurance')
       AND (NEW.can_create OR NEW.can_update OR NEW.can_delete) THEN
        RAISE EXCEPTION 'SOD-02: System Administrator may not write to content objects';
    END IF;

    IF NEW.role_code = 'EAP'
       AND NEW.object_name NOT IN ('esg_assurance_findings','esg_impartiality_declarations')
       AND (NEW.can_create OR NEW.can_update OR NEW.can_delete OR NEW.can_approve) THEN
        RAISE EXCEPTION 'SOD-03: assurance provider is read-only on client data';
    END IF;

    IF NEW.object_name = 'esg_audit_log' AND (NEW.can_update OR NEW.can_delete) THEN
        RAISE EXCEPTION 'FLD-21: the audit log is append-only for every role';
    END IF;

    IF NEW.role_code IN ('EA','HGB') AND NEW.object_name = 'esg_datapoints'
       AND (NEW.can_create OR NEW.can_update) THEN
        RAISE EXCEPTION 'SOD-08: governance roles may not enter or edit raw data';
    END IF;

    RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER tr_permission_guard
    BEFORE INSERT OR UPDATE ON esg_permissions
    FOR EACH ROW EXECUTE FUNCTION fn_permission_guard();

-- ---------------------------------------------------------------------
-- 5. SEGREGATION OF DUTIES CATALOGUE
-- ---------------------------------------------------------------------
CREATE TABLE esg_sod_rules (
    rule_id        VARCHAR(10) PRIMARY KEY,
    rule_text      TEXT NOT NULL,
    enforcement    VARCHAR(40) NOT NULL,
    ctrl_type      control_type NOT NULL,
    override_ok    BOOLEAN NOT NULL DEFAULT FALSE,
    override_role  VARCHAR(8) REFERENCES esg_roles(role_code),
    linkage        VARCHAR(120),
    CONSTRAINT ck_override CHECK (NOT override_ok OR override_role IS NOT NULL)
);

INSERT INTO esg_sod_rules (rule_id, rule_text, enforcement, ctrl_type, override_ok, override_role, linkage) VALUES
('SOD-01','Contributor may not approve the datapoint entered','db_constraint','hard_block',FALSE,NULL,'Four-eyes principle'),
('SOD-02','System Administrator holds no approval authority; self-grant blocked','role_model','hard_block',FALSE,NULL,'Privilege escalation control'),
('SOD-03','Assurance provider is read-only on client data','tenant_isolation','hard_block',FALSE,NULL,'ISO/IEC 17029:2019; ISO 14065:2020'),
('SOD-04','Preparation and assurance roles may not coexist per client and cycle','assignment_validation','hard_block',FALSE,NULL,'Impartiality'),
('SOD-05','Omission approver must differ from requester','db_constraint','hard_block',FALSE,NULL,'GRI 1 omission requirements'),
('SOD-06','Restatement executor may not approve it','db_constraint','hard_block',FALSE,NULL,'GRI 2-4'),
('SOD-07','AI output requires human disposition before use','workflow_guard','workflow_block',FALSE,NULL,'Human-in-the-loop'),
('SOD-08','Governance roles may not enter or edit raw data','permission_matrix','hard_block',FALSE,NULL,'Governance independence'),
('SOD-09','Break-glass access is time-boxed, justified and notified','session_control','logged_exception',TRUE,'EA','IT security control'),
('SOD-10','Technical reviewer may not review content he authored','api_guard','hard_block',TRUE,'EA','Independence of review'),
('SOD-11','Data Owner may not approve outside the assignment scope','scope_filter','hard_block',FALSE,NULL,'Scope integrity'),
('SOD-12','Assurance Coordinator may not answer technical findings','api_guard','hard_block',FALSE,NULL,'Evidence authenticity'),
('SOD-13','No user holds more than one of DC, DR, DO, ETR on the same disclosure','assignment_validation','hard_block',TRUE,'EA','Segregation integrity'),
('SOD-14','Publication requires executive execution plus a governance approval record','workflow_guard','hard_block',FALSE,NULL,'GRI 2-14'),
('SOD-15','Delegation may not bypass segregation; conflicts are inherited','role_resolution','hard_block',FALSE,NULL,'Delegation integrity');

-- ---------------------------------------------------------------------
-- 6. WORKFLOW AUTHORITY
-- ---------------------------------------------------------------------
CREATE TABLE esg_state_transitions (
    transition_id   SERIAL PRIMARY KEY,
    entity_type     VARCHAR(40) NOT NULL,       -- disclosure | finding | report | ai_output
    from_state      VARCHAR(40),
    to_state        VARCHAR(40) NOT NULL,
    authorized_roles VARCHAR(8)[] NOT NULL,
    preconditions   TEXT,
    mandatory_fields TEXT,
    post_effect     TEXT,
    audit_event     VARCHAR(30) NOT NULL,
    UNIQUE (entity_type, from_state, to_state)
);

-- SOD-01: four-eyes enforcement on approval of a datapoint
CREATE OR REPLACE FUNCTION fn_four_eyes(p_datapoint_id BIGINT, p_actor BIGINT)
RETURNS VOID AS $$
BEGIN
    IF EXISTS (SELECT 1 FROM esg_audit_log
                WHERE object_name = 'esg_datapoints'
                  AND object_id = p_datapoint_id
                  AND event_code IN ('DP_VALUE_SET','DSC_SUBMITTED')
                  AND actor_user_id = p_actor) THEN
        RAISE EXCEPTION 'SOD-01: the contributor of this datapoint may not approve it';
    END IF;
END; $$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------
-- 7. APPROVALS, OMISSIONS, RESTATEMENTS - separation constraints
-- ---------------------------------------------------------------------
CREATE TABLE esg_approvals (
    approval_id        BIGSERIAL PRIMARY KEY,
    object_name        VARCHAR(64) NOT NULL,
    object_id          BIGINT      NOT NULL,
    approval_type      VARCHAR(40) NOT NULL,     -- material_topics | department_data | technical | publication
    approver_user_id   BIGINT      NOT NULL,
    approver_assignment_id BIGINT  NOT NULL REFERENCES esg_role_assignments(assignment_id),
    governance_body_id BIGINT,
    approved_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    evidence_id        BIGINT,
    UNIQUE (object_name, object_id, approval_type, approver_user_id)
);

-- SOD-14: publication approval must be linked to a governance body record
ALTER TABLE esg_approvals ADD CONSTRAINT ck_publication_governance
    CHECK (approval_type <> 'publication' OR governance_body_id IS NOT NULL);

CREATE TABLE esg_omissions (
    omission_id     BIGSERIAL PRIMARY KEY,
    disclosure_id   BIGINT NOT NULL,
    cycle_id        BIGINT NOT NULL,
    reason_code     VARCHAR(40) NOT NULL,
    explanation     TEXT NOT NULL,
    future_plan     TEXT,
    requested_by    BIGINT NOT NULL,
    approved_by     BIGINT,
    approved_at     TIMESTAMPTZ,
    CONSTRAINT ck_omission_separation CHECK (approved_by IS NULL OR approved_by <> requested_by)
);

CREATE TABLE esg_restatements (
    restatement_id  BIGSERIAL PRIMARY KEY,
    cycle_id        BIGINT NOT NULL,
    reason          TEXT   NOT NULL,
    affected_periods TEXT  NOT NULL,
    executed_by     BIGINT NOT NULL,
    approved_by     BIGINT,
    approved_at     TIMESTAMPTZ,
    gri_2_4_entry_id BIGINT,
    CONSTRAINT ck_restatement_separation CHECK (approved_by IS NULL OR approved_by <> executed_by)
);

-- ---------------------------------------------------------------------
-- 8. ASSURANCE ISOLATION
-- ---------------------------------------------------------------------
CREATE TABLE esg_assurance_engagements (
    engagement_id      BIGSERIAL PRIMARY KEY,
    client_org_id      BIGINT NOT NULL,
    cycle_id           BIGINT NOT NULL,
    provider_org_id    BIGINT NOT NULL,
    assurance_level    VARCHAR(20) NOT NULL,       -- limited | reasonable
    scope_definition   TEXT   NOT NULL,
    access_from        TIMESTAMPTZ NOT NULL,
    access_to          TIMESTAMPTZ NOT NULL,
    impartiality_decl_id BIGINT NOT NULL,
    independent_reviewer_user_id BIGINT,
    status             VARCHAR(20) NOT NULL DEFAULT 'draft',
    CONSTRAINT ck_window CHECK (access_to > access_from)
);

CREATE TABLE esg_assurance_findings (
    finding_id      BIGSERIAL PRIMARY KEY,
    engagement_id   BIGINT NOT NULL REFERENCES esg_assurance_engagements(engagement_id),
    disclosure_id   BIGINT NOT NULL,
    finding_class   VARCHAR(20) NOT NULL,          -- material | immaterial
    description     TEXT NOT NULL,
    evidence_ref    TEXT,
    raised_by       BIGINT NOT NULL,
    raised_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    action_plan_id  BIGINT,
    closed_by       BIGINT,
    closed_at       TIMESTAMPTZ,
    CONSTRAINT ck_closure_requires_action CHECK (closed_at IS NULL OR action_plan_id IS NOT NULL)
);

-- BG-08: every read by an assurance account is evidence
CREATE TABLE esg_assurance_access_log (
    access_id     BIGSERIAL PRIMARY KEY,
    engagement_id BIGINT NOT NULL REFERENCES esg_assurance_engagements(engagement_id),
    user_id       BIGINT NOT NULL,
    object_name   VARCHAR(64) NOT NULL,
    object_id     BIGINT,
    read_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    ip_address    INET
);

CREATE TABLE esg_impartiality_declarations (
    declaration_id BIGSERIAL PRIMARY KEY,
    user_id        BIGINT NOT NULL,
    provider_org_id BIGINT,
    client_org_id  BIGINT NOT NULL,
    cycle_id       BIGINT NOT NULL,
    threats_identified TEXT,
    safeguards     TEXT,
    declared_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    evidence_id    BIGINT NOT NULL
);

-- ---------------------------------------------------------------------
-- 9. AI OUTPUT CONTROL
-- ---------------------------------------------------------------------
CREATE TABLE esg_ai_outputs (
    ai_output_id      BIGSERIAL PRIMARY KEY,
    object_name       VARCHAR(64) NOT NULL,
    object_id         BIGINT,
    model_reference   VARCHAR(80) NOT NULL,
    prompt_reference  VARCHAR(120),
    triggered_by      BIGINT NOT NULL,
    generated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    status            ai_status NOT NULL DEFAULT 'ai_suggested',
    reviewed_by       BIGINT,
    reviewed_at       TIMESTAMPTZ,
    disposition_note  TEXT,
    approval_grade    BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT ck_ai_review CHECK (status = 'ai_suggested' OR reviewed_by IS NOT NULL),
    -- SOD-07: for approval-grade content the reviewer must differ from the trigger
    CONSTRAINT ck_ai_self_review CHECK (NOT approval_grade OR reviewed_by IS NULL OR reviewed_by <> triggered_by)
);

-- ---------------------------------------------------------------------
-- 10. CHANGE REQUESTS - the only path to alter an approved value
-- ---------------------------------------------------------------------
CREATE TABLE esg_change_requests (
    change_request_id BIGSERIAL PRIMARY KEY,
    datapoint_id      BIGINT NOT NULL,
    original_value    TEXT   NOT NULL,
    requested_value   TEXT   NOT NULL,
    reason            TEXT   NOT NULL,
    requested_by      BIGINT NOT NULL,
    approved_by       BIGINT,
    approved_at       TIMESTAMPTZ,
    CONSTRAINT ck_cr_separation CHECK (approved_by IS NULL OR approved_by <> requested_by)
);

-- ---------------------------------------------------------------------
-- 11. AUDIT LOG - append only (WORM)
-- ---------------------------------------------------------------------
CREATE TABLE esg_audit_log (
    audit_id         BIGSERIAL PRIMARY KEY,
    event_code       VARCHAR(30) NOT NULL,
    actor_user_id    BIGINT      NOT NULL,
    acting_assignment_id BIGINT,
    delegating_user_id   BIGINT,
    object_name      VARCHAR(64) NOT NULL,
    object_id        BIGINT,
    previous_value   TEXT,
    new_value        TEXT,
    reason           TEXT,
    session_kind     session_type NOT NULL DEFAULT 'normal',
    ip_address       INET,
    occurred_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX ix_audit_object ON esg_audit_log (object_name, object_id, occurred_at);
CREATE INDEX ix_audit_actor  ON esg_audit_log (actor_user_id, occurred_at);

-- FLD-21: revoke update and delete for every application account
CREATE OR REPLACE FUNCTION fn_audit_immutable() RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'FLD-21: the audit log is append-only';
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER tr_audit_no_update BEFORE UPDATE ON esg_audit_log
    FOR EACH ROW EXECUTE FUNCTION fn_audit_immutable();
CREATE TRIGGER tr_audit_no_delete BEFORE DELETE ON esg_audit_log
    FOR EACH ROW EXECUTE FUNCTION fn_audit_immutable();

-- Grant model (application role must not hold UPDATE/DELETE at all)
-- REVOKE UPDATE, DELETE ON esg.esg_audit_log FROM app_user;
-- GRANT  SELECT, INSERT ON esg.esg_audit_log TO app_user;

-- ---------------------------------------------------------------------
-- 12. BREAK-GLASS SESSIONS
-- ---------------------------------------------------------------------
CREATE TABLE esg_break_glass_sessions (
    session_id     BIGSERIAL PRIMARY KEY,
    user_id        BIGINT NOT NULL,
    reason_code    VARCHAR(40) NOT NULL,
    justification  TEXT   NOT NULL,
    opened_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at     TIMESTAMPTZ NOT NULL,
    closed_at      TIMESTAMPTZ,
    reviewed_by    BIGINT,
    reviewed_at    TIMESTAMPTZ,
    CONSTRAINT ck_bg_window CHECK (expires_at > opened_at)
);

-- BG-04: break-glass never grants content approval
CREATE OR REPLACE FUNCTION fn_break_glass_guard() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.session_kind = 'break_glass'
       AND NEW.event_code IN ('DSC_APPROVED','MT_APPROVED','OMS_APPROVED','RPT_PUBLISHED','RST_APPROVED') THEN
        RAISE EXCEPTION 'BG-04: break-glass access does not confer content approval authority';
    END IF;
    RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER tr_break_glass_guard BEFORE INSERT ON esg_audit_log
    FOR EACH ROW EXECUTE FUNCTION fn_break_glass_guard();

-- ---------------------------------------------------------------------
-- 13. CONFIGURATION PARAMETERS (never hard-coded in application logic)
-- ---------------------------------------------------------------------
CREATE TABLE esg_config_parameters (
    param_key    VARCHAR(60) PRIMARY KEY,
    param_value  TEXT NOT NULL,
    data_type    VARCHAR(20) NOT NULL,
    configurable BOOLEAN NOT NULL DEFAULT TRUE,
    note         TEXT
);

INSERT INTO esg_config_parameters VALUES
('max_delegation_days','30','integer',TRUE,'Mandatory expiry on every delegation'),
('max_chain_depth','1','integer',TRUE,'Delegation chain limit'),
('break_glass_minutes','60','integer',TRUE,'Maximum emergency session duration'),
('break_glass_review_days','5','integer',TRUE,'Mandatory post-session executive review'),
('consultancy_cooling_off_months','','integer',TRUE,'Not fixed by ISO/IEC 17029:2019 or ISO 14065:2020 - set by the impartiality policy'),
('hgb_delegation_allowed','false','boolean',TRUE,'Whether publication approval may be delegated'),
('variance_explanation_threshold','','decimal',TRUE,'Set by the approved methodology');

-- ---------------------------------------------------------------------
-- 14. VERIFICATION QUERIES (run as part of acceptance testing)
-- ---------------------------------------------------------------------
-- V1: no role class may hold approval rights it should not have
-- SELECT * FROM esg_roles WHERE role_class IN ('system','assurance') AND can_approve_content;

-- V2: any assignment active without appointment evidence
-- SELECT * FROM esg_role_assignments a JOIN esg_roles r USING (role_code)
--  WHERE a.status='active' AND r.requires_appointment AND a.appointment_evidence_id IS NULL;

-- V3: users holding conflicting review-chain roles on the same scope
-- SELECT user_id, scope_type, scope_id, reporting_cycle_id, COUNT(DISTINCT role_code)
--   FROM esg_role_assignments
--  WHERE role_code IN ('DC','DR','DO','ETR') AND status='active'
--  GROUP BY 1,2,3,4 HAVING COUNT(DISTINCT role_code) > 1;

-- V4: publication approvals without a governance body record
-- SELECT * FROM esg_approvals WHERE approval_type='publication' AND governance_body_id IS NULL;

-- V5: assurance accounts with any write event in the audit log
-- SELECT l.* FROM esg_audit_log l JOIN esg_role_assignments a ON a.user_id=l.actor_user_id
--  WHERE a.role_code='EAP' AND l.event_code NOT IN ('AF_CREATED','AF_CLOSED','AF_REMEDIATION');
-- =====================================================================
-- END OF SCRIPT
-- =====================================================================
