# Requirement 10 — Roles, Authority & Access Control Specification

**ESG Intelligence & GRI Digital Reporting Module**

| Field | Entry |
|---|---|
| Document ID | ESG-GRI-MOD/REQ-10/SPEC |
| Version | 1.0 — Issued for review |
| Status | Draft for approval by the ESG/GRI Technical Domain Lead |
| Methodology owner | ESG/GRI Technical Domain Lead |
| Implementation owner | Development team — implementation only, no methodology interpretation |
| Companion file | `REQ-10_Roles_Authority_Access_Control_Matrices.xlsx` (11 controlled sheets) |
| Companion file | `REQ-10_RBAC_Schema.sql` (reference data model and constraints) |

---

## 1. Purpose

This specification converts the roles and permissions requirement of the ESG & GRI Digital Reporting Module into an implementable and testable control design. It defines who may do what, within which scope, under which preconditions, and what evidence the system must retain.

It replaces the previous formulation of Requirement 10, which listed job titles only and could not be implemented. A job title is not a permission. A permission is an authorised operation on a named object, within a defined scope, subject to stated preconditions, producing a recorded audit event.

## 2. Scope

This document covers:

- the role register and role scoping model;
- accountability across the reporting process (RACI);
- object-level and field-level permissions;
- workflow state transition authority;
- segregation of duties;
- delegation, backup, leaver handling and emergency access;
- isolation controls for external assurance access;
- controls over AI-generated content;
- audit trail requirements;
- generation of governance-related disclosures from role records.

It does not cover network security, identity provider configuration, encryption or infrastructure hardening. Those belong to the platform security baseline and are referenced but not specified here.

## 3. Normative references

| Reference | Application in this document |
|---|---|
| GRI 1: Foundation 2021 | Reporting requirements, omission rules, and the conditions governing the "in accordance" claim |
| GRI 2: General Disclosures 2021 | Governance disclosures generated from role and approval records (2-4, 2-5, 2-9 to 2-18, 2-22 to 2-29) |
| GRI 3: Material Topics 2021 | Material topic determination and management, including responsibility for managing each topic |
| Applicable GRI Sector and Topic Standards | Applicability rules driving disclosure assignment |
| ISO/IEC 17029:2019 | General principles and requirements for validation and verification bodies; impartiality management |
| ISO 14065:2020 | Requirements for bodies validating and verifying environmental information |
| ISO 14066:2023 | Competence requirements for validation and verification teams |
| ISO 14064-3:2019 | Verification and validation process, evidence sufficiency and findings handling |
| COSO Internal Control — Integrated Framework | Control environment, authority and accountability structures applied to sustainability reporting |

**Version control note.** GRI 102: Climate Change 2025 and GRI 103: Energy 2025 take effect for reporting periods beginning on or after 1 January 2027, with early adoption permitted; they replace GRI 305 (Disclosures 305-1 to 305-5), GRI 302, and Disclosure 201-2. GRI 101: Biodiversity 2024 takes effect from 1 January 2026. GRI 2: General Disclosures remains the 2021 edition. Disclosure identifiers must therefore be read from the standards library at runtime and must never be hard-coded in application logic.

## 4. Design principles

**P1 — Enforcement at data layer.** Every rule in this specification is enforced by database constraint, trigger or API guard. User-interface enforcement alone is not accepted and will fail acceptance testing.

**P2 — No authority without scope.** A role is meaningless until bound to an organizational, geographic, content and time scope. Role assignment is a record, not an attribute of a user.

**P3 — Separation of system authority from content authority.** Administrative privilege over the platform never confers approval authority over reported information.

**P4 — Independence of assurance.** The assurance provider reads; it never writes to client data. Preparation and assurance may not meet in the same person, the same account or the same organizational unit for the same client and cycle.

**P5 — Evidence by default.** Every approval, rejection, omission, delegation, restatement and emergency access produces a durable, exportable record. If an action cannot be evidenced, it must not be possible.

## 5. Control architecture — three layers

| Layer | Question answered | Artefact | Sheet |
|---|---|---|---|
| L1 — Accountability | Who answers for each step of the process? | RACI matrix | 02 |
| L2 — Permissions | Which operations may a role perform on which object and field? | Permission matrix, field rules | 03, 04 |
| L3 — Workflow authority | Who may move a record from one state to another, and under which preconditions? | State transition table | 05 |

A RACI matrix alone cannot be implemented. Layers 2 and 3 are the developer-facing contract; Layer 1 is the organizational contract.

## 6. Role scoping model

Role assignment is a first-class record:

```
esg_role_assignments
  assignment_id
  user_id
  role_code                 -- FK to the role register (18 roles)
  scope_type                -- organization | legal_entity | site | department | topic | disclosure_set | engagement
  scope_id
  reporting_cycle_id
  effective_from / effective_to
  is_backup                 -- named backup, inactive until activated
  is_delegated / delegated_by / delegation_expiry
  appointment_evidence_id   -- appointment letter, board resolution, charter
  impartiality_declaration_id
  status                    -- active | suspended | expired
```

Rules:

1. A role is granted per reporting cycle and is not inherited automatically into the next cycle.
2. Every assignment requires stored appointment evidence before activation.
3. Assignment of Executive Approver or Highest Governance Body requires dual authorization.
4. Effective role resolution runs the segregation rules on the **effective** role set, including delegated roles.
5. Deactivating a user surfaces open assignments for reassignment; the reporting period cannot be locked while unassigned mandatory items remain.

## 7. Role register

Eighteen roles are defined in sheet 01. Eight were present in the original requirement; ten were added because the process cannot be operated or evidenced without them.

| Class | Roles |
|---|---|
| Governance | HGB — Highest Governance Body / Sustainability Committee; EA — Executive Approver |
| Programme | EPM — ESG Programme Manager |
| Content | MTO — Material Topic Owner; IMO — Impact Owner; TGO — Target Owner; SEO — Stakeholder Engagement Owner; RED — Report Editor |
| Data | DO — Data Owner; DC — Data Contributor |
| Review | DR — Department Reviewer; ETR — ESG Technical Reviewer; TRR — Translation & Terminology Reviewer; AIR — AI Output Reviewer |
| Assurance | AC — Assurance Coordinator; EAP — External Assurance Provider |
| Support / System | SA — System Administrator; OBS — Read-only Observer (Internal Audit) |

**Rationale for the ten added roles.** Without HGB the module cannot evidence the governance body's role in reviewing and approving the reported information and the material topics, and therefore cannot produce that disclosure. Without MTO and IMO the module cannot evidence responsibility for managing topics and impacts. Without AC the assurance channel is uncontrolled and correspondence with the assurance provider is unrecorded. Without AIR the AI disposition workflow has no owner. Without TRR bilingual output has no terminology control. Without OBS internal audit must be given a write-capable account, which breaks independence.

## 8. Accountability model

Sheet 02 covers 24 process steps: the 20 defined in the module workflow plus four added steps (narrative drafting, terminology and translation review, AI output disposition, and role assignment with impartiality declarations).

Rules applied:

1. Exactly one Accountable per step. This is validated programmatically; the workbook passes with zero exceptions.
2. The System Administrator holds neither Responsible nor Accountable on any content step. Its presence on a content RACI is itself a design defect.
3. The External Assurance Provider holds no Responsible or Accountable role before the assurance step, and never on client data.
4. Approval of the material topic list and approval of the report for publication are Accountable to the Highest Governance Body. Where this is delegated to a senior executive, the delegation decision must be stored as evidence, because the corresponding disclosure requires the approving authority to be identified.

## 9. Permission model

Sheet 03 defines object-level rights for all 37 objects across all 18 roles. Sheet 04 defines field-level rules for controlled fields.

Structural decisions:

- **Soft delete only.** Hard delete is disabled system-wide. Deletion grants do not exist for application accounts.
- **The System Administrator has no access to content objects.** Its rights are confined to user administration, role assignment, configuration, and technical loading of the standards library. Activation of a standards version is an ESG Technical Reviewer decision.
- **The audit log is append-only.** `UPDATE` and `DELETE` grants are revoked at database level for every application account, including administrative accounts.
- **Approval stamps are system-set.** `approved_by`, `approved_at` and `approver_role_id` have no user write path in the API or the interface.
- **Narrative sections carry no typed numbers.** Numeric content is inserted by reference to a datapoint identifier so that a restatement propagates automatically and the report cannot drift from the dataset.

## 10. Workflow authority

Sheet 05 defines 24 transitions across the disclosure lifecycle, the assurance lifecycle, the publication and lock sequence, the restatement sequence and the AI disposition sequence.

Key control points:

| Control point | Rule |
|---|---|
| Marking a disclosure Not Applicable | ESG Technical Reviewer only, with an applicability rule reference or documented justification |
| Submission | Blocked until all blocking validation rules pass and mandatory evidence is attached |
| Departmental approval | Two steps, and neither approver may be the contributor |
| Technical approval | ESG Technical Reviewer only, and not the contributor or departmental reviewer for that datapoint |
| Assurance exposure | Read-only, scoped to the engagement, time-boxed, and fully logged |
| Finding closure | Assurance provider only, after a linked corrective action is completed |
| Publication | Requires two distinct actors: executive execution and a linked governance approval record |
| Period lock | Blocked while any mandatory disclosure is open and not covered by an approved omission |
| Restatement | Executor and approver must differ; approval generates the restatement disclosure entry automatically |

After a datapoint reaches the approved state its value is immutable. The only path to change is a change request, which retains the original value, the reason and the approval.

## 11. Segregation of duties

Fifteen rules are defined in sheet 06, each with its enforcement layer, control type and detection logic. Nine are hard blocks with no override. The rules that most often fail in ESG platforms, and are therefore treated as critical, are:

1. Contributor and approver are the same person (four-eyes failure).
2. The administrator grants himself a content role (privilege escalation).
3. The assurance account can write to client data (independence failure).
4. Preparation and assurance roles coexist for the same client and cycle (impartiality failure).
5. Publication occurs without a governance approval record (governance failure).

Delegation may not be used to bypass any segregation rule; a delegate inherits the delegator's conflicts.

## 12. External assurance isolation

This section is mandatory where the module supports engagements involving an accredited validation and verification body, and where preparation and assurance activities exist within the same corporate group but in separate legal entities.

| Control | Requirement |
|---|---|
| Tenancy | The assurance provider operates in a read-only tenancy over the client dataset |
| Scope | Access is limited to the disclosures inside the agreed engagement scope |
| Time boxing | Access tokens expire with the engagement window and are revoked automatically without administrator action |
| Read logging | Every read is logged — account, object, timestamp — and is exportable as engagement evidence |
| Write path | Confined to assurance objects; any write attempt outside them is rejected and recorded as a security event |
| Findings | Raised, classified and closed by the assurance provider only; client roles respond through a linked response record and never by editing a finding |
| Declarations | A signed impartiality declaration and competence evidence must exist before account activation; re-declaration is required on any scope change |
| Conflict blocking | A user or organizational unit holding a preparation or consultancy assignment for a client is hard-blocked from an assurance role for that client and cycle |
| Independent review | The assurance body's internal independent review is a separate role from the engagement lead; the module records both |

**Parameter not specified by the standards.** The cooling-off period between providing consultancy and performing validation or verification for the same client is not fixed as a numeric value in ISO/IEC 17029:2019 or ISO 14065:2020; those standards require identification, analysis and treatment of impartiality risks. The period is therefore implemented as a configurable system parameter driven by the body's documented impartiality policy, and must not be hard-coded.

## 13. Controls over AI-generated content

Artificial intelligence is a technical assistant, not a role and not a decision-maker.

1. Every AI output carries a status: AI Suggested, Human Reviewed, Accepted, Rejected, Modified.
2. Every output is attributed to the user who triggered the run, together with the model identifier and prompt reference.
3. Content in AI Suggested status is excluded from completion metrics and cannot enter the disclosure workflow.
4. For approval-grade content the reviewer must differ from the triggering user.
5. AI may not approve material topics, approve omissions, generate missing data, conclude conformity, or publish.

## 14. Audit trail requirements

The audit log records, for every event: event code, actor user ID, acting role assignment ID, delegating authority where applicable, object type and identifier, previous value, new value, timestamp, source IP, session type (normal or break-glass), and reason where the event requires one.

Requirements:

- Append-only, with no update or delete path for any account.
- Retention aligned to the assurance and legal retention policy, and never shorter than the assurance evidence retention period.
- Exportable per indicator as an assurance pack containing value, source, formula, evidence, entering user, reviewer, approvals, change history and related findings.
- Break-glass sessions are flagged and included in the assurance pack by default.

## 15. Governance disclosures generated from role records

Sheet 08 maps 21 GRI disclosures to their system source object, responsible role, and whether the content can be generated automatically. The design decision is that the role register and the approval records are not merely configuration — they are the evidence base for the governance disclosures.

This applies in particular to restatements of information, external assurance, governance structure and composition, oversight of impact management, delegation of responsibility for managing impacts, the governance body's role in sustainability reporting, conflicts of interest, the approach to stakeholder engagement, the process to determine material topics, the list of material topics, and the management of each material topic.

All auto-generated content requires human review by the ESG Technical Reviewer before it enters the report.

## 16. Configuration parameters

| Parameter | Default | Configurable | Note |
|---|---|---|---|
| `max_delegation_days` | 30 | Yes | Mandatory expiry on every delegation |
| `max_chain_depth` | 1 | Yes | Delegation chains limited to one level |
| `break_glass_minutes` | 60 | Yes | Maximum emergency session duration |
| `break_glass_review_days` | 5 | Yes | Mandatory post-session executive review |
| `assurance_access_window` | Engagement dates | No | Derived from the engagement record |
| `consultancy_cooling_off_months` | Per impartiality policy | Yes | Not fixed by ISO/IEC 17029:2019 or ISO 14065:2020 |
| `variance_explanation_threshold` | Set by methodology | Yes | Triggers mandatory explanation on year-on-year movement |
| `hgb_delegation_allowed` | Disabled | Yes, by board decision | Governs whether publication approval may be delegated |

## 17. Implementation sequence

**MVP.** Sixteen roles (all except IMO and TGO, which may be represented by MTO in the first release), the full permission matrix, all state transitions for the disclosure and publication lifecycle, all fifteen segregation rules, delegation and break-glass, assurance isolation, the audit log, and bilingual terminology control.

**Phase 1.** Impact Owner and Target Owner as distinct roles, internal audit observer, automated generation of governance disclosures, supplier portal roles, and taxonomy tagging roles for structured output.

The audit log, role assignment model and assurance isolation must be built in the MVP. Retrofitting an audit trail after go-live invalidates the evidence base for every period reported before the retrofit.

## 18. Acceptance

The requirement is accepted only when:

1. Sheets 01 to 08 and 10 are approved by the ESG/GRI Technical Domain Lead.
2. The development lead confirms sheets 03 to 07 are implementable as written.
3. All 35 test cases in sheet 09 are executed with zero open Critical failures.
4. Sheet 11 is signed by all four named parties.

## 19. Limitations and items not specified

The following are deliberately not specified here and must be provided before build:

- Identity provider, authentication method and session policy — **not specified**; belongs to the platform security baseline.
- Data retention periods in months or years — **not provided**; must be set from the organization's records retention and assurance policies.
- The cooling-off period between consultancy and assurance — **not specified by the referenced standards**; set by the assurance body's impartiality policy.
- Licensing route for embedding standard content in a commercial product — **not resolved**; must be confirmed with the standard setter before commercial release. This is a gating item for any software-as-a-service offering, not a documentation detail.

---

## Appendix A — ملخص تنفيذي بالعربية

هذه الوثيقة تحوّل المتطلب 10 من قائمة مسميات وظيفية إلى مواصفة ضوابط قابلة للبرمجة والاختبار، وتغطي:

- **18 دورًا** بدلًا من 8، لأن العملية لا يمكن تشغيلها أو إثباتها بدون الأدوار العشرة المضافة، وعلى رأسها **أعلى جهة حوكمة** التي بدونها لا يمكن إنتاج إفصاح اعتماد التقرير أصلًا.
- **مصفوفة مسؤوليات** على 24 خطوة، بمسؤول نهائي واحد لكل خطوة، تم التحقق منها برمجيًا.
- **مصفوفة صلاحيات** على 37 كائنًا، مع قاعدة حاكمة: **مسؤول النظام لا يملك أي صلاحية اعتماد على محتوى ESG**، و**جهة التأكيد الخارجي لا تملك أي صلاحية كتابة على بيانات العميل**.
- **24 انتقال حالة** بشروط حاجبة وحقول إلزامية، مع قفل القيمة بعد الاعتماد وعدم إمكانية تعديلها إلا عبر طلب تغيير موثق.
- **15 قاعدة فصل مهام**، تسع منها منع مطلق بلا استثناء، مطبقة على مستوى قاعدة البيانات وليس الواجهة.
- **ضوابط عزل جهة التأكيد**: نطاق محدد، صلاحية زمنية تنتهي تلقائيًا، تسجيل كامل لكل قراءة، ومنع تقني لتعارض الإعداد مع التحقق لنفس العميل ونفس الدورة.
- **ضوابط الذكاء الاصطناعي**: لا يوجد مخرج آلي قابل للاستخدام قبل تسجيل قرار بشري موثق.
- **ربط الأدوار بإفصاحات GRI**: سجل الأدوار وسجلات الاعتماد هما مصدر الإثبات لإفصاحات الحوكمة، لا مجرد إعدادات نظام.
- **35 حالة اختبار قبول** لا يُقبل البند قبل اجتيازها دون إخفاقات حرجة مفتوحة.

**تنبيه تجاري:** مسار ترخيص محتوى المعايير داخل منتج تجاري بند حاكم يجب حسمه قبل الإطلاق، وليس تفصيلًا توثيقيًا.

---

## Appendix B — Audit event codes

| Code | Event |
|---|---|
| `DSC_INIT` | Disclosure created in the register |
| `DSC_NA` | Disclosure marked Not Applicable |
| `DSC_REQUESTED` | Data request issued |
| `DSC_INPROGRESS` | Data entry started |
| `DSC_SUBMITTED` | Data submitted for review |
| `DSC_RETURNED` | Returned for correction |
| `DSC_REWORK` | Correction started |
| `DSC_DEPT_APPROVED` | Departmental approval recorded |
| `DSC_ESG_QUEUE` | Routed to technical review |
| `DSC_APPROVED` | Technical approval recorded |
| `DSC_ASSURANCE` | Exposed to assurance within scope |
| `AF_CREATED` | Assurance finding raised |
| `AF_REMEDIATION` | Remediation started |
| `AF_CLOSED` | Assurance finding closed |
| `RPT_READY` | Report package assembled |
| `RPT_PUBLISHED` | Report published |
| `CYC_LOCKED` | Reporting period locked |
| `CYC_SUSPENDED` | Cycle suspended |
| `RST_OPENED` | Restatement opened |
| `RST_APPROVED` | Restatement approved |
| `OMS_PROPOSED` | Omission proposed |
| `OMS_APPROVED` | Omission approved |
| `MT_APPROVED` | Material topic list approved |
| `MT_THRESHOLD_SET` | Materiality threshold set |
| `IMP_SCORED` | Impact scored |
| `TGT_BASELINE_SET` | Target baseline set |
| `CI_GENERATED` | Content index generated |
| `AI_SUGGESTED` | AI output created |
| `AI_REVIEWED` | AI output reviewed |
| `AI_DISPOSITIONED` | AI output accepted, rejected or modified |
| `ROLE_PRIV_ASSIGNED` | Privileged role assigned |
| `BG_SESSION_OPENED` | Break-glass session opened |
| `BG_ACTION` | Action performed under break-glass |
| `SEC_DENIED` | Access or write attempt denied |
