# المتطلب 12 — Output Specification
## المواصفة التفصيلية للمخرجات | ESG Intelligence & GRI Digital Reporting Module

| البند | البيان |
|---|---|
| Document ID | ESG-GRI-SPEC-REQ12 |
| Version | 1.0 (Draft for development) |
| Owner | ESG/GRI Technical Domain Lead (Methodology Owner) |
| Approver | ESG Programme Manager + Product Owner |
| المرجع المعياري | GRI 1: Foundation 2021 (effective 1 Jan 2023), GRI 2: General Disclosures 2021, GRI 3: Material Topics 2021, GRI Sector Standards, GRI Topic Standards |
| مرجع التأكيد | ISO/IEC 17029:2019, ISO 14064-3:2019 (حيثما يشمل النطاق بيانات GHG), ISAE 3000 (Revised) حسب مقدم التأكيد |

> **قاعدة حاكمة:** كل مخرج في هذه الوثيقة يجب أن يكون **مولَّدًا من قاعدة البيانات** وليس محررًا يدويًا، وأن يكون **قابلًا لإعادة الإنتاج** بنفس النتيجة عند نفس نقطة قطع البيانات، وأن يكون **متتبعًا** حتى مستوى المستند المصدر والشخص المدخل.

---

# 0. قواعد حاكمة لكل المخرجات (Global Output Governance Rules)

## 0.1 بطاقة تعريف إلزامية على كل مخرج (Output Header Block)

يجب أن يطبع النظام تلقائيًا على كل مخرج (PDF/Excel/DOCX/Screen) الحقول التالية:

| الحقل | المصدر | ملاحظات |
|---|---|---|
| `output_id` | System | مثال: `OUT-01-2025-EGY-0007` |
| `output_type` | System | من كتالوج المخرجات أدناه |
| `organization_name` / `legal_entity` | `esg_organizations`, `esg_legal_entities` | الاسم القانوني وليس التجاري |
| `reporting_cycle` + `period_start` / `period_end` | `esg_reporting_cycles` | يطابق فترة التقرير المالي حيثما أمكن |
| `reporting_boundary_ref` | `esg_reporting_boundaries` | الكيانات والمواقع المشمولة |
| `data_cut_off_timestamp` | System | **إلزامي** — لحظة قطع البيانات (UTC + التوقيت المحلي) |
| `output_version` | System | ترقيم متسلسل غير قابل للتعديل |
| `output_status` | System | Draft / Under Review / Approved / Published / Superseded |
| `generated_by`, `generated_at` | System | المستخدم + الطابع الزمني |
| `approved_by`, `approved_at` | `esg_approvals` | فارغ في حالة Draft |
| `language` | System | AR / EN |
| `confidentiality_class` | `esg_datapoints` | Public / Internal / Confidential / Restricted |
| `checksum` | System | SHA-256 لملف المخرج بعد التوليد |

## 0.2 دورة حياة المخرج (Output Lifecycle)

`Draft → Under Review → Approved → Published → Superseded`

- أي مخرج بحالة `Draft` أو `Under Review` يُطبع عليه **DRAFT / NOT FOR EXTERNAL USE** كعلامة مائية إلزامية.
- لا يُسمح بتصدير `Published` إلا بعد قفل الفترة (`period_lock = TRUE`).
- عند فتح Restatement، تنتقل النسخة السابقة تلقائيًا إلى `Superseded` مع الاحتفاظ بها كاملة (لا حذف).

## 0.3 قابلية إعادة الإنتاج (Reproducibility Rule)

يجب أن يخزن النظام مع كل مخرج **Snapshot** للبيانات المستخدمة في توليده (أو مؤشرات إصدار الصفوف `row_version`) بحيث تُعاد طباعة نفس المخرج بعد سنة بنفس القيم. هذه نقطة مراجعة أساسية عند التأكيد الخارجي ومرتبطة بمبدأ **Verifiability** في GRI 1.

## 0.4 اللغة

- كل مخرج ثنائي اللغة على مستوى **الهيكل والعناوين الوصفية**.
- **أرقام وعناوين معايير GRI وأسماء الإفصاحات تُعرض بالإنجليزية كما هي رسميًا**، مع إمكانية عرض ترجمة عربية توضيحية بجوارها مُعلّمة صراحة بـ `Unofficial translation — for guidance only`.
- لا يُسمح بإنتاج GRI Content Index بترجمة عربية غير رسمية كنسخة رسمية.

## 0.5 حقوق النشر والادعاءات

- لا يُظهر أي مخرج عبارات: `GRI Certified`, `GRI Approved`, `GRI Rating`, `GRI Score`, `Compliance Certificate`, ولا شعار GRI بما يوحي باعتماد.
- المسميات الداخلية المسموحة فقط: `Disclosure Completion Score`, `Evidence Coverage Score`, `Data Quality Score`, `Review Progress Score`, `ESG Management Maturity Score`, `Target Performance Score`.
- عرض نصوص GRI المحمية داخل المخرجات التجارية مشروط بترخيص GRI (بند مستقل في خطة المشروع قبل الإطلاق).

## 0.6 الحياد والفصل (Impartiality Control — إلزامي في التصميم)

| الدور | الصلاحية على المخرجات |
|---|---|
| Preparer / Consultant | إنشاء وتعديل البيانات والمخرجات في حالة Draft |
| ESG Technical Reviewer | مراجعة واعتماد داخلي |
| Executive Approver | اعتماد الموضوعات الجوهرية والتقرير |
| **External Assurance Provider (VVB)** | **Read-only** على كل البيانات والأدلة + كتابة في `esg_assurance_findings` فقط. **لا يملك أي صلاحية تعديل على بيانات العميل** |
| System Administrator | إدارة المستخدمين والإعدادات — **بدون** اعتماد فني لمحتوى ESG |

- النظام **لا يُصدر** بيان التأكيد (Assurance Statement)؛ يقوم فقط **بتخزينه ونشره** بعد رفعه من جهة التحقق المستقلة.
- يجب أن يمنع النظام تقنيًا أن يكون نفس المستخدم `Preparer` و`Assurance Provider` على نفس الدورة (Conflict-of-Interest Check).

## 0.7 صيغ التصدير القياسية

| الصيغة | الاستخدام |
|---|---|
| PDF/A-2b | النسخ الرسمية والمعتمدة (أرشفة طويلة الأجل) |
| XLSX | Content Index، Gap Analysis، Audit Pack Index، Data Tables |
| DOCX | Sustainability Report Builder (نسخة قابلة للتحرير التحريري فقط) |
| CSV / JSON | تكامل وتصدير آلي |
| ZIP | Audit & Assurance Pack (حزمة كاملة + Manifest) |
| *(المرحلة التالية)* XBRL / iXBRL | وفق GRI Sustainability Taxonomy |

---

# 1. OUT-01 — ESG Gap Analysis Report

| البند | التفصيل |
|---|---|
| **الغرض** | تحديد ما يمنع إصدار تقرير GRI قابل للمراجعة، وتحويل كل فجوة إلى إجراء تصحيحي بمسؤول وتاريخ |
| **الجمهور** | ESG Programme Manager، مديري الإدارات، الإدارة العليا |
| **التشغيل** | On-demand + Scheduled (أسبوعي) + Auto قبل أي محاولة انتقال إلى `Report Freeze` |
| **المعاملات (Parameters)** | Reporting cycle، Entity/Site، Department، ESG Pillar، Material topic، Severity، Status، Due-date range |

## 1.1 هيكل التقرير

| القسم | المحتوى |
|---|---|
| **A. In-Accordance Readiness** | حالة الامتثال لمتطلبات GRI 1 التسعة (جدول 1.2) — **هذا القسم هو البوابة** |
| **B. Applicable Requirements Inventory** | المعايير والإفصاحات المنطبقة (Universal + Sector + Topic) وعددها ومصدر انطباقها |
| **C. Completed Disclosures** | المكتملة والمعتمدة + نسبة الاكتمال لكل معيار |
| **D. Missing / Incomplete Disclosures** | الناقصة على مستوى Disclosure و Sub-requirement |
| **E. Evidence Gaps** | الأدلة الناقصة/منتهية الصلاحية/غير المطابقة للفترة أو الموقع |
| **F. Data Inconsistencies** | مخالفات Validation Catalogue + الانحرافات غير المفسرة مقابل السنة السابقة |
| **G. Omission Integrity** | أسباب الحذف المستخدمة وصحتها (جدول 1.4) |
| **H. Corrective Action Plan (CAPA)** | الإجراء، المسؤول، الموعد، الحالة، العمر بالأيام |
| **I. Summary Dashboard** | عدد الفجوات حسب الخطورة/الإدارة/الموقع + اتجاه الإغلاق |

## 1.2 محرك فحص المتطلبات التسعة (Requirement-Level Gate)

| # | متطلب GRI 1 | الفحص الآلي المطلوب | النتيجة عند الإخفاق |
|---|---|---|---|
| R1 | تطبيق مبادئ الإعداد | اكتمال نموذج Reporting Principles Self-Assessment (OUT-12) | Major |
| R2 | الإفصاح عن كل بنود GRI 2 | جميع إفصاحات GRI 2 لها حالة `Approved` أو `Omission (مسموح)` | **Blocking** |
| R3 | تحديد الموضوعات الجوهرية + مراجعة معايير القطاع | وجود Materiality Assessment معتمد + تقييم كل موضوع في Sector Standard المنطبق | **Blocking** |
| R4 | إفصاحات GRI 3 (3-1, 3-2, 3-3) | 3-1 و3-2 مكتملان (لا يقبلان حذفًا)، و3-3 لكل موضوع جوهري | **Blocking** |
| R5 | إفصاحات Topic Standards لكل موضوع جوهري | لكل موضوع جوهري إفصاح واحد على الأقل أو حذف مبرر | **Blocking** |
| R6 | أسباب الحذف | كل حذف من الأسباب الأربعة المسموحة + التفسير المطلوب مكتمل | **Blocking** |
| R7 | نشر GRI Content Index | اجتياز كل قواعد OUT-03 | **Blocking** |
| R8 | بيان الاستخدام (Statement of Use) | الصيغة الصحيحة + مطابقة الفترة | **Blocking** |
| R9 | إخطار GRI | تسجيل الإخطار (OUT-13) بعد النشر | Major |

**قاعدة تشغيل إلزامية:** إذا وُجدت فجوة واحدة بحالة **Blocking**، يمنع النظام تفعيل `Statement of Use = in accordance` ويقتصر على `with reference` أو `Draft`.

## 1.3 تصنيف الفجوات (Gap Taxonomy)

| Code | نوع الفجوة | مصدر الاكتشاف |
|---|---|---|
| `GAP-STD` | معيار منطبق غير مُفعّل في الدورة | Applicability rules |
| `GAP-SEC` | موضوع في Sector Standard لم يُقيَّم (جوهري/غير جوهري) | Sector matrix |
| `GAP-DISC` | إفصاح مطلوب بدون بيانات | Disclosure matrix |
| `GAP-REQ` | إجابة جزئية على متطلب فرعي (Sub-requirement) | Requirement-level tracking |
| `GAP-EVD` | دليل ناقص / منتهٍ / لا يغطي الفترة أو الموقع | Evidence rules |
| `GAP-VAL` | إخفاق قاعدة تحقق | Validation Catalogue |
| `GAP-CMP` | لا توجد بيانات مقارنة للفترة السابقة | Comparability check |
| `GAP-RST` | إعادة عرض بيانات دون إفصاح 2-4 | Restatement engine |
| `GAP-OMS` | سبب حذف غير مسموح أو تفسير ناقص | Omission engine |
| `GAP-APR` | بيانات غير معتمدة من المستوى المطلوب | Workflow engine |
| `GAP-EST` | تقدير/افتراض دون توثيق منهجية | Data quality engine |
| `GAP-ASR` | نقطة داخل نطاق التأكيد بلا مسار تتبع كامل | Assurance scope |

## 1.4 قواعد الخطورة (Severity Rules) — أمثلة إلزامية

| الحالة | الخطورة |
|---|---|
| استخدام سبب حذف على إفصاح لا يقبل الحذف (2-1، 2-2، 2-3، 2-4، 2-5، 3-1، 3-2) | **Blocking** |
| موضوع جوهري بدون إفصاح 3-3 | **Blocking** |
| سبب حذف `Information unavailable / incomplete` بدون تحديد الجزء الناقص أو بدون خطة وإطار زمني | **Blocking** |
| موضوع في Sector Standard المنطبق غير مُقيَّم | **Blocking** |
| إفصاح داخل نطاق التأكيد بدون دليل | Major |
| انحراف > Threshold عن السنة السابقة بدون تفسير | Major |
| اختلاف وحدة قياس عن قاموس البيانات | Major |
| دليل مرفوع بدون تحديد الفترة/الموقع | Minor |
| ملاحظة تحسينية بلا أثر على الامتثال | Observation |

## 1.5 حقول صف الفجوة (Gap Record Fields)

`gap_id` · `gap_code` · `severity` · `gri_standard` · `disclosure_id` · `requirement_ref` · `material_topic` · `entity` · `site` · `department` · `data_owner` · `description_ar` · `description_en` · `detected_by` (Rule / Reviewer / Assurance / AI-Suggested) · `detected_at` · `corrective_action` · `action_owner` · `target_date` · `status` (Open / In Progress / Pending Verification / Closed / Accepted Risk) · `closure_evidence_ref` · `closed_by` · `closed_at` · `age_days` · `linked_finding_id`

## 1.6 المصادر والتصدير

- **Source tables:** `gri_standards`, `gri_disclosures`, `gri_disclosure_requirements`, `gri_applicability_rules`, `gri_sector_topics`, `esg_material_topics`, `esg_datapoints`, `esg_evidence`, `esg_omissions`, `esg_reviews`, `esg_approvals`, `esg_assurance_findings`, `esg_restatements`
- **Exports:** XLSX (ورقة لكل قسم) · PDF/A · CSV للـ CAPA
- **معايير القبول:** لا يُقبل التقرير إذا أنتج فجوة واحدة بلا `disclosure_id` أو بلا `action_owner`؛ ويجب أن يتطابق مجموع (المكتملة + الناقصة + المحذوفة + غير المنطبقة) مع إجمالي الإفصاحات المنطبقة **بدقة 100%**.

---

# 2. OUT-02 — Materiality Assessment Report

| البند | التفصيل |
|---|---|
| **الغرض** | إثبات أن الموضوعات الجوهرية نتجت عن عملية موثقة قابلة للتدقيق، وليست قائمة جاهزة أو متوسط درجات استبيان |
| **الجمهور** | الإدارة العليا، أعلى جهة حوكمة، جهة التأكيد، القارئ الخارجي |
| **الارتباط المعياري** | يغذي الإفصاحين 3-1 (العملية) و3-2 (القائمة)، ويرتبط بـ 2-12 و2-14 و2-29 |

## 2.1 هيكل التقرير

| القسم | المحتوى الإلزامي |
|---|---|
| **1. المنهجية** | خطوات العملية، الأدوات، المدخلات، مصادر التقييم، الاستشارات الفنية، حدود العملية، التغييرات عن الدورة السابقة |
| **2. سياق المنظمة وسلسلة القيمة** | الأنشطة، المنتجات، المواقع، الدول، الأنشطة Upstream/Downstream، العلاقات التجارية |
| **3. أصحاب المصلحة** | الفئات، أساس تحديدها، أسلوب ودورية المشاركة، الموضوعات والمخاوف المطروحة، كيف أثرت في النتائج |
| **4. سجل التأثيرات (Impact Register)** | جدول 2.2 |
| **5. منهجية التقييم** | مقاييس Scale / Scope / Irremediable character / Likelihood، وقاعدة تقدم **الخطورة على الاحتمال** في تأثيرات حقوق الإنسان |
| **6. الحد الفاصل (Threshold)** | القيمة، أساس اختيارها، تحليل الحساسية (± خطوة واحدة) |
| **7. الموضوعات الجوهرية** | القائمة النهائية + الترتيب + التأثيرات المكوِّنة لكل موضوع + الإفصاحات المرتبطة |
| **8. الموضوعات المستبعدة** | مع سبب الاستبعاد الموثق |
| **9. موضوعات Sector Standard غير الجوهرية** | القائمة + التفسير — **تُنقل حرفيًا إلى Content Index** |
| **10. الحوكمة والاعتماد** | المُعِد، المراجع، المعتمد، دور أعلى جهة حوكمة، تاريخ الاعتماد، محضر/قرار مرجعي |
| **11. المقارنة بالدورة السابقة** | Added / Removed / Re-ranked / Merged / Split + سبب كل تغيير |
| **12. الملاحق** | الأدلة، قوائم الحضور، نتائج الاستبيانات، مراجع خارجية |

## 2.2 جدول سجل التأثيرات (يُولَّد من `esg_impacts`)

`impact_id` · `impact_description` · `actual/potential` · `positive/negative` · `own operations / business relationship` · `value_chain_position` (Upstream / Own / Downstream) · `affected_stakeholders` · `human_rights_related (Y/N)` · `right_affected` · `scale` · `scope` · `irremediable_character` · `likelihood` · `severity_score` · `priority_score` · `above_threshold (Y/N)` · `mapped_material_topic` · `source_of_assessment` · `evidence_ref` · `internal_owner` · `assessment_date` · `reviewer` · `decision` (Included / Excluded) · `decision_rationale`

## 2.3 قواعد عمل

- **BR-MAT-01:** لا يُسمح باعتماد موضوع جوهري غير مرتبط بتأثير واحد على الأقل في `esg_impacts`.
- **BR-MAT-02:** أي تأثير على حقوق الإنسان بخطورة عالية لا يُستبعد بسبب انخفاض الاحتمال إلا بقرار موثق ومعتمد على مستوى الحوكمة.
- **BR-MAT-03:** نتائج استبيان أصحاب المصلحة تُخزَّن كـ **مدخل واحد** (`input_weight`) ولا يجوز أن تكون المحدد الوحيد للترتيب.
- **BR-MAT-04:** التقرير لا يُصدَّر بحالة `Approved` قبل تسجيل `approved_by` من دور Executive Approver.
- **BR-MAT-05:** كل تعديل بعد الاعتماد يفتح إصدارًا جديدًا مع Change Log مقارن.

---

# 3. OUT-03 — GRI Content Index

> هذا أعلى المخرجات خطورة من ناحية الامتثال؛ أي خطأ فيه يُبطل ادعاء "in accordance". يجب برمجته كـ **محرك قواعد** لا كقالب.

## 3.1 الوضعان (Modes)

| Mode | الشرط | بيان الاستخدام |
|---|---|---|
| **A — In accordance** | اجتياز المتطلبات التسعة كلها | `[Name of organization] has reported in accordance with the GRI Standards for the period [start] to [end].` |
| **B — With reference** | استيفاء ثلاثة متطلبات فقط: نشر Content Index + بيان الاستخدام + إخطار GRI | `[Name of organization] has reported the information cited in this GRI content index for the period [start] to [end] with reference to the GRI Standards.` |

النص أعلاه **قالب إلزامي مقفل (locked template)**؛ يملأ النظام الاسم القانوني والتواريخ فقط، ولا يُتاح تحريره للمستخدم.

## 3.2 الترويسة (Header Block) — Mode A

| الحقل | المصدر |
|---|---|
| العنوان: `GRI content index` | ثابت |
| `Statement of use` | مولَّد آليًا حسب Mode |
| `GRI 1 used` | `GRI 1: Foundation 2021` (الرقم + الاسم + سنة النشر من `gri_standard_versions`) |
| `Applicable GRI Sector Standard(s)` | من `gri_sector_topics` — العنوان الكامل بسنة النشر |

## 3.3 الجدول الرئيسي — Mode A (الأعمدة بالترتيب)

| العمود | القاعدة |
|---|---|
| `GRI STANDARD / OTHER SOURCE` | العنوان الكامل بسنة النشر (مثال: `GRI 303: Water and Effluents 2018`) |
| `DISCLOSURE` | الرقم + الاسم الكامل (مثال: `2-6 Activities, value chain and other business relationships`) |
| `LOCATION` | رقم/أرقام الصفحات أو الروابط — **إجباري لكل إفصاح مُبلَّغ**؛ إذا توزعت المعلومة على عدة مواضع تُذكر جميعها |
| `OMISSION → REQUIREMENT(S) OMITTED` | المتطلب الفرعي المحذوف تحديدًا |
| `OMISSION → REASON` | من القائمة المغلقة (4 أسباب فقط) |
| `OMISSION → EXPLANATION` | نص إلزامي حسب نوع السبب |
| `GRI SECTOR STANDARD REF. NO.` | المعرّف الفريد للإفصاح في معيار القطاع (نمط `Sxx.y.z`) |

**كتلة إضافية إلزامية أسفل الجدول:**
`Topics in the applicable GRI Sector Standards determined as not material` بعمودين: `TOPIC` | `EXPLANATION` — تُملأ آليًا من OUT-02 قسم 9.

## 3.4 الجدول — Mode B

ثلاثة أعمدة فقط: `GRI STANDARD` | `DISCLOSURE` | `LOCATION` (بدون أعمدة الحذف ولا مرجع معيار القطاع).

## 3.5 قواعد العمل (Business Rules) — إلزامية التنفيذ

| ID | القاعدة |
|---|---|
| `BR-CI-01` | أسباب الحذف مسموحة لجميع الإفصاحات **باستثناء**: 2-1، 2-2، 2-3، 2-4، 2-5، 3-1، 3-2 — يجب حجب خيار الحذف تقنيًا على هذه السبعة |
| `BR-CI-02` | داخل GRI 3، الحذف مسموح لإفصاح 3-3 فقط |
| `BR-CI-03` | الأسباب المسموحة أربعة فقط ولا يُقبل نص حر: `Not applicable` / `Legal prohibitions` / `Confidentiality constraints` / `Information unavailable / incomplete` |
| `BR-CI-04` | حقول التفسير الإلزامية حسب السبب: <br>• Not applicable → سبب عدم الانطباق <br>• Legal prohibitions → وصف الحظر القانوني المحدد <br>• Confidentiality constraints → وصف قيد السرية المحدد <br>• Information unavailable/incomplete → تحديد المعلومة/الجزء الناقص + الكيانات أو المواقع المعنية + سبب عدم التوافر + **الخطوات المتخذة والإطار الزمني المتوقع** |
| `BR-CI-05` | خلايا الحذف ومرجع معيار القطاع تُعرض "رمادية/غير منطبقة" للصفوف التي لا تنطبق عليها، ولا تُترك فارغة بلا دلالة |
| `BR-CI-06` | لا يُكتب محتوى الإفصاح داخل الفهرس؛ الفهرس يدل على الموقع فقط (استثناءات محدودة جدًا مثل بيان الفترة أو الإفادة بعدم وجود بند) |
| `BR-CI-07` | كل موضوع جوهري يظهر ككتلة مستقلة تبدأ بـ 3-3 ثم إفصاحات الموضوع |
| `BR-CI-08` | إفصاحات Topic Standards المدرجة في معيار القطاع لموضوع جوهري ولم تُبلَّغ → تُدرج بسبب `Not applicable` + تفسير عدم الصلة بالتأثيرات |
| `BR-CI-09` | الإفصاحات القطاعية الإضافية (Additional sector disclosures) توصية؛ لا يُطلب سبب حذف لها، وتُدرج فقط إذا بُلِّغت |
| `BR-CI-10` | أي معلومات إضافية (ربط SDG/ESRS/ISSB) تُوضع في **أعمدة إضافية بعد الأعمدة المطلوبة** ولا تُدرج داخلها |
| `BR-CI-11` | منع التوليد النهائي إذا: إفصاح بحالة `Approved` بدون `location`، أو حذف بدون تفسير مكتمل، أو موضوع جوهري بلا 3-3، أو موضوع Sector غير مُقيَّم |
| `BR-CI-12` | تغيير Mode من B إلى A يعيد تشغيل بوابة المتطلبات التسعة (OUT-01 قسم A) بالكامل |

## 3.6 التصدير

- XLSX مطابق تخطيطيًا لقالب GRI الرسمي (وقالب مستخدمي معايير القطاعات المتاح منذ يناير 2026)، مع الحفاظ على ترتيب الأعمدة وأسماء الحقول.
- PDF/A للنشر، وHTML مع Anchors تربط كل صف بموقعه في التقرير.
- JSON للتكامل ولإعداد التوسيم المستقبلي (`esg_taxonomy_tags`).

---

# 4. OUT-04 — Sustainability Report Builder

| البند | التفصيل |
|---|---|
| **الغرض** | بناء التقرير من نفس قاعدة البيانات، بحيث يكون كل رقم في التقرير متتبعًا إلى Datapoint ودليل واعتماد |
| **القاعدة الأساسية** | **لا كتابة أرقام يدويًا في نص التقرير** — الأرقام تُدرج كـ Tokens مرتبطة (`{{DP:305-1.total.2025}}`) تُحدَّث آليًا وتُقفل عند النشر |

## 4.1 خريطة الأقسام والربط المعياري

| # | القسم | الربط الإلزامي |
|---|---|---|
| 1 | Executive message | 2-22 (بيان استراتيجية التنمية المستدامة) |
| 2 | About this report | 2-2، 2-3، 2-4، 2-5 + النطاق وأساس الإعداد |
| 3 | Organization profile | 2-1، 2-6، 2-7، 2-8 |
| 4 | Governance | 2-9 → 2-21 |
| 5 | Strategy, policies and practices | 2-22 → 2-28 |
| 6 | Stakeholder engagement | 2-29، 2-30 + OUT-10 |
| 7 | Materiality | 3-1، 3-2 + ملخص OUT-02 |
| 8 | Environmental performance | 3-3 + Topic Standards البيئية |
| 9 | Social performance | 3-3 + Topic Standards الاجتماعية |
| 10 | Governance & economic impacts | 3-3 + Topic Standards الاقتصادية |
| 11 | Targets and progress | `esg_targets` + OUT-11 |
| 12 | GRI Content Index | OUT-03 (مضمّن أو برابط) |
| 13 | Assurance statement | مرفوع من جهة التحقق المستقلة — **لا يولده النظام** |

## 4.2 متطلبات وظيفية

- كتل محتوى (Content Blocks) لكل إفصاح بحالة تحرير مستقلة: `Draft → Reviewed → Approved → Locked`.
- مؤشر تغطية: أي إفصاح معتمد غير مُدرج في أي قسم يُرفع كـ `GAP-DISC` في OUT-01.
- **تعبئة عكسية آلية:** بعد ترقيم الصفحات/الروابط، يُحدَّث عمود `LOCATION` في OUT-03 تلقائيًا (لا إدخال يدوي).
- ترقيم آلي للجداول والأشكال، وقائمة اختصارات، ومسرد ثنائي اللغة.
- سجل تحرير كامل (من غيّر، ماذا، متى)، ومقارنة إصدارات (Redline).
- تصدير: DOCX (تحريري) + PDF/A (نهائي) + HTML متجاوب.

---

# 5. OUT-05 — Management Dashboard

## 5.1 مؤشرات لوحة القيادة والمعادلات الملزمة

| KPI | المعادلة | التجميع |
|---|---|---|
| Disclosure Completion Score | الإفصاحات بحالة `Approved` ÷ الإفصاحات المنطبقة × 100 | كلي / معيار / موضوع / إدارة |
| Department Completion | الإفصاحات المعتمدة للإدارة ÷ المسندة إليها × 100 | إدارة / موقع |
| Overdue Disclosures | عدد الطلبات التي تجاوز `due_date` وحالتها ≠ Approved | إدارة / مسؤول |
| Evidence Coverage Score | نقاط البيانات المرتبطة بدليل صالح ÷ النقاط التي تتطلب دليلًا × 100 | كلي / موضوع |
| Data Quality Score | متوسط مرجّح لأبعاد: Completeness، Accuracy، Consistency، Timeliness، Traceability، Verifiability (أوزان يحددها خبير ESG) | نقطة بيانات / موضوع |
| Review Progress Score | النقاط المغلقة والمعتمدة ÷ الإجمالي × 100 | مرحلة المراجعة |
| Open Findings & Aging | عدد الملاحظات المفتوحة + متوسط العمر بالأيام + الأقدم | الخطورة / المسؤول |
| Target Performance Score | (القيمة الحالية − خط الأساس) ÷ (المستهدف − خط الأساس) × 100 | هدف / موضوع |
| YoY Variance | (الفترة الحالية − السابقة) ÷ السابقة × 100 مع تعليم تجاوز Threshold | مؤشر / موقع |
| Estimation Ratio | البيانات المقدَّرة ÷ إجمالي البيانات × 100 | مؤشر / موضوع |
| High-Severity Topics | الموضوعات المرتبطة بتأثيرات فوق حد الخطورة أو بحقوق الإنسان | موضوع |

## 5.2 قواعد العرض

- كل مؤشر قابل للتنقيب (Drill-down) حتى مستوى `datapoint → evidence → user → timestamp`.
- عرض **صريح** لتاريخ ووقت آخر تحديث ونطاق البيانات المعروضة.
- لوحة مقيدة بالدور: الموظف يرى مهامه فقط؛ مدير الإدارة يرى إدارته؛ ESG Manager يرى الكل؛ VVB يرى Read-only ضمن نطاق التأكيد.
- **لا يُعرض أي مؤشر تجميعي باسم يوحي بالتوافق مع GRI أو بتقييم من GRI.**

---

# 6. OUT-06 — Audit and Assurance Pack

| البند | التفصيل |
|---|---|
| **الغرض** | تمكين المراجع الداخلي وجهة التحقق المستقلة من إعادة تتبع أي رقم من التقرير إلى مصدره الأولي دون الرجوع إلى أفراد |
| **الجمهور** | Internal Audit، External Assurance Provider (VVB)، الإدارة العليا |
| **الوصول** | Read-only + كتابة الملاحظات فقط + تسجيل كامل لكل عملية اطلاع (Access Log) |

## 6.1 ملف نقطة البيانات (Datapoint Dossier)

لكل مؤشر داخل نطاق التأكيد:

`datapoint_id` · `disclosure_id` · `indicator_name` · `definition` · `reported_value` · `unit` · `calculation_formula` · `input_values` · `conversion_factors + source` · `emission/conversion factor version` · `estimation_flag + method + assumptions` · `uncertainty/accuracy_range` · `organizational & operational boundary` · `entity/site coverage` · `period_covered` · `data_source_system` · `evidence_refs[]` · `entered_by/at` · `reviewed_by/at` · `approved_by/at` · `change_log[]` · `prior_period_value` · `variance %` · `variance_explanation` · `restatement_flag + reference` · `assurance_scope (Y/N)` · `assurance_level (Limited / Reasonable)` · `linked_findings[]`

## 6.2 مكونات الحزمة (ZIP Structure)

```
/00_Manifest/            Manifest.csv (كل ملف + الحجم + SHA-256 + المصدر)
/01_Scope/               نطاق التأكيد، الحدود، الفترة، معايير الإعداد
/02_Datapoints/          Dossier لكل مؤشر (CSV + PDF)
/03_Calculations/        أوراق الحساب + عوامل التحويل + الأمثلة
/04_Evidence/            الأدلة مرتبة حسب Disclosure/Entity/Site
/05_Methodology/         المنهجية، قاموس البيانات، التقديرات، Restatements
/06_Workflow/            الاعتمادات، سجل التعديلات، سجل الاستفسارات والردود
/07_Findings/            سجل الملاحظات (مفتوحة/مغلقة) + أدلة الإغلاق
/08_ContentIndex/        OUT-03 النسخة المعتمدة
```

## 6.3 قواعد إلزامية

- **Immutability:** بعد قفل الفترة، أي تغيير يُنشئ إصدارًا جديدًا مع سبب موثق؛ لا تعديل صامت ولا حذف.
- **Evidence integrity:** لكل دليل: نوع، مُصدِر، تاريخ، فترة التغطية، الموقع، الحالة (سارٍ/مستبدل/منتهٍ)، SHA-256.
- **Query log:** كل استفسار من جهة التحقق يُسجَّل كـ `esg_assurance_findings` بحالة وتاريخ استحقاق ومسؤول رد.
- **الفصل:** النظام يمنع تقنيًا أي دور تحقق من تعديل بيانات أو أدلة أو اعتمادات.
- **بيان التأكيد:** يُرفع كملف موقّع من الجهة المستقلة؛ يخزنه النظام ويربطه بالإفصاح 2-5، ولا يولّده ولا يستنتج مستوى التأكيد آليًا.

---

# 7. مخرجات إلزامية ناقصة في القائمة الحالية (Recommended Additions)

القائمة الواردة في المتطلب 12 لا تكفي لإصدار تقرير قابل للتأكيد. يجب إضافة التالي:

| ID | المخرج | سبب الإلزام |
|---|---|---|
| `OUT-07` | **Omissions Register** | مبرر كل حذف بالتفصيل والاعتماد — الفهرس وحده لا يحمل الأدلة والاعتمادات |
| `OUT-08` | **Restatement Report** | الإفصاح 2-4 لا يقبل الحذف؛ يجب تقرير مستقل بالقيمة السابقة والجديدة والسبب والأثر |
| `OUT-09` | **Data Quality & Estimation Report** | إثبات تطبيق مبدأي Accuracy وVerifiability: ما القيم المقاسة، وما المقدَّرة، وبأي منهجية وحدود دقة |
| `OUT-10` | **Stakeholder Engagement Log** | يغذي 2-29 و2-30 ويثبت أن المشاركة حقيقية وليست شكلية |
| `OUT-11` | **Targets & Performance Report** | خط الأساس، المستهدف، الأداء، الانحراف، الإجراءات — مطلوب داخل 3-3 |
| `OUT-12` | **Reporting Principles Self-Assessment** | دليل الامتثال للمتطلب 1 (المبادئ الثمانية) — عادة أول ما يطلبه المراجع |
| `OUT-13` | **GRI Notification Record** | إثبات المتطلب 9 (إخطار GRI): تاريخ الإرسال، الجهة، بيان الاستخدام، رابط الفهرس |
| `OUT-14` | **Taxonomy Export Package** *(مرحلة تالية)* | حزمة موسومة تمهيدًا لـ XBRL/iXBRL وفق GRI Sustainability Taxonomy |

> ملاحظة تصميمية: أضف `esg_taxonomy_tags` إلى نموذج البيانات من الآن حتى لو لم يُفعَّل في الـMVP؛ إضافته لاحقًا تعني إعادة هيكلة.

---

# 8. مصفوفة الربط (Output × Source × Trigger × Access)

| Output | المصادر الرئيسية | التشغيل | الوصول |
|---|---|---|---|
| OUT-01 Gap Analysis | كل جداول الإفصاح والأدلة والمراجعة | On-demand / أسبوعي / قبل القفل | ESG Manager, Dept Reviewer (نطاقه) |
| OUT-02 Materiality | `esg_impacts`, `esg_material_topics`, `esg_engagements` | عند اعتماد الموضوعات | ESG Manager, Executive Approver, VVB (RO) |
| OUT-03 Content Index | `gri_*`, `esg_datapoints`, `esg_omissions`, `esg_content_index` | قبل النشر + عند أي تغيير معتمد | ESG Manager, Executive Approver |
| OUT-04 Report Builder | كل ما سبق + `esg_report_sections` | مستمر | ESG Manager, Editors |
| OUT-05 Dashboard | مجمّع | فوري (Near real-time) | حسب الدور |
| OUT-06 Assurance Pack | كل ما سبق + `esg_audit_log` | عند بدء التأكيد + عند الإغلاق | VVB (RO), Internal Audit |
| OUT-07 → OUT-13 | حسب الجدول | حسب المرحلة | حسب الدور |

---

# 9. معايير القبول واختبارات التسليم (Acceptance Criteria & UAT)

لا يُقبل تسليم المتطلب 12 إلا باجتياز الحالات التالية على النموذج التجريبي (شركة متعددة المواقع، دورة كاملة، 15–20 تأثيرًا، 5–8 موضوعات جوهرية):

| ID | حالة الاختبار | النتيجة المتوقعة |
|---|---|---|
| `TC-01` | محاولة استخدام سبب حذف لإفصاح 2-3 | رفض النظام + رسالة تفسيرية + عدم إمكانية التجاوز |
| `TC-02` | حذف بسبب `Information unavailable` دون خطة وإطار زمني | منع الحفظ + فجوة Blocking في OUT-01 |
| `TC-03` | موضوع جوهري بلا 3-3 | منع توليد OUT-03 |
| `TC-04` | موضوع في معيار القطاع غير مُقيَّم | منع Mode A + إدراجه في تقرير الفجوات |
| `TC-05` | قيمة طاقة متجددة > إجمالي الطاقة | إخفاق قاعدة تحقق + فجوة Major |
| `TC-06` | انحراف 60% عن السنة السابقة | طلب تفسير إلزامي قبل الاعتماد |
| `TC-07` | تعديل قيمة بعد الاعتماد | إصدار جديد + سجل تعديل + إشعار للمراجع |
| `TC-08` | محاولة VVB تعديل قيمة | رفض + تسجيل المحاولة في `esg_audit_log` |
| `TC-09` | تغيير ترقيم صفحات التقرير | تحديث آلي لعمود Location في OUT-03 |
| `TC-10` | إعادة توليد OUT-03 بعد 6 أشهر بنفس نقطة القطع | نفس الملف بالضبط (نفس Checksum للمحتوى) |
| `TC-11` | تصدير عربي/إنجليزي | تطابق الهيكل والقيم؛ عناوين GRI بالإنجليزية |
| `TC-12` | محاولة نشر مع فجوة Blocking واحدة | منع النشر + تقرير أسباب المنع |

---

# 10. ملاحظة الحياد (Impartiality Statement — تُدرج في وثيقة المشروع)

إعداد البيانات والتقرير نشاط استشاري، والتحقق منها نشاط مستقل. يجب أن يفرض الموديول هذا الفصل **تقنيًا** لا تنظيميًا فقط: صلاحيات منفصلة، سجل وصول، ومنع أي دور تحقق من التعديل أو الاعتماد. أي مخرج يوحي بأن الجهة التي أعدت البيانات قد أكّدتها يُعد إخلالًا بالحياد ويجب منعه على مستوى النظام.

---

## المراجع

1. GRI 1: Foundation 2021 — Requirements 1–9، Table 1 (Permitted reasons for omission)، Appendix 1 & 2 (Content index) — https://www.globalreporting.org/publications/documents/english/gri-1-foundation-2021/
2. GRI 2: General Disclosures 2021 — https://www.globalreporting.org/publications/documents/english/gri-2-general-disclosures-2021/
3. GRI 3: Material Topics 2021 — https://www.globalreporting.org/publications/documents/english/gri-3-material-topics-2021/
4. GRI Content Index Template (incl. dedicated Sector Standards template, available since January 2026) — https://www.globalreporting.org/reporting-support/reporting-tools/content-index-template/
5. GRI Sustainability Taxonomy — https://www.globalreporting.org/standards/gri-sustainability-taxonomy/
6. GRI Trademarks and Copyright Policy — https://www.globalreporting.org/copyright/
7. ISO/IEC 17029:2019; ISO 14064-3:2019 — لأنشطة التحقق والمصادقة ضمن النطاق
