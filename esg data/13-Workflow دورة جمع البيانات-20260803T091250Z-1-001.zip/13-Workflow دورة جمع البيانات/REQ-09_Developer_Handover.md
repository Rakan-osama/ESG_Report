# REQ-09 — Developer Handover Note
## ESG Intelligence & GRI Digital Reporting Module — Workflow Engine

| | |
|---|---|
| **Deliverable** | REQ-09 — Data collection, review and approval workflow |
| **Version** | 1.0 — Draft for ESG Domain Owner sign-off |
| **Date** | 25 July 2026 |
| **Methodology owner** | ESG/GRI Technical Domain Lead |
| **Implementation owner** | Software Development Lead |
| **Companion files** | `REQ-09_ESG_GRI_Workflow_Specification_v1.0.xlsx` (20 sheets) · `REQ-09_workflow_engine_config.json` (machine-readable) |
| **Normative basis** | GRI 1: Foundation 2021 (effective 1 January 2023), Sections 3–4 and Appendix 1; GRI 2: General Disclosures 2021; GRI 3: Material Topics 2021 |

> **ملخص تنفيذي:** هذا الملف هو الجزء البرمجي من المتطلب التاسع. الاختصاصات موزعة كالتالي: خبير الـESG يملك المنهجية والقواعد، والمطور يملك التنفيذ فقط. القواعد الواردة هنا **حاجبة (Blocking)** ولا تُنفَّذ كتنبيهات في الواجهة. أي قاعدة تُطبَّق في الـUI فقط تُعتبر غير منفذة.

---

## 1. Architecture principle

The workflow is **configuration-driven, not code-driven**. States, transitions, guards, gates and omission rules live in database tables loaded from `REQ-09_workflow_engine_config.json`. GRI updates its Standards regularly; a methodology change must be a configuration change, never a redeployment.

```
esg_workflow_states        <- sheets 02, 03, 04
esg_workflow_transitions   <- sheet 05  (guard_expression stored as evaluable text)
esg_workflow_gates         <- sheet 07
esg_claim_rules            <- sheet 08
esg_omission_rules         <- sheets 09, 10
esg_validation_rules       <- Validation Catalogue (separate deliverable)
```

**Three-layer enforcement.** Every rule below must be enforced at all three layers. UI-only enforcement is treated as a defect, not a partial implementation:

| Layer | Purpose |
|---|---|
| Database | Constraints and triggers — the last line of defence (`reason_code` CHECK constraint, append-only audit log, immutability on locked records) |
| API / service | Guard evaluation before any state change; returns structured rejection with the failed guard ID |
| UI | Prevents the user from attempting an invalid action and displays the guard message |

---

## 2. State machine contract

Disclosure state is **derived, never assigned**. The service layer computes it from subordinate objects:

```
computeDisclosureState(d):
    if d.scoped_out                                  -> "Out of Scope"
    if omission(d).state == "Approved"               -> "Omission Approved"
    if any(datapoint.state == "Empty" and mandatory) -> "In Progress" | "Data Requested"
    if all(datapoint.state in ("Submitted","Validated","Item Does Not Exist"))
                                                     -> "Submitted"
    ... continues through review, assurance and lock states
```

A single writable `state` column that any endpoint can set will fail assurance. The only permitted writes are through `applyTransition(trn_id)`.

```
applyTransition(object, trn_id, actor):
    trn = config.transitions[trn_id]
    assert object.state == trn.from                  -> ERR_INVALID_SOURCE_STATE
    assert actor.role in trn.actor_role              -> ERR_ROLE_NOT_PERMITTED
    for g in trn.guards:
        if not evaluate(g.expression, context):
            reject(g.id, g.message)                  -> HTTP 422 with guard payload
    persist(object.state = trn.to)
    writeAudit(trn.audit_event, from, to, actor, justification?)
    dispatch(trn.notify)
```

---

## 3. Non-negotiable controls

These eight controls are the difference between a reporting tool and an auditable system. Each maps to a Critical test case in sheet 17.

### 3.1 Segregation of duties — enforced on `user_id`, not on role

```
assert submitter.user_id != reviewer.user_id          # SOD-01
assert reviewer.user_id != disclosure.data_owner_id   # SOD-02
assert etr.user_id not in (submitter, dept_reviewer)  # SOD-03
assert provider.write_permissions == NONE             # SOD-04
assert provider_entity_id != preparer_entity_id       # SOD-06  <-- impartiality
```

SOD-06 is the control that protects group structures where advisory and verification capabilities coexist. The preparing legal entity must not be registrable as the assurance provider for the same cycle. GRI expects the assurance provider to be independent of the organization and able to reach impartial conclusions; the system must make the conflict impossible rather than rely on policy.

Override (SOD-08) is permitted only for small organizations, requires executive approval, and is **printed permanently in the audit pack**. A hidden override is worse than no override.

### 3.2 Omission control

```
POST /omissions
  reject if disclosure_ref in ["2-1","2-2","2-3","2-4","2-5","3-1","3-2"]
         -> OMISSION_NOT_PERMITTED
  reject if reason_code not in ["RFO-01","RFO-02","RFO-03","RFO-04"]
         -> ONLY_FOUR_REASONS_PERMITTED
  reject if requirement_ref is null
         -> REQUIREMENT_LEVEL_REFERENCE_REQUIRED
  if reason_code == "RFO-04":
     require missing_scope, reason_why, steps_taken, expected_date
     auto-create action plan owned by the Data Owner, carried into the next cycle
  on approve: assert approver != requester
              write row into esg_content_index (non-optional)
```

**The single most common implementation error:** treating "the organization has no such committee/policy/process" as an omission. It is not. Reporting that the item does not exist is a **compliant answer** and must follow `TRN-D22`, count as complete, and write nothing to the omission register. Two visibly different paths in the UI, two different tables in the database.

### 3.3 Claim engine — `in accordance` is computed, never chosen

```
evaluateClaim(cycle) -> "IN_ACCORDANCE" | "WITH_REFERENCE" | "BLOCKED"
    checks = [CE-1 .. CE-9]                  # the nine requirements
    controls = [CE-X1, CE-X2, CE-X3]         # integrity and prohibited-claim controls
    if all(checks) and all(controls): return IN_ACCORDANCE
    if content_index_valid and statement_present and gri_notified: return WITH_REFERENCE
    return BLOCKED
```

The statement of use is generated from the result with the exact prescribed wording, legal name and period dates inserted. The user never selects it. A dropdown offering "in accordance" is a compliance defect.

`CE-X3` scans the generated report and the UI for prohibited claim patterns (`GRI certified`, `GRI rating`, `certified by GRI`, and the Arabic equivalents). GRI does not audit, certify or validate reports; the product must never imply otherwise.

### 3.4 Requirement 9 — notify GRI

Publication may proceed, but **period lock (G7) is blocked** until the notification evidence is stored: date sent, recipient address `reportregistration@globalreporting.org`, and the payload (legal name, content index link, report link, statement of use, contact person). This step is missing from most implementations and is a direct in-accordance requirement.

### 3.5 Evidence freeze and immutability

At gate G4 the service creates a hash-stamped baseline snapshot and switches the cycle to read-only. From that point:

- all write endpoints on data tables return `ERR_CYCLE_FROZEN`;
- reopening is scoped — only disclosures carrying an open finding become editable (`TRN-C07`), everything else stays frozen;
- after lock, **no edit path exists at all**. Corrections go through restatement (`TRN-D20`), which creates version *n+1* and sets version *n* to `Superseded` while keeping it fully retrievable.

### 3.6 Audit log

Append-only at database level: `INSERT` only, no `UPDATE`, no `DELETE`. Each record carries `transition_id`, `role_at_time`, `entity_of_user`, a chained `hash`, and a mandatory `justification` for overrides, post-approval changes and cycle reopening. The log must be exportable per cycle as a read-only file for the assurance provider — this is the practical expression of the verifiability principle, which expects information systems to be designed so they can be examined as part of an external assurance process.

### 3.7 AI assistance boundary

Every AI-generated output carries a status chain: `AI Suggested → Human Reviewed → Accepted | Rejected | Modified`. Publication is blocked while any narrative remains at `AI Suggested`. AI may draft, extract, compare and flag; it may never approve an omission, conclude on conformance, or publish.

### 3.8 Standards versioning

The cycle freezes a Standards snapshot at G1. A mid-cycle GRI update applies to the **next** cycle unless early adoption is explicitly approved and recorded (`EX-14`). Sector Standard lists must be data, never hard-coded — the sector programme is still expanding and standards under development will be published during the product's life.

---

## 4. Build sequence

| Sprint | Scope | Exit criterion |
|---|---|---|
| 1 | Config tables, state machine service, `applyTransition`, audit log | TC-42, TC-43 pass |
| 2 | Cycle setup, scoping, roles, SOD engine, gates G0–G1 | TC-01, TC-02, TC-16, TC-17 pass |
| 3 | Impact register, materiality, sector topic decisions, gate G2 | TC-05 to TC-08 pass |
| 4 | Data requests, entry, evidence, validation levels 1–3 | TC-09 to TC-14 pass |
| 5 | Omission engine, blocked list, content index sync | TC-19 to TC-27 pass |
| 6 | Review chain, freeze, assurance workspace, findings | TC-28 to TC-31 pass |
| 7 | Claim engine, content index, statement of use, publication | TC-32 to TC-36 pass |
| 8 | Lock, restatement, erratum, GRI notification | TC-33, TC-37 to TC-41 pass |

---

## 5. Acceptance conditions

The module is not accepted until:

1. All **Critical** test cases in sheet 17 pass — no exceptions, no deferrals.
2. All twelve open items in sheet 19 are closed by the ESG Domain Owner. Sprints 3, 4 and 5 cannot start on the affected components while OI-01 to OI-06 remain open.
3. A full end-to-end dry run is completed on the sample company dataset (multi-site, one incomplete disclosure, one approved omission, one deliberately invalid value, one post-review correction, one assurance finding, a final content index and a trial report).
4. The ESG Domain Owner signs the UAT record and accepts technical responsibility for the interpretation of GRI requirements. The development team is not responsible for methodology.

---

## 6. Two conditions that sit outside the code

**Licensing.** GRI Standards content — disclosure titles, requirements and guidance text — is copyright protected. Embedding it in a commercial product requires prior licensing from GRI through its software and tools programme. Decide the route (internal tool vs commercial SaaS) before sprint 1, because it determines whether the Standards library stores full text or references only. This is open item OI-12.

**Claims.** Nothing in the product — UI, report, dashboard, marketing material — may state or imply GRI certification, approval, rating or endorsement. `CE-X3` enforces this inside the product; a parallel review is needed for anything customer-facing outside it.

---

*Source of normative requirements: GRI 1: Foundation 2021, https://www.globalreporting.org/publications/documents/english/gri-1-foundation-2021/*
