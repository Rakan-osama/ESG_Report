
## v18.0.0 — v4 Premium Operational Experience (2026-08-03)

Merge release executed per the v18 directive: v4 premium design remains the visual authority; the v17.1 operational core remains the data/workflow/RBAC/evidence/calculation/materiality/GRI/gates/audit authority. v4.3 was rejected as an operational baseline and retained only as a visual reference.

### Added
- Startup-mode chooser on first login: **Empty First-Use Mode** (no demo records, steps, evidence, calculations or claim; first action = Create Organization & Reporting Cycle, routed to My Organization with replace-data pre-selected) and **Demo/Sandbox Mode**.
- Permanent demo banner: "DEMO DATA — NOT CLIENT DATA — NOT FOR REPORTING OR ASSURANCE" with **Reset Demo Data** (deletes IndexedDB working set + preferences and restores the labelled sandbox) and **Start my organization**.
- Empty-workspace banner until the tenant creates its own organization.
- Ctrl/Cmd + K now focuses the global search input.
- `source/extension-v18.{js,css}`, `source/build_v18.py`, `qa/run_v18_qa.js` (Node/jsdom harness).

### Fixed (engine)
- **VR-DUP-001 escalated ERROR → BLOCKER** (`source/data/library.js`, `registries/validation-rules.json`). A record sharing the full dimensional key (activity + site + period, non-superseded) can be drafted but can no longer pass the VALIDATED/SUBMITTED gate. Completes P0-03: duplicates are now blocked, not merely flagged.

### QA
- 100/100 steps pass across boot/login/demo mode, the full domain end-to-end executed twice, and empty first-use; **QA_STATE_MUTATION_COUNT = 0**.

## v18.2.0 — Corrected Premium Operational Baseline (2026-08-03)

Selective merge executed per directive: the v18.1 review corrections were merged INTO the full v18.0/v17.1 engine as improvements — not as a replacement. All 18 operational modules (records, workflow, RBAC/SoD, evidence, calculations, materiality, GRI, gates, audit, journey, tenant, principles, units, translations) remain intact and unreduced.

### Fixed (engine)
- **P0-2** `Records.duplicateOf()` now compares the canonical full dimensional business key: tenant + organization + cycle + activity + entity + site + ISO period + NFC/trim/case-normalized, key-sorted dimension values. Record id and version are excluded; SUPERSEDED and frozen version copies are excluded. Two meters at the same site/month are now two valid records; only a true full-key duplicate is blocked (VR-DUP-001, still BLOCKER).
- **P0-3** Empty First-Use is truly empty: client tenants hydrate with pending organization/cycle sentinels, zero records/evidence/impacts/topics/findings, GRI 2 = MISSING, no claim. `GRI.evaluateClaim`, `GRI.contentIndex` and `Gates.reEvaluate` return `NOT_EVALUATED / PRECONDITION_ORG_CYCLE` until the organization and cycle exist. Every screen except My Organization and Expert Specification renders a NO_ORGANIZATION precondition card pre-setup; the rendered UI is verified to contain zero demo wording (Delta / FY2025 / demonstration).
- **P0-4** Real tenant isolation: each tenant persists in its own IndexedDB database (`cr10-esg-gri--TEN-EEG`, `cr10-esg-gri--TEN-CLIENT-XXXX`) with per-namespace preferences. Records, audit entries and the permission context carry the active namespace. Reset Demo Data deletes only the demo namespace. Nothing migrates between tenants.
- Reporting-cycle save now guarantees `publicationTarget` and clears the pending flag.

### Fixed (package · P0-5/P0-6)
- `package.json` 18.2.0 with pinned `jsdom` devDependency and `package-lock.json`; `npm test` runs the v18.2 QA against the v18.2 HTML.
- `qa/verify_integrity.py` re-hashes the full tree against `SHA256SUMS.txt` and fails on any mismatch, missing or unlisted file. Manifest and sums are generated as the final build step.
- Version hygiene: exactly one runnable HTML at root (v18.2); v17.1 and v18.0 HTMLs moved to `archive/reference/` with a superseded note; single classification across all documents.

### Changed (UX)
- Demo/empty banner is now a top strip under no content (topbar and sidebar offset beneath it), collapsible to a compact DEMO/SETUP pill; ≤48px expanded on ≤430px viewports. Full warning text remains reachable at all times.

### QA
- 124/124 steps pass (boot/demo/banner-collapse, full domain e2e ×2, canonical-key proofs: meter A/B allowed · identical key blocked · normalization detected · superseded freed, isolated empty client tenant incl. rendered-UI demo-text scan, precondition guards lift after real org+cycle, cross-tenant refusal). QA_STATE_MUTATION_COUNT = 0.


## v18.3.0 — Sealed Operational Baseline (2026-08-03)

Closes all six P1 findings from the independent v18.2 review; engine unreduced.

- **P1-1 ID collisions after reload:** `App.nextId` now derives its floor from every object
  collection (incl. legal entities and sites) plus a persisted per-namespace counter
  (`cr10.seq--<NS>`). Reproduced reviewer case (second `LE-9001`) is impossible; proven in QA.
- **P1-2 Business key completeness:** `datapointId` added to the canonical key; per-dimension
  `caseSensitive` definitions honoured via `App.Data.dimensionDefinitions`; period dates parsed
  and re-emitted as ISO (invalid dates key as null). Identifier ids stay case-exact by design.
- **P1-3 Tests vs. sealed hashes:** QA reports now write to `qa/output/` (excluded from
  FILE_MANIFEST/SHA256SUMS and from verify_integrity). `npm test` → `verify_integrity` passes.
- **P1-4 Browser QA target:** run_domain_e2e / run_ui_qa / generate_screenshots / run_all all
  open the v18.3 HTML; `package.json` gains `test:browser` + `screenshots`; `qa/requirements.txt`
  pins playwright 1.54.1.
- **P1-5 Cross-OS hash stability:** the build writes LF-only bytes, so the standalone SHA-256 is
  identical on Windows/macOS/Linux; npm scripts call portable `python`.
- **P1-6 Document coherence:** FINAL_REPORT and all documentation now state v18.3 with the single
  RC classification.
- QA extended to 136 steps (ID-generator proofs, datapointId key, case-sensitive dimension
  definitions, short-date normalization). 136/136 × 2 runs, QA_STATE_MUTATION_COUNT = 0.
