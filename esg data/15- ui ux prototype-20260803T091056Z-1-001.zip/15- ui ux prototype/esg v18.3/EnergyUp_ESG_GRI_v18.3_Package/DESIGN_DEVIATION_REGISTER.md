
## v18.0 deviations

| ID | Deviation | Reason | Disposition |
|---|---|---|---|
| DEV-18-01 | No screenshot set and no Playwright browser UI QA in this build | Chromium/Playwright unavailable in the build sandbox (network allowlist blocks browser download) | jsdom harness (`qa/run_v18_qa.js`) executes the same domain assertions headlessly; screenshot suite (`qa/generate_screenshots.py`) ships ready to run in any environment with Chromium |
| DEV-18-02 | The 9-item "daily navigation" IA from the v18 spec is not applied; the approved v4 sidebar + My Path / My Organization / Output / Expert Specification entries remain | The v4 sidebar is the approved design authority; replacing its IA is a design change requiring UX sign-off | Deferred to v18.1 behind explicit sign-off; Expert Specification already role-gated |
| DEV-18-03 | Manual 27-step first-time-user test not executed | Requires a human tester and a real browser | Script preserved in the specification; to be executed at UAT |


## v18.2 dispositions

| ID | Deviation | Disposition |
|---|---|---|
| DEV-18-01 | No browser screenshot suite in build sandbox | STILL OPEN — `qa` harness is jsdom; screenshot tooling ships ready for any Chromium environment |
| DEV-18-02 | 9-item daily navigation IA | STILL DEFERRED to UX sign-off; current nav = approved v4 sidebar + My Path / My Organization / Output / Expert |
| DEV-18-03 | Manual 27-step user journey | STILL OPEN — requires human tester + browser |
| DEV-18-04 | v4.3 design conformance (reviewer P0-1) | CLOSED HONESTLY: no v4.3 file exists in this repository; all documents now state the visual authority as "v4 Premium (v4.1 FIXED base)" and no v4.3 claim is made anywhere |
