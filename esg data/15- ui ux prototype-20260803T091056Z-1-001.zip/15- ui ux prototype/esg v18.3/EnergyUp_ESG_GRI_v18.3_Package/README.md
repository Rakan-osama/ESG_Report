# EnergyUp ESG & GRI — v18.3.0 · Sealed Operational Baseline

**Single entry point:** open `EnergyUp_ESG_GRI_v18.3_Sealed_Operational_Baseline.html` in Chrome/Edge/Chromium.
Superseded builds (v17.1, v18.0) live in `archive/reference/` for comparison only.

## What this release is
The full v17.1 operational engine (multi-record workflow with RETURNED/REOPENED, centralized RBAC + SoD,
evidence versioning & supersession, factor-gated calculation engine, impact-based materiality with the
human-rights override, GRI nine-requirement claim engine with omission blocking, 15 publication gates,
append-audit, guided journey, 117-screen Expert Specification) — **plus** the v18.1 review corrections
merged in as improvements, not replacements:

- **Canonical duplicate key (P0-2):** full dimensional business key (tenant, org, cycle, activity, entity,
  site, ISO period, normalized sorted dimensions). Two meters, same site & month = two valid records.
- **Truly empty first use (P0-3):** client tenants boot with no organization, no cycle, no data, no claim;
  claim/gates/content-index return `NOT_EVALUATED / PRECONDITION_ORG_CYCLE` until setup completes.
- **Real tenant isolation (P0-4):** per-tenant IndexedDB namespaces (`TEN-EEG` demo sandbox,
  `TEN-CLIENT-XXXX` client). Reset Demo touches only the demo namespace.
- **Reproducible QA & integrity (P0-5/6):** `npm ci && npm test` (jsdom, 136 steps, run twice,
  `QA_STATE_MUTATION_COUNT = 0`) and `python qa/verify_integrity.py` (full-tree SHA-256).
- **Mobile-safe demo banner:** top strip, collapsible to a DEMO pill, ≤48px on phones.

## Reproduce
```
npm ci
npm test
python qa/verify_integrity.py
python source/build_v18_3.py    # rebuild (LF-deterministic: same SHA-256 on every OS)
```

## Classification
**Release Candidate — Corrections Still Required.**
Open items: browser screenshot suite + manual 27-step user journey (need a real Chromium; tooling ships
ready), and the 9-item daily-navigation IA (deferred pending UX sign-off). Production still requires:
backend, PostgreSQL + FORCE RLS, server-side RBAC/SoD, object storage, immutable server audit,
server-side calculations, an approved factor library, real authentication, monitoring, backup, pen-test.

Visual authority: **v4 Premium (v4.1 FIXED base)**. No v4.3 file exists in this repository and no v4.3
conformance is claimed (see DESIGN_DEVIATION_REGISTER · DEV-18-04).

## Windows note
Scripts call `python` (works with the standard python.org installer). On systems with only
`python3`, either alias it or run the same files with `python3`. The build output is byte-identical
across operating systems (LF-only), so `standaloneSha256` in RELEASE_METADATA.json always matches.
