# Superseded references
- `EnergyUp_ESG_GRI_v17.1_v4_Live_Operational_Final.html` — prior approved operational baseline (engines carried forward into v18.2).
- `EnergyUp_ESG_GRI_v18.0_v4_Premium_Operational_Experience.html` — v18.0 release candidate, superseded by v18.2 corrections.
The single current entry point is `../../EnergyUp_ESG_GRI_v18.2_Corrected_Premium_Operational_Baseline.html`.
