# Frontend Architecture

## Build layers
1. **Approved v4.1 base** — visual shell, B–F navigation, components and responsive identity.
2. **Data registries** — 117 screens, 16 workspaces, 51 activities, 30 GRI 2 disclosures, roles, methods, factors, standards and gates.
3. **Domain modules** — state, audit, permissions, units, calculations, records, evidence, materiality, principles, GRI, gates, journey and tenant.
4. **v4 integration extension** — live Overview, My Path, My Organization, Output, Expert Specification and screen-specific live bindings.

## State and persistence
The standalone prototype uses IndexedDB for the working dataset and localStorage for lightweight preferences. Production must use server-side authoritative state.

## Security boundary
Client-side permissions are an executable specification only. Production authorization, tenant isolation, state transitions, approval version binding and audit immutability must be enforced in the API and PostgreSQL RLS.

## Build reproducibility
`source/build.py` reads only package-relative paths and regenerates the standalone artifact.
