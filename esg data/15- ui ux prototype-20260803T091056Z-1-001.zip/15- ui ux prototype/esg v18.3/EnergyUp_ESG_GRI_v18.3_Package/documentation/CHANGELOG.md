# Changelog

## v17.1.0 — Final v4 Live Operational Baseline
- Preserved v4.1 as the controlling interface and B–F navigation.
- Replaced the static Overview with live engine metrics and blockers.
- Bound all 66 v4 operational screens to live functions.
- Added My Path, My Organization, Output, and role-filtered Expert Specification.
- Confined the 117-screen scope to the technical registry.
- Added complete source modules and relative build process.
- Added reproducible UI and domain QA.
- Corrected LPG, natural-gas, energy, waste, safety, turnover, and anti-corruption calculation mappings.
- Isolated calculation self-tests from business calculation history.
- Corrected evidence digest statistics.
