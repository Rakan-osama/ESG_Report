# Design Deviation Register

| ID | Area | Reference | Implemented | Status | Rationale |
|---|---|---|---|---|---|
| DD-01 | Application shell | v4.1 sidebar, topbar, page grid and brand system | Preserved | EXACT_MATCH | Controlling visual authority |
| DD-02 | Daily navigation | v4 B–F epic grouping | Preserved; My Path, My Organization and Output added above Overview | REFERENCE_BASED_EXTENSION | Adds orientation without exposing 117 screens |
| DD-03 | Overview | v4 static demonstration metrics | Same component language with live engine metrics, current step, blockers and role | APPROVED_DEVIATION | Removes conflicting mock values |
| DD-04 | Expert scope | Not available in v4 | One role-filtered Expert Specification entry containing 117 screens | REFERENCE_BASED_EXTENSION | Keeps technical scope outside daily work |
| DD-05 | Mobile | v4 could overflow at narrow widths | Same visual language with corrected 390 px layout | APPROVED_DEVIATION | Required usability correction |
| DD-06 | Live screen bodies | Several v4 views were static prototypes | Reused v4 cards, tables, forms, tabs and alerts with live domain data | REFERENCE_BASED_EXTENSION | Functional completion inside approved design |

**Unresolved critical design deviations: 0**
