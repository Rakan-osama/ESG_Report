# Developer Handover

## Controlling references
1. `documentation/APPROVED_DESIGN_REFERENCE_v4.1.html` — controlling visual authority.
2. `EnergyUp_ESG_GRI_v17.1_v4_Live_Operational_Final.html` — approved standalone behavior and UAT reference.
3. `registries/live-screen-binding-66.csv` — daily B–F product surface.
4. `registries/screen-registry-117.*` — complete technical scope under Expert Specification.

## Architecture
The final HTML is compiled from:
- `source/base/` — unmodified v4.1 approved design baseline.
- `source/data/` — registries, methodology library, journey, and demo dataset.
- `source/modules/` — state, translations, audit, permissions, units, calculations, records, evidence, materiality, GRI, gates, principles, journey, and tenant.
- `source/extension.js` and `source/extension.css` — surgical v4 integration hooks and live screens.

Run `python source/build.py` from the package root. No absolute build path is used.

## Required production implementation
### Frontend
- Rebuild the same visual system as reusable React components.
- Preserve v4 sidebar grouping and the Expert Specification separation.
- Replace direct state calls with a typed API adapter.
- Preserve Arabic/English semantic parity and accessibility.

### Backend
- PostgreSQL schema, migrations, constraints, object versions, and tenant keys.
- Server authentication and role assignments.
- FORCE ROW LEVEL SECURITY for every tenant table.
- Server-side RBAC, separation of duties, reviewer independence, and state transitions.
- Secure object storage, SHA-256 on uploaded bytes, malware scanning, retention, supersession, and signed access.
- Versioned calculation service using approved methods, factors, conversions, and deterministic lineage.
- Append-only/tamper-evident audit events and correlation IDs.
- Gate and GRI claim evaluation on authoritative server state.

## API groups
Build APIs for organization/cycles/boundaries; standards/methodology; stakeholders/impacts/material topics; requests/records/evidence; validations/calculations; reviews/findings; GRI assessment/omissions/content index/claim; report/assurance/release; administration/audit/build specification.

## Acceptance contract
A production slice is not complete until the corresponding UAT action works through the UI, API, database, audit log, permissions, and automated tests. Client-side permission logic is a specification, not a security boundary.

## QA
```bash
python -m pip install -r qa/requirements.txt
python -m playwright install chromium
python qa/run_all.py
```
Expected result: 78 passed, 0 failed, 0 page errors, 0 console errors.
