# Final Report — EnergyUp ESG & GRI v18.3.0 · Sealed Operational Baseline

**Classification (single, authoritative): Release Candidate — Corrections Still Required.**
This supersedes every earlier classification in this document tree, including any historical
"Approved Frontend UAT and Developer Build Baseline" wording from the v17.1 era retained below
for archival context only.

## v18.3 outcome
- Full v17.1 operational engine (18 modules) carried forward unreduced; v4 Premium visual authority.
- v18.1/v18.2 corrections merged: canonical full business key (now incl. datapointId, dimension
  case-sensitivity definitions, real ISO date normalization), truly-empty client tenants with
  PRECONDITION_ORG_CYCLE guards, per-tenant IndexedDB isolation, collision-proof persisted ID
  generator, sealed-tree integrity with QA output isolated in qa/output/, LF-deterministic build,
  browser QA retargeted to the v18.3 artifact.
- QA: 136/136 (run twice), QA_STATE_MUTATION_COUNT = 0; `npm test` then `python qa/verify_integrity.py` passes.
- Open before "Approved Frontend UAT": Chromium screenshot suite + manual 27-step user journey
  (tooling ready in qa/), 9-item daily-navigation IA pending UX sign-off.
- Production still requires: backend, PostgreSQL + FORCE RLS, server-side RBAC/SoD, object storage,
  immutable server audit, server-side calculations, approved factor library, real authentication.

---
## Archived v17.1 final report (historical)
# Final Implementation Report — v17.1

## Executive decision
The release uses **v4.1 as the controlling UI/UX product** and inserts the operational functions from v16/v17 into that structure. It does not place 117 screens in the daily sidebar. The result is approved as a **Frontend UAT and Developer Build Baseline**.

## What is now complete
- The original v4 B–F navigation remains the normal user route.
- All 66 v4 B–F routes return a live, non-mock screen body. Of these, 57 have domain-evaluable completion logic and 9 are explicitly backend/taxonomy/export dependent rather than being falsely marked complete.
- The Overview is generated from live records, evidence, GRI 2, claim, gates, audit, and current journey state.
- My Path identifies the current step, blocker, responsible role, completion condition, previous/next route, and progress.
- My Organization provides organization, legal-entity, site, boundary, cycle, and reporting-approach setup.
- The v16 117-screen specification is contained in Expert Specification for authorized technical roles.
- Source modules and data registries are included, and `source/build.py` uses relative paths only.

## Corrections made during final independent QA
1. Split the diesel and LPG combustion methods; LPG no longer uses a litre-based diesel factor.
2. Added a controlled LPG demo factor and a separate natural-gas combustion method.
3. Added `Nm3/Nm³` to the volume family for controlled compatibility.
4. Removed natural gas from direct kWh aggregation because a calorific-value conversion is required.
5. Corrected waste-diversion, LTIFR, turnover, and anti-corruption activity mappings.
6. Corrected calculation self-tests so they leave zero synthetic calculation runs in Product Mode.
7. Corrected evidence statistics to count simulated digests through the central classifier.

## Test evidence
- UI/navigation/responsive/security suite: **42/42 passed**.
- End-to-end domain/methodology/security suite: **36/36 passed**.
- Combined: **78/78 passed**.
- JavaScript page errors: **0**.
- Browser console errors: **0**.
- Mobile width at 390 px: **no horizontal overflow**.

## User journey proven
Create record → create/link evidence → validate → submit → independent review → return with reason → correct → revalidate → resubmit → approve → controlled calculation → evidence supersession → GRI evaluation → Content Index → publication gates.

## Methodology controls proven
- Viewer and assurance roles cannot mutate source records.
- Self-approval, reviewer independence, cross-tenant access, and state restrictions are evaluated centrally.
- Demo factors are refused in Product Mode.
- Human-rights severity override reads one approved threshold-model field.
- Seven prohibited GRI omissions are blocked.
- Nine GRI requirements and fifteen publication gates are evaluated from domain state.
- Failed gates contain remediation.

## Remaining boundaries
This release does not provide a production backend, licensed GRI content package, approved client emission factors, official taxonomy package validation, server-side evidence storage, or production assurance controls. These are recorded in `KNOWN_LIMITATIONS.md` and the Gap Register.
