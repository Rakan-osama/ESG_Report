# Known Limitations

1. No production backend, database, authentication provider, or multi-user concurrency.
2. Client-side RBAC/SoD is demonstrative and must never be treated as a security boundary.
3. Evidence binary storage is simulated in the standalone build; browser-computed hashes can be demonstrated, but production hashing must be server-side.
4. All supplied emission factors are `DEMO_ONLY`; Product Mode refuses them until approved.
5. GRI licensed disclosure content and complete datapoint matrices are not distributed in this package.
6. Applicable Sector Standard topic sets require governed content loading for relevant clients.
7. Official GRI taxonomy package import and validator are not included; no QName is invented.
8. Claim eligibility shown by the engine is an evaluation of loaded records, not a certification by GRI or an assurance conclusion.
9. Data export, report rendering, sampling, secure assurance workpapers, backup, disaster recovery, monitoring, and penetration testing require production services.
10. Demo organization values are fictional and must not be reused as client results.
