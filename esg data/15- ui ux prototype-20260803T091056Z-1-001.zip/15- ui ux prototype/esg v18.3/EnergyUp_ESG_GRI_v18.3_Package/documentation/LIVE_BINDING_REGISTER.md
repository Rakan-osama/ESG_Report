# Live Binding Register

- v4 B–F routes: **66**
- Routes with live non-mock screen bodies: **66**
- Domain-evaluable journey steps: **57**
- Explicitly backend/taxonomy/export-dependent steps: **9**
- Controlled technical screens available in Expert Specification: **117**

The nine backend-dependent steps remain visible with an honest `SPECIFIED_NOT_BUILT` status where a standalone browser cannot provide the production control. They are not counted in the journey completion denominator. This prevents false green completion while keeping the screen specification and UI available for development.

The detailed 66-route register is `registries/live-screen-binding-66.csv`. The full technical scope is `registries/screen-registry-117.csv`.
