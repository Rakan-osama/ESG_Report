# EnergyUp ESG & GRI — superseded v17.1 documentation (see root README for v18.2)

## Start here
Open `EnergyUp_ESG_GRI_v17.1_v4_Live_Operational_Final.html` in a current Chromium, Edge, or Chrome browser.

The application preserves the approved v4.1 interface and B–F navigation. Operational functions from v16/v17 are bound into that interface. The 117-screen controlled registry is available under **Expert specification** and is not exposed as the normal user journey.

## Included
- 66/66 v4 B–F screens with live operational bindings.
- 117-screen controlled technical registry.
- 16 workspaces, 51 activity inputs, 30 GRI 2 disclosures, and 13 roles.
- Multi-record data workflow, evidence versioning, calculation controls, impact materiality, GRI claim evaluation, publication gates, audit, Arabic/English, RTL, and responsive layouts.
- Complete modular source and a relative-path build script.
- Reproducible browser and domain QA.

## Build
```bash
python source/build.py
```

## Test
```bash
python -m pip install -r qa/requirements.txt
python -m playwright install chromium
python qa/run_all.py
```

When Chromium is installed at a non-standard path, update the `executable_path` setting in the QA scripts or use the Playwright-installed browser.

## Release classification
**Release Candidate — Corrections Still Required (v18.2).**

This is not a production SaaS. Server-side authentication, PostgreSQL/RLS, secure object storage, malware scanning, approval enforcement, calculation execution, audit immutability, and deployment controls remain backend responsibilities.
