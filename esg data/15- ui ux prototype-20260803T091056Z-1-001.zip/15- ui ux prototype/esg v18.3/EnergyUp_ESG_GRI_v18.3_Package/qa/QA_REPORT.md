# QA Report — EnergyUp ESG & GRI v17.1

## Result
- Total assertions: **78**
- Passed: **78**
- Failed: **0**
- Page errors: **0**
- Console errors: **0**

## Coverage
### UI, navigation and responsive — 42 assertions
- Login and live Overview.
- 117-screen registry, 16 workspaces, 51 activity inputs, 30 GRI 2 disclosures, and 66 journey screens.
- 66/66 live B–F bindings.
- Previously static screens B-06, B-08, C-08, C-10, D-04, D-11, D-12, E-03, F-02, F-03, F-04, F-06, F-08, F-09, F-10, and F-11.
- Expert Specification separation.
- 390 px responsive width and Arabic RTL.
- Permission negatives, factor blocking, nine requirements, fifteen gates, remediation, offline resources, and zero runtime errors.

### End-to-end domain and methodology — 36 assertions
- Create record and evidence; link evidence.
- Validate, submit, review, return with reason, correct, resubmit, and independently approve.
- Refuse demo factors in Product Mode; calculate only after temporary approval in isolated QA state.
- Preserve evidence versions and move links on supersession.
- Classify simulated and browser-computed SHA-256 digests consistently.
- Apply human-rights severity override from the approved threshold model.
- Block prohibited GRI omissions; compute claim; generate Content Index; evaluate gates.
- Enforce Viewer, Assurance, and cross-tenant restrictions.
- Confirm calculation self-tests add zero audit events and zero calculation runs.

## Reproduction
```bash
python -m pip install -r qa/requirements.txt
python -m playwright install chromium
python qa/run_all.py
```

Expected summary: `78 passed / 0 failed`.
