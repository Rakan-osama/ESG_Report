from pathlib import Path
import os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'EnergyUp_ESG_GRI_v18.3_Sealed_Operational_Baseline.html').read_text(encoding='utf-8')
OUT=ROOT/'screenshots';OUT.mkdir(exist_ok=True)
BROWSER_PATH=os.environ.get('CHROMIUM_PATH') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path=BROWSER_PATH,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':1000});page.set_content(HTML,wait_until='load');page.wait_for_timeout(800)
 page.screenshot(path=str(OUT/'login_1440.png'),full_page=True);page.click('#enterPlatform');page.wait_for_timeout(1200)
 for sid,fn in [('OVERVIEW','overview_1440.png'),('X-PATH','my_path_1440.png'),('X-ORG','my_organization_1440.png'),('D-03','data_records_1440.png'),('C-07','materiality_1440.png'),('E-07','gri_claim_1440.png'),('F-09','taxonomy_1440.png'),('X-EXPERT','expert_spec_1440.png')]:
  page.evaluate('(id)=>V41.go(id)',sid);page.wait_for_timeout(250);page.screenshot(path=str(OUT/fn),full_page=True)
 page.set_viewport_size({'width':390,'height':844});page.evaluate("V41.go('OVERVIEW')");page.wait_for_timeout(250);page.screenshot(path=str(OUT/'overview_390_en.png'),full_page=True);page.click('.lang-btn');page.wait_for_timeout(250);page.screenshot(path=str(OUT/'overview_390_ar.png'),full_page=True)
 b.close()
print('Screenshots generated:',len(list(OUT.glob('*.png'))))
