from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).resolve().parents[1]
qa=ROOT/'qa'
cmds=[[sys.executable,str(qa/'run_ui_qa.py')],[sys.executable,str(qa/'run_domain_e2e.py')]]
for c in cmds:
    r=subprocess.run(c,cwd=ROOT)
    if r.returncode: raise SystemExit(r.returncode)
ui=json.loads((qa/'ui_qa.json').read_text())
dm=json.loads((qa/'domain_e2e.json').read_text())
all_tests=ui['tests']+dm['steps']
out={'release':'v18.3','total':len(all_tests),'passed':sum(1 for x in all_tests if x.get('pass')),'failed':sum(1 for x in all_tests if not x.get('pass')),'pageErrors':ui.get('errors',[])+dm.get('page_errors',[]),'consoleErrors':ui.get('console_errors',[])+dm.get('console_errors',[]),'ui':ui,'domain':dm}
(qa/'QA_REPORT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'total':out['total'],'passed':out['passed'],'failed':out['failed'],'pageErrors':len(out['pageErrors']),'consoleErrors':len(out['consoleErrors'])},indent=2))
if out['failed'] or out['pageErrors'] or out['consoleErrors']: raise SystemExit(1)
