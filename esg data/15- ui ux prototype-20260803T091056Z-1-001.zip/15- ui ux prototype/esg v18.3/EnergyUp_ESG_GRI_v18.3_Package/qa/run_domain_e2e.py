import asyncio, json, os
from pathlib import Path
BROWSER_PATH=os.environ.get('CHROMIUM_PATH') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None)
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'EnergyUp_ESG_GRI_v18.3_Sealed_Operational_Baseline.html').read_text(encoding='utf-8')
JS=r'''() => {
  const snapshot = JSON.parse(JSON.stringify({
    records:App.State.records,evidence:App.State.evidence,audit:App.State.audit,calcRuns:App.State.calcRuns,
    materialTopics:App.State.materialTopics,omissions:App.State.omissions,gateResults:App.State.gateResults,claim:App.State.claim,
    role:App.State.role,user:App.State.user
  }));
  const out={steps:[], errors:[]};
  function step(name, cond, detail){ out.steps.push({name,pass:!!cond,detail:detail||''}); if(!cond) out.errors.push(name+': '+(detail||'')); }
  try {
    App.setRole('DATA_CONTRIBUTOR',{name:'Data Contributor Test'});
    const c=App.Records.create({activityId:'ACT-ENE-005',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-12-01',periodEnd:'2025-12-31',periodLabel:'2025-12',dimensions:{site:'SITE-03',month:'2025-12'},rawValue:150,rawUnit:'kg',dataSource:'Test invoice',method:'Measured',estimated:false,uncertainty:'±2%',varianceExplanation:'First record'});
    step('record create',c.ok,c.code);
    const rid=c.record.id;
    const ev=App.Evidence.create({fileName:'lpg-invoice-test.pdf',fileType:'PDF',mimeType:'application/pdf',fileSize:1000,notes:'QA'});
    step('evidence create',ev.ok,ev.code);
    const link=App.Evidence.link(ev.evidence.id,rid); step('evidence link',link.ok,link.code);
    let x=App.Records.transition(rid,'VALIDATED'); step('record validate',x.ok,x.code);
    x=App.Records.transition(rid,'SUBMITTED'); step('record submit',x.ok,x.code);
    App.setRole('ESG_TECH_REVIEWER',{name:'Independent Reviewer'});
    x=App.Records.transition(rid,'UNDER_REVIEW'); step('start review',x.ok,x.code);
    x=App.Records.transition(rid,'RETURNED',{reason:'Clarify invoice period'}); step('return with reason',x.ok,x.code);
    App.setRole('DATA_CONTRIBUTOR',{name:'Data Contributor Test'});
    x=App.Records.edit(rid,{notes:'Invoice period clarified',varianceExplanation:'QA controlled change'}); step('edit returned',x.ok,x.code);
    x=App.Records.transition(rid,'VALIDATED'); step('revalidate',x.ok,x.code);
    x=App.Records.transition(rid,'SUBMITTED'); step('resubmit',x.ok,x.code);
    App.setRole('ESG_TECH_REVIEWER',{name:'Independent Reviewer'});
    x=App.Records.transition(rid,'UNDER_REVIEW'); step('review after resubmit',x.ok,x.code);
    x=App.Records.transition(rid,'APPROVED'); step('independent approval',x.ok,x.code);
    step('approved status',App.Records.byId(rid).status==='APPROVED',App.Records.byId(rid).status);
    // Product calculation remains blocked because all supplied factors are DEMO_ONLY.
    let calc=App.Calculations.runProduct(App.Records.byId(rid)); step('demo factor blocked in product',!calc.ok && calc.code==='FACTOR_NOT_APPROVED',calc.code);
    // Temporarily approve factor to validate unit lineage; restored at end.
    const fac=App.Data.factorSets.find(f=>f.id==='FS-LPG-2025'); const oldApproval=fac.approval; fac.approval='APPROVED';
    calc=App.Calculations.runProduct(App.Records.byId(rid)); step('approved factor calculation',calc.ok,calc.code||'');
    if(calc.ok){ step('calculation output unit',calc.run.outputUnit==='tCO2e',calc.run.outputUnit); step('calculation lineage',Array.isArray(calc.run.trace)&&calc.run.trace.length>0,JSON.stringify(calc.run.trace)); }
    fac.approval=oldApproval;
    // Evidence supersession by Data Owner.
    App.setRole('DATA_OWNER',{name:'Data Owner Test'});
    const sup=App.Evidence.supersede(ev.evidence.id,{fileName:'lpg-invoice-test-v2.pdf',fileType:'PDF',mimeType:'application/pdf',fileSize:1200});
    step('evidence supersede',sup.ok,sup.code);
    if(sup.ok){ step('old evidence preserved',sup.previous.status==='SUPERSEDED',sup.previous.status); step('new evidence linked',App.Records.byId(rid).evidenceIds.includes(sup.evidence.id),JSON.stringify(App.Records.byId(rid).evidenceIds)); }
    // Hash classification consistency.
    const sim=App.Evidence.classifyEvidenceHash(sup.evidence); step('simulated hash classified',sim.code==='SIMULATED_PROTOTYPE_DIGEST',sim.code);
    const real={hash:'a'.repeat(64),hashMethod:'SHA-256',hashSource:'WEB_CRYPTO'};
    const cls=App.Evidence.classifyEvidenceHash(real); step('browser SHA classified',cls.code==='VERIFIED_BROWSER_SHA256',cls.code);
    // Materiality human-rights override.
    const hr={polarity:'Negative',actuality:'Potential',scale:2,scope:1,irremediability:1,likelihood:1,humanRights:true};
    const sc=App.Materiality.score(hr); step('human rights override',sc.override===true,JSON.stringify(sc));
    step('override uses approved model',sc.overrideRule.includes(String(App.Materiality.model().humanRightsOverride.severityFloor)),sc.overrideRule);
    // GRI controls.
    App.setRole('ESG_TECH_REVIEWER',{name:'GRI Reviewer'}); const omit=App.GRI.requestOmission('2-1','NOT_APPLICABLE','x',{});
    step('prohibited omission blocked',omit && omit.ok===false && omit.code==='OMISSION_BLOCKED',JSON.stringify(omit));
    const req=App.GRI.requirements(); step('nine GRI requirements',req.length===9,String(req.length));
    const claim=App.GRI.evaluateClaim(); step('claim computed',!!claim && ['IN_ACCORDANCE','WITH_REFERENCE','NOT_ELIGIBLE','BLOCKED'].includes(claim.result),JSON.stringify(claim));
    const ci=App.GRI.contentIndex(); step('content index generated',!!ci && Array.isArray(ci.rows) && ci.rows.length>0,String(ci&&ci.rows&&ci.rows.length));
    const gates=App.Gates.reEvaluate(); step('fifteen gates',gates.length===15,String(gates.length));
    const badRem=gates.filter(g=>!g.pass && (!g.failures.length || !g.remediation.length)); step('failed gates actionable',badRem.length===0,JSON.stringify(badRem));
    // Negative permissions.
    const approved=App.Records.byId(rid);
    App.setRole('VIEWER',{name:'Viewer Test'});
    const v=App.Permissions.canPerformAction({permission:'record.reopen',object:approved}); step('viewer read only',v.allowed===false,v.code);
    const cross=Object.assign({},approved,{tenantId:'TEN-OTHER'});
    const ct=App.Permissions.canPerformAction({permission:'view',object:cross}); step('cross tenant blocked',ct.allowed===false && ct.code==='TENANT_ISOLATION',ct.code);
    App.setRole('ASSURANCE_REVIEWER',{name:'Assurance Reviewer Test'});
    const ae=App.Permissions.canPerformAction({permission:'record.edit',object:approved}); step('assurance cannot edit source',ae.allowed===false,ae.code);
    // QA audit isolation: calculations self-test must not alter business audit.
    const ac=App.State.audit.length, cc=App.State.calcRuns.length;
    const st=App.Calculations.selfTest();
    step('calculation self tests pass',st.every(t=>t.pass),JSON.stringify(st.filter(t=>!t.pass)));
    step('self test does not add audit',App.State.audit.length===ac,String(App.State.audit.length-ac));
    step('self test does not add calc runs',App.State.calcRuns.length===cc,String(App.State.calcRuns.length-cc));
  } catch(e){ out.errors.push(String(e&&e.stack||e)); }
  // Restore complete mutable state and user identity.
  Object.keys(snapshot).forEach(k=>{ if(k==='role'||k==='user') return; App.State[k]=JSON.parse(JSON.stringify(snapshot[k])); });
  App.State.role=snapshot.role; App.State.user=snapshot.user;
  out.pass=out.errors.length===0 && out.steps.every(s=>s.pass);
  out.count=out.steps.length;
  return out;
}'''
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True, executable_path=BROWSER_PATH, args=['--no-sandbox'])
  page=await b.new_page(viewport={'width':1440,'height':1000})
  errs=[]; cons=[]
  page.on('pageerror',lambda e: errs.append(str(e)))
  page.on('console',lambda m: cons.append(m.text) if m.type=='error' else None)
  await page.set_content(HTML,wait_until='domcontentloaded',timeout=120000); await page.wait_for_timeout(1000)
  out=await page.evaluate(JS)
  out['page_errors']=errs; out['console_errors']=cons
  (ROOT/'qa'/'domain_e2e.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
  print(json.dumps(out,ensure_ascii=False,indent=2))
  await b.close()
asyncio.run(main())
