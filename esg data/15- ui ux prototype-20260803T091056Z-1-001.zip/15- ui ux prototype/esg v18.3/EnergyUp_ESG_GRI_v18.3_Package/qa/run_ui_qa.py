from playwright.sync_api import sync_playwright
import json, os, time
from pathlib import Path
BROWSER_PATH=os.environ.get('CHROMIUM_PATH') or ('/usr/bin/chromium' if Path('/usr/bin/chromium').exists() else None)
ROOT=Path(__file__).resolve().parents[1]
html_path=ROOT/'EnergyUp_ESG_GRI_v18.3_Sealed_Operational_Baseline.html'
html=html_path.read_text(encoding='utf-8')
res={'errors':[],'console_errors':[],'tests':[]}
def t(name,ok,detail=''):
 res['tests'].append({'name':name,'pass':bool(ok),'detail':str(detail)})
with sync_playwright() as p:
 b=p.chromium.launch(headless=True, executable_path=BROWSER_PATH, args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':1000})
 page.on('pageerror',lambda e:res['errors'].append(str(e)))
 page.on('console',lambda m:res['console_errors'].append(m.text) if m.type=='error' else None)
 page.set_content(html,wait_until='load')
 page.wait_for_timeout(1500)
 t('login visible',page.locator('#standaloneLogin').is_visible())
 page.click('#enterPlatform')
 page.wait_for_timeout(2500)
 t('app visible',page.locator('#app').is_visible())
 t('live overview title',page.get_by_text('Reporting overview',exact=True).count()>0,page.locator('body').inner_text()[:500])
 t('continue report',page.get_by_text('Continue report',exact=False).count()>0)
 t('expert nav',page.get_by_text('Expert specification',exact=True).count()>0)
 # engine counts
 counts=page.evaluate('''() => ({screens:Object.keys(App.Data.registry.screens).length, acts:App.Data.registry.activities.length,gri2:App.Data.registry.gri2.length,workspaces:App.Data.registry.workspaces.length,steps:App.Data.journeySteps.length})''')
 t('registry 117',counts['screens']==117,counts)
 t('activities 51',counts['acts']==51,counts)
 t('gri2 30',counts['gri2']==30,counts)
 t('workspaces 16',counts['workspaces']==16,counts)
 t('journey 66',counts['steps']==66,counts)
 # all 66 live bindings
 live=page.evaluate('''() => App.Data.journeySteps.map(s=>({id:s.id,live:V41_EXT.screen({id:s.id})!=null}));''')
 missing=[x['id'] for x in live if not x['live']]
 t('all 66 live',len(missing)==0,missing)
 # navigate missing screens and check unique live phrase
 checks={'B-06':'Setup progress','B-08':'Approved sector profile','C-08':'Divergence reconciliation queue','C-10':'Sector Standard reconciliation','D-04':'Controlled bulk import','D-11':'Comparative analysis','D-12':'Restatement and version history','E-03':'Cross-disclosure and cross-period controls','F-02':'Controlled report structure','F-03':'Narrative blocks with source references','F-04':'Tables and charts bound to controlled outputs','F-06':'Narrative parity','F-08':'Controlled exports','F-09':'Official taxonomy package registry','F-10':'XBRL-ready context model','F-11':'Digital-report validation'}
 for sid,txt in checks.items():
  page.evaluate('(id)=>V41.go(id)',sid)
  page.wait_for_timeout(120)
  t('live '+sid,page.get_by_text(txt,exact=False).count()>0,txt)
 # expert page
 page.evaluate("V41.go('X-EXPERT')")
 page.wait_for_timeout(300)
 t('expert registry page',page.get_by_text('Controlled screens',exact=True).count()>0)
 t('expert 117 visible',page.get_by_text('117',exact=True).count()>0)
 # mobile responsive
 page.set_viewport_size({'width':390,'height':844})
 page.evaluate("V41.go('OVERVIEW')")
 page.wait_for_timeout(300)
 widths=page.evaluate('''() => ({doc:document.documentElement.scrollWidth,inner:innerWidth,body:document.body.scrollWidth})''')
 t('mobile no overflow',widths['doc']<=390 and widths['body']<=390,widths)
 # Arabic
 page.click('.lang-btn')
 page.wait_for_timeout(300)
 t('rtl',page.locator('html').get_attribute('dir')=='rtl',page.locator('html').get_attribute('dir'))
 t('arabic overview',page.get_by_text('نظرة عامة على التقرير',exact=True).count()>0)
 # screenshots
 out=str(ROOT/'screenshots')
 os.makedirs(out,exist_ok=True)
 page.screenshot(path=out+'/overview_390_ar.png',full_page=True)
 page.click('.lang-btn')
 page.set_viewport_size({'width':1440,'height':1000});page.evaluate("V41.go('OVERVIEW')");page.wait_for_timeout(250);page.screenshot(path=out+'/overview_1440.png',full_page=True)
 page.evaluate("V41.go('X-PATH')");page.wait_for_timeout(250);page.screenshot(path=out+'/my_path_1440.png',full_page=True)
 page.evaluate("V41.go('D-03')");page.wait_for_timeout(250);page.screenshot(path=out+'/data_records_1440.png',full_page=True)
 page.evaluate("V41.go('X-EXPERT')");page.wait_for_timeout(250);page.screenshot(path=out+'/expert_spec_1440.png',full_page=True)
 # role security negative tests
 sec=page.evaluate('''() => {let r=App.Records.approved()[0]; return {
  viewerApprove: App.Permissions.canPerformAction({permission:'record.approve',object:r,role:'VIEWER'}).allowed,
  contributorApproveOwn: App.Permissions.canPerformAction({permission:'record.approve',object:Object.assign({},r,{lastEditedBy:App.State.user.id}),role:'DATA_CONTRIBUTOR'}).allowed,
  assuranceEdit: App.Permissions.canPerformAction({permission:'record.edit',object:r,role:'ASSURANCE_REVIEWER'}).allowed
 }}''')
 t('viewer cannot approve',sec['viewerApprove']==False,sec)
 t('contributor cannot approve own',sec['contributorApproveOwn']==False,sec)
 t('assurance cannot edit',sec['assuranceEdit']==False,sec)
 # calculation controls
 calc=page.evaluate('''() => {let a=App.Data.factorSets.filter(x=>x.approval!=='APPROVED')[0];let r=App.Records.approved()[0]; return {unapprovedFactor:!!a, run:App.Calculations.run(r,{sandbox:false})};}''')
 t('unapproved factor blocked',calc['run'].get('ok')==False if isinstance(calc['run'],dict) else False,calc)
 # claim and gates
 cg=page.evaluate('''() => {let c=App.GRI.evaluateClaim(),g=App.Gates.results();return {req:c.requirements.length,gates:g.length,rem:g.filter(x=>!x.pass&&(!x.remediation||!x.remediation.length)).map(x=>x.id)}}''')
 t('nine GRI requirements',cg['req']==9,cg)
 t('15 gates',cg['gates']==15,cg)
 t('failed gates have remediation',len(cg['rem'])==0,cg)
 # external requests check not easily; performance entries
 ext=page.evaluate('''() => performance.getEntriesByType('resource').filter(x=>!x.name.startsWith(location.origin)).map(x=>x.name)''')
 t('offline self-contained resources',len(ext)==0,ext)
 t('zero page errors',len(res['errors'])==0,res['errors'])
 t('zero console errors',len(res['console_errors'])==0,res['console_errors'])
 b.close()
(ROOT/'qa'/'ui_qa.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(res,ensure_ascii=False,indent=2))
