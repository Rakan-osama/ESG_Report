#!/usr/bin/env node
/* v18 QA — Node + jsdom (no browser available in the build sandbox).
   Runs: boot, login, startup-mode chooser, demo banner, empty first-use wipe,
   the full v17.1 domain e2e (twice, proving QA_STATE_MUTATION_COUNT = 0),
   and v18 negative controls (SoD, duplicate key, omission block, claim). */
const fs = require('fs'), path = require('path');
const { JSDOM } = require('jsdom');
const HTML = fs.readFileSync(path.join(__dirname, '..', 'EnergyUp_ESG_GRI_v18.3_Sealed_Operational_Baseline.html'), 'utf8');

const DOMAIN_E2E = ` (function(){
  const snapshot = JSON.parse(JSON.stringify({
    records:App.State.records,evidence:App.State.evidence,audit:App.State.audit,calcRuns:App.State.calcRuns,
    materialTopics:App.State.materialTopics,omissions:App.State.omissions,gateResults:App.State.gateResults,claim:App.State.claim,
    role:App.State.role,user:App.State.user
  }));
  const out={steps:[], errors:[]};
  function step(name, cond, detail){ out.steps.push({name,pass:!!cond,detail:detail||''}); if(!cond) out.errors.push(name+': '+(detail||'')); }
  try {
    App.setRole('DATA_CONTRIBUTOR',{name:'Data Contributor Test'});
    const c=App.Records.create({activityId:'ACT-ENE-005',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-12-01',periodEnd:'2025-12-31',periodLabel:'2025-12',dimensions:{site:'SITE-03',month:'2025-12'},rawValue:150,rawUnit:'kg',dataSource:'Test invoice',method:'Measured',estimated:false,uncertainty:'±2%',varianceExplanation:'First record'});
    step('record create',c.ok,c.code);
    const rid=c.record.id;
    const ev=App.Evidence.create({fileName:'lpg-invoice-test.pdf',fileType:'PDF',mimeType:'application/pdf',fileSize:1000,notes:'QA'});
    step('evidence create',ev.ok,ev.code);
    const link=App.Evidence.link(ev.evidence.id,rid); step('evidence link',link.ok,link.code);
    let x=App.Records.transition(rid,'VALIDATED'); step('record validate',x.ok,x.code);
    x=App.Records.transition(rid,'SUBMITTED'); step('record submit',x.ok,x.code);
    const self=App.Records.transition(rid,'APPROVED');
    step('SoD: contributor cannot approve own record',self.ok===false,self.code);
    App.setRole('ESG_TECH_REVIEWER',{name:'Independent Reviewer'});
    x=App.Records.transition(rid,'UNDER_REVIEW'); step('start review',x.ok,x.code);
    x=App.Records.transition(rid,'RETURNED',{reason:'Clarify invoice period'}); step('return with reason',x.ok,x.code);
    const noReason=App.Records.transition(rid,'RETURNED',{}); step('return without reason rejected',noReason.ok===false,noReason.code);
    App.setRole('DATA_CONTRIBUTOR',{name:'Data Contributor Test'});
    x=App.Records.edit(rid,{notes:'Invoice period clarified',varianceExplanation:'QA controlled change'}); step('edit returned',x.ok,x.code);
    x=App.Records.transition(rid,'VALIDATED'); step('revalidate',x.ok,x.code);
    x=App.Records.transition(rid,'SUBMITTED'); step('resubmit',x.ok,x.code);
    App.setRole('ESG_TECH_REVIEWER',{name:'Independent Reviewer'});
    x=App.Records.transition(rid,'UNDER_REVIEW'); step('review after resubmit',x.ok,x.code);
    x=App.Records.transition(rid,'APPROVED'); step('independent approval',x.ok,x.code);
    step('approved status',App.Records.byId(rid).status==='APPROVED',App.Records.byId(rid).status);
    App.setRole('DATA_CONTRIBUTOR',{name:'Data Contributor Test'});
    const dup=App.Records.create({activityId:'ACT-ENE-005',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-12-01',periodEnd:'2025-12-31',periodLabel:'2025-12',dimensions:{site:'SITE-03',month:'2025-12'},rawValue:150,rawUnit:'kg',dataSource:'Dup'});
    step('duplicate draft detected',!!App.Records.duplicateOf(dup.record),'');
    const dupVal=App.Records.transition(dup.record.id,'VALIDATED');
    step('identical full key blocked at validation gate',dupVal.ok===false && dupVal.code==='VALIDATION_FAILED',dupVal.code);
    /* P0-2: different dimension value => NOT a duplicate (two meters, same site+month) */
    const mA=App.Records.create({activityId:'ACT-ENE-005',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-11-01',periodEnd:'2025-11-30',periodLabel:'2025-11',dimensions:{meter:'MTR-A'},rawValue:90,rawUnit:'kg',dataSource:'Meter A invoice'});
    const mB=App.Records.create({activityId:'ACT-ENE-005',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-11-01',periodEnd:'2025-11-30',periodLabel:'2025-11',dimensions:{meter:'MTR-B'},rawValue:80,rawUnit:'kg',dataSource:'Meter B invoice'});
    step('meter A and meter B are distinct records',mA.ok&&mB.ok&&!App.Records.duplicateOf(mB.record),'');
    let vA=App.Records.transition(mA.record.id,'VALIDATED');
    let vB=App.Records.transition(mB.record.id,'VALIDATED');
    step('meter A validates',vA.ok,vA.code); step('meter B validates (P0-2 fixed)',vB.ok,vB.code);
    /* case normalization: meter 'mtr-a ' (trailing space, lower) IS a duplicate of MTR-A */
    const mAdup=App.Records.create({activityId:'ACT-ENE-005',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-11-01',periodEnd:'2025-11-30',periodLabel:'2025-11',dimensions:{meter:' mtr-a '},rawValue:90,rawUnit:'kg',dataSource:'dup'});
    step('normalized dimension detected as duplicate',!!App.Records.duplicateOf(mAdup.record),'');
    /* superseded original frees the key */
    const supRec=App.Records.byId(mAdup.record.id); const origA=App.Records.byId(mA.record.id);
    origA.status='SUPERSEDED';
    step('superseded record excluded from duplicate key',!App.Records.duplicateOf(supRec),'');
    origA.status='VALIDATED';
    /* v18.3 P1-2: datapointId is part of the business key */
    const dpA=App.Records.create({activityId:'ACT-ENE-005',datapointId:'DP-A',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-10-01',periodEnd:'2025-10-31',periodLabel:'2025-10',dimensions:{},rawValue:5,rawUnit:'kg',dataSource:'x'});
    const dpB=App.Records.create({activityId:'ACT-ENE-005',datapointId:'DP-B',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-10-01',periodEnd:'2025-10-31',periodLabel:'2025-10',dimensions:{},rawValue:6,rawUnit:'kg',dataSource:'x'});
    step('different datapointId => distinct records (P1-2)',dpA.ok&&dpB.ok&&!App.Records.duplicateOf(dpB.record),'');
    const dpB2=App.Records.create({activityId:'ACT-ENE-005',datapointId:'DP-B',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-10-1',periodEnd:'2025-10-31',periodLabel:'2025-10',dimensions:{},rawValue:6,rawUnit:'kg',dataSource:'x'});
    step('same datapointId + short date (2025-10-1) normalized => duplicate detected',!!App.Records.duplicateOf(dpB2.record),'');
    step('identifier ids are case-exact (dp-b != DP-B by design)',App.Records.businessKey({datapointId:'dp-b'})!==App.Records.businessKey({datapointId:'DP-B'}),'');
    /* v18.3 P1-2: per-dimension case-sensitivity definitions honoured */
    App.Data.dimensionDefinitions={serial:{caseSensitive:true}};
    const csA=App.Records.create({activityId:'ACT-ENE-005',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-09-01',periodEnd:'2025-09-30',periodLabel:'2025-09',dimensions:{serial:'abc'},rawValue:1,rawUnit:'kg',dataSource:'x'});
    const csB=App.Records.create({activityId:'ACT-ENE-005',entityId:'LE-02',siteId:'SITE-03',periodStart:'2025-09-01',periodEnd:'2025-09-30',periodLabel:'2025-09',dimensions:{serial:'ABC'},rawValue:1,rawUnit:'kg',dataSource:'x'});
    step('case-sensitive dimension definition honoured (abc != ABC)',csA.ok&&csB.ok&&!App.Records.duplicateOf(csB.record),'');
    delete App.Data.dimensionDefinitions;
    /* v18.3 P1-1: id generator scans entities/sites and never re-issues an existing id */
    App.Data.demo.legalEntities.push({id:'LE-9001',name_en:'Ghost'});
    const freshId=App.nextId('LE');
    step('nextId never re-issues an existing entity id (P1-1)',freshId!=='LE-9001' && parseInt(freshId.split('-')[1],10)>9001,freshId);
    const freshId2=App.nextId('LE');
    step('nextId monotonic within session',freshId2!==freshId,freshId2);
    App.Data.demo.legalEntities=App.Data.demo.legalEntities.filter(function(x){return x.id!=='LE-9001';});
    App.setRole('ESG_TECH_REVIEWER',{name:'Independent Reviewer'});
    let calc=App.Calculations.runProduct(App.Records.byId(rid)); step('demo factor blocked in product',!calc.ok && calc.code==='FACTOR_NOT_APPROVED',calc.code);
    const fac=App.Data.factorSets.find(f=>f.id==='FS-LPG-2025'); const oldApproval=fac.approval; fac.approval='APPROVED';
    calc=App.Calculations.runProduct(App.Records.byId(rid)); step('approved factor calculation',calc.ok,calc.code||'');
    if(calc.ok){ step('calculation output unit',calc.run.outputUnit==='tCO2e',calc.run.outputUnit); step('calculation lineage',Array.isArray(calc.run.trace)&&calc.run.trace.length>0,'trace'); }
    fac.approval=oldApproval;
    App.setRole('DATA_OWNER',{name:'Data Owner Test'});
    const sup=App.Evidence.supersede(ev.evidence.id,{fileName:'lpg-invoice-test-v2.pdf',fileType:'PDF',mimeType:'application/pdf',fileSize:1200});
    step('evidence supersede',sup.ok,sup.code);
    if(sup.ok){ step('old evidence preserved',sup.previous.status==='SUPERSEDED',sup.previous.status); step('new evidence linked',App.Records.byId(rid).evidenceIds.includes(sup.evidence.id),''); }
    const sim=App.Evidence.classifyEvidenceHash(sup.evidence); step('simulated hash classified',sim.code==='SIMULATED_PROTOTYPE_DIGEST',sim.code);
    const cls=App.Evidence.classifyEvidenceHash({hash:'a'.repeat(64),hashMethod:'SHA-256',hashSource:'WEB_CRYPTO'}); step('browser SHA classified',cls.code==='VERIFIED_BROWSER_SHA256',cls.code);
    const sc=App.Materiality.score({polarity:'Negative',actuality:'Potential',scale:2,scope:1,irremediability:1,likelihood:1,humanRights:true});
    step('human rights override',sc.override===true,JSON.stringify(sc.override));
    App.setRole('ESG_TECH_REVIEWER',{name:'GRI Reviewer'});
    const omit=App.GRI.requestOmission('2-1','NOT_APPLICABLE','x',{});
    step('prohibited omission blocked',omit && omit.ok===false && omit.code==='OMISSION_BLOCKED',omit&&omit.code);
    const req=App.GRI.requirements(); step('nine GRI requirements',req.length===9,String(req.length));
    const claim=App.GRI.evaluateClaim(); step('claim computed read-only',!!claim && ['IN_ACCORDANCE','WITH_REFERENCE','NOT_ELIGIBLE','BLOCKED'].includes(claim.result),claim&&claim.result);
    const ci=App.GRI.contentIndex(); step('content index generated',!!ci && Array.isArray(ci.rows) && ci.rows.length>0,String(ci&&ci.rows&&ci.rows.length));
    const gates=App.Gates.reEvaluate(); step('fifteen gates',gates.length===15,String(gates.length));
    const badRem=gates.filter(g=>!g.pass && (!g.failures.length || !g.remediation.length)); step('failed gates actionable',badRem.length===0,String(badRem.length));
    const approved=App.Records.byId(rid);
    App.setRole('VIEWER',{name:'Viewer Test'});
    const v=App.Permissions.canPerformAction({permission:'record.reopen',object:approved}); step('viewer read only',v.allowed===false,v.code);
    const ct=App.Permissions.canPerformAction({permission:'view',object:Object.assign({},approved,{tenantId:'TEN-OTHER'})}); step('cross tenant blocked',ct.allowed===false && ct.code==='TENANT_ISOLATION',ct.code);
    App.setRole('ASSURANCE_REVIEWER',{name:'Assurance Reviewer Test'});
    const ae=App.Permissions.canPerformAction({permission:'record.edit',object:approved}); step('assurance cannot edit source',ae.allowed===false,ae.code);
    const ac=App.State.audit.length, cc=App.State.calcRuns.length;
    const st=App.Calculations.selfTest();
    step('calculation self tests pass',st.every(t=>t.pass),String(st.filter(t=>!t.pass).length));
    step('self test does not add audit',App.State.audit.length===ac,'');
    step('self test does not add calc runs',App.State.calcRuns.length===cc,'');
  } catch(e){ out.errors.push(String(e&&e.stack||e)); }
  Object.keys(snapshot).forEach(k=>{ if(k==='role'||k==='user') return; App.State[k]=JSON.parse(JSON.stringify(snapshot[k])); });
  App.State.role=snapshot.role; App.State.user=snapshot.user;
  const after=JSON.stringify({records:App.State.records,evidence:App.State.evidence,audit:App.State.audit,calcRuns:App.State.calcRuns,
    materialTopics:App.State.materialTopics,omissions:App.State.omissions,gateResults:App.State.gateResults,claim:App.State.claim});
  const before=JSON.stringify({records:snapshot.records,evidence:snapshot.evidence,audit:snapshot.audit,calcRuns:snapshot.calcRuns,
    materialTopics:snapshot.materialTopics,omissions:snapshot.omissions,gateResults:snapshot.gateResults,claim:snapshot.claim});
  out.stateMutated = after!==before;
  out.pass=out.errors.length===0 && out.steps.every(s=>s.pass);
  out.count=out.steps.length;
  return out;
})() `;

function bootDom(seed) {
  const dom = new JSDOM(HTML, { runScripts: 'dangerously', url: 'https://localhost/v18', pretendToBeVisual: true,
    beforeParse(w) {
      w.requestAnimationFrame = cb => setTimeout(cb, 0);
      w.confirm = () => true;
      if (seed) Object.entries(seed).forEach(([k, v]) => w.localStorage.setItem(k, v));
    } });
  return dom;
}

(async function main() {
  const results = { suite: 'v18 QA (Node/jsdom)', at: new Date().toISOString(), sections: [], pass: true };
  function section(name, steps) { const ok = steps.every(s => s.pass); results.sections.push({ name, pass: ok, steps }); if (!ok) results.pass = false; }

  /* ---- 1. boot + login + demo mode ---- */
  const dom = bootDom(); const w = dom.window, d = w.document;
  await new Promise(r => setTimeout(r, 300));
  const s1 = [];
  s1.push({ name: 'App engines loaded', pass: !!(w.App && w.App.Records && w.App.GRI && w.App.Gates && w.App.Permissions), detail: '' });
  s1.push({ name: 'V41 base exposed', pass: !!w.V41, detail: '' });
  s1.push({ name: 'V18 overlay loaded', pass: !!w.V18, detail: '' });
  s1.push({ name: 'login overlay present', pass: !!d.getElementById('standaloneLogin'), detail: '' });
  d.getElementById('enterPlatform').click();
  await new Promise(r => setTimeout(r, 60));
  s1.push({ name: 'mode chooser shown on first login', pass: !!d.getElementById('v18Mode'), detail: '' });
  d.getElementById('v18Demo').click();
  await new Promise(r => setTimeout(r, 120));
  s1.push({ name: 'demo mode stored', pass: w.V18.getMode() === 'demo', detail: String(w.V18.getMode()) });
  w.V18.syncBanner();
  const banner = d.getElementById('v18Banner');
  s1.push({ name: 'permanent demo banner visible', pass: !!banner && /DEMO DATA/.test(banner.textContent), detail: '' });
  s1.push({ name: 'banner offers Reset Demo Data', pass: !!d.getElementById('v18Reset'), detail: '' });
  s1.push({ name: 'banner rendered at TOP (body class v18-banner-top)', pass: d.body.classList.contains('v18-banner-top'), detail: '' });
  d.getElementById('v18Coll').click();
  await new Promise(r => setTimeout(r, 30));
  s1.push({ name: 'banner collapsible to pill', pass: d.getElementById('v18Banner').classList.contains('collapsed'), detail: '' });
  d.getElementById('v18Banner').click();
  await new Promise(r => setTimeout(r, 30));
  s1.push({ name: 'banner expandable again', pass: !d.getElementById('v18Banner').classList.contains('collapsed'), detail: '' });
  s1.push({ name: 'demo tenant namespace = TEN-EEG', pass: w.App.State.tenantNamespace === 'TEN-EEG', detail: w.App.State.tenantNamespace });
  s1.push({ name: 'demo dataset labelled sandbox (isDemo)', pass: w.App.Tenant.isDemo() === true, detail: '' });
  section('Boot, login & demo mode', s1);

  /* ---- 2. domain e2e run 1 & 2 (mutation count) ---- */
  const run1 = w.eval(DOMAIN_E2E);
  section('Domain end-to-end · run 1 (' + run1.count + ' steps)', run1.steps);
  const run2 = w.eval(DOMAIN_E2E);
  section('Domain end-to-end · run 2 (' + run2.count + ' steps)', run2.steps);
  const mutations = (run1.stateMutated ? 1 : 0) + (run2.stateMutated ? 1 : 0);
  section('QA state isolation', [{ name: 'QA_STATE_MUTATION_COUNT = 0 across both runs', pass: mutations === 0, detail: String(mutations) }]);
  results.QA_STATE_MUTATION_COUNT = mutations;

  /* ---- 3. empty first-use mode — isolated client tenant (fresh DOM) ---- */
  const dom2b = bootDom({ 'cr10.tenant': 'TEN-CLIENT-QA01', 'cr10.tenant.client': 'TEN-CLIENT-QA01', 'cr10.v18mode': 'empty' });
  const w2 = dom2b.window, d2 = w2.document;
  await new Promise(r => setTimeout(r, 300));
  d2.getElementById('enterPlatform').click();
  await new Promise(r => setTimeout(r, 150));
  const s3 = [];
  s3.push({ name: 'client tenant namespace active', pass: w2.App.State.tenantNamespace === 'TEN-CLIENT-QA01', detail: w2.App.State.tenantNamespace });
  s3.push({ name: 'no organization (pending sentinel)', pass: w2.App.Data.demo.organization.pending === true && w2.App.Data.demo.organization.name_en === '', detail: '' });
  s3.push({ name: 'no reporting cycle (pending sentinel)', pass: w2.App.Data.demo.cycle.pending === true && w2.App.Data.demo.cycle.label === '', detail: '' });
  s3.push({ name: 'no records', pass: w2.App.State.records.length === 0, detail: String(w2.App.State.records.length) });
  s3.push({ name: 'no evidence', pass: w2.App.State.evidence.length === 0, detail: '' });
  s3.push({ name: 'no impacts / topics / findings', pass: w2.App.State.impacts.length===0 && w2.App.State.materialTopics.length===0 && w2.App.State.findings.length===0, detail: '' });
  s3.push({ name: 'GRI 2 reset to MISSING', pass: (w2.App.State.gri2 || []).every(g => g.status === 'MISSING'), detail: '' });
  const cl = w2.App.GRI.evaluateClaim();
  s3.push({ name: 'claim guard: NOT_EVALUATED / PRECONDITION_ORG_CYCLE', pass: cl && cl.result==='NOT_EVALUATED' && cl.reason==='PRECONDITION_ORG_CYCLE', detail: JSON.stringify(cl) });
  const gt = w2.App.Gates.reEvaluate();
  s3.push({ name: 'gates guard: not evaluated pre-setup', pass: Array.isArray(gt) && gt.length === 0, detail: String(gt.length) });
  const ci0 = w2.App.GRI.contentIndex();
  s3.push({ name: 'content index guard pre-setup', pass: ci0.status==='NOT_GENERATED' && ci0.reason==='PRECONDITION_ORG_CYCLE', detail: ci0.status });
  s3.push({ name: 'routed to organization setup (X-SETUP)', pass: w2.V41.state.active === 'X-SETUP', detail: w2.V41.state.active });
  /* banned demo text scan on rendered DOM (P0-3) */
  w2.V18.syncBanner();
  await new Promise(r => setTimeout(r, 80));
  const visText = () => (d2.getElementById('app')?.textContent || '') + ' ' +
    (d2.getElementById('v18Banner')?.textContent || '') + ' ' +
    (d2.getElementById('v18Mode')?.textContent || '') + ' ' +
    (d2.getElementById('standaloneLogin')?.textContent || '');
  const bodyTxt = visText();
  const banned = ['Delta Industrial', 'دلتا الصناعية', 'FY2025', 'demonstration data'];
  const leaks = banned.filter(t => bodyTxt.includes(t));
  s3.push({ name: 'DOM contains zero demo text (Delta/FY2025/demonstration)', pass: leaks.length === 0, detail: leaks.join(',') });
  /* navigating to a data screen shows the precondition card, not demo content */
  w2.V41.go('D-03');
  await new Promise(r => setTimeout(r, 80));
  s3.push({ name: 'data screens gated pre-setup (NO_ORGANIZATION card)', pass: visText().includes('NO_ORGANIZATION'), detail: '' });
  const leaks2 = banned.filter(t => visText().includes(t));
  s3.push({ name: 'gated screen leaks no demo text', pass: leaks2.length === 0, detail: leaks2.join(',') });
  /* empty-workspace banner present */
  const b2 = d2.getElementById('v18Banner');
  s3.push({ name: 'empty-workspace banner with tenant id', pass: !!b2 && /EMPTY WORKSPACE/.test(b2.textContent) && b2.textContent.includes('TEN-CLIENT-QA01'), detail: '' });
  /* cross-tenant permission: a demo-tenant object is refused in the client tenant */
  const foreign = { id:'REC-X', tenantId:'TEN-EEG', status:'APPROVED' };
  const px = w2.App.Permissions.canPerformAction({ permission:'view', object: foreign });
  s3.push({ name: 'cross-tenant object refused (TENANT_ISOLATION)', pass: px.allowed===false && px.code==='TENANT_ISOLATION', detail: px.code });
  /* create real org + cycle, guards lift */
  const org = w2.App.Tenant.createOrganization({ name_en: 'QA Real Org', sector: 'Manufacturing', hq: 'Cairo', country: 'EG', employees: 100, replaceData: true });
  s3.push({ name: 'create organization succeeds', pass: org.ok === true, detail: org.code || '' });
  s3.push({ name: 'tenant owned after creation', pass: w2.App.State.tenantOwned === true, detail: '' });
  const cyc = w2.App.Tenant.setCycle({ label: 'FY2026', periodStart: '2026-01-01', periodEnd: '2026-12-31', targetApproach: 'IN_ACCORDANCE' });
  s3.push({ name: 'create reporting cycle succeeds', pass: cyc.ok === true, detail: cyc.code || '' });
  const cl2 = w2.App.GRI.evaluateClaim();
  s3.push({ name: 'claim evaluates for real after setup', pass: cl2 && ['IN_ACCORDANCE','WITH_REFERENCE','NOT_ELIGIBLE','BLOCKED'].includes(cl2.result), detail: cl2 && cl2.result });
  const gt2 = w2.App.Gates.reEvaluate();
  s3.push({ name: 'fifteen gates evaluate after setup', pass: gt2.length === 15, detail: String(gt2.length) });
  const nr = w2.App.Records.create({activityId:'ACT-ENE-005',entityId:'LE-02',siteId:'SITE-03',periodStart:'2026-01-01',periodEnd:'2026-01-31',periodLabel:'2026-01',dimensions:{meter:'MTR-1'},rawValue:10,rawUnit:'kg',dataSource:'x'});
  s3.push({ name: 'new records carry client tenant id', pass: nr.ok && nr.record.tenantId === 'TEN-CLIENT-QA01', detail: nr.record && nr.record.tenantId });
  section('Empty first-use · isolated client tenant', s3);

  /* ---- report ---- */
  const totals = results.sections.reduce((a, s) => { a.t += s.steps.length; a.p += s.steps.filter(x => x.pass).length; return a; }, { t: 0, p: 0 });
  results.total = totals.t; results.passed = totals.p; results.failed = totals.t - totals.p;
  const OUT_DIR = path.join(__dirname, 'output'); fs.mkdirSync(OUT_DIR, { recursive: true });
  fs.writeFileSync(path.join(OUT_DIR, 'QA_REPORT_v18.json'), JSON.stringify(results, null, 2));
  let md = '# v18 QA Report (Node/jsdom)\n\n' +
    '- Date: ' + results.at + '\n- Total steps: ' + results.total + '\n- Passed: ' + results.passed + '\n- Failed: ' + results.failed +
    '\n- QA_STATE_MUTATION_COUNT: **' + results.QA_STATE_MUTATION_COUNT + '**\n\n' +
    '> Environment note: no Chromium/Playwright is available in this build sandbox; the browser UI/screenshot suite is replaced by a jsdom harness executing the same domain assertions. Recorded in the Design Deviation Register.\n\n';
  results.sections.forEach(s => {
    md += '## ' + s.name + ' — ' + (s.pass ? 'PASS' : 'FAIL') + '\n\n| Step | Result | Detail |\n|---|---|---|\n';
    s.steps.forEach(x => { md += '| ' + x.name + ' | ' + (x.pass ? '✅' : '❌') + ' | ' + String(x.detail || '').replace(/\|/g, '/') + ' |\n'; });
    md += '\n';
  });
  fs.writeFileSync(path.join(OUT_DIR, 'QA_REPORT_v18.md'), md);
  console.log(JSON.stringify({ pass: results.pass, total: results.total, passed: results.passed, failed: results.failed, QA_STATE_MUTATION_COUNT: results.QA_STATE_MUTATION_COUNT }, null, 2));
  if (!results.pass) { results.sections.forEach(s => s.steps.filter(x => !x.pass).forEach(x => console.error('FAIL:', s.name, '→', x.name, x.detail))); process.exit(1); }
})();
