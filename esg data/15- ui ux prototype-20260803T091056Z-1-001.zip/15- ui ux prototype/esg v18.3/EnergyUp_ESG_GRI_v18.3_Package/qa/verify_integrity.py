#!/usr/bin/env python3
"""v18.2 release integrity: every file present in SHA256SUMS with a matching hash,
and no unlisted file in the tree (node_modules and SHA256SUMS itself excluded)."""
import hashlib, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SUMS = ROOT / 'SHA256SUMS.txt'
def sha(p): 
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''): h.update(chunk)
    return h.hexdigest()
listed = {}
for line in SUMS.read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    digest, path = line.split(None, 1)
    listed[path.strip().lstrip('./')] = digest
errors = []
actual = set()
for p in ROOT.rglob('*'):
    if p.is_dir(): continue
    rel = p.relative_to(ROOT).as_posix()
    if rel == 'SHA256SUMS.txt' or rel.startswith('node_modules/') or 'node_modules/' in rel or rel.startswith('qa/output/'): continue
    actual.add(rel)
    if rel not in listed: errors.append('UNLISTED: ' + rel)
    elif sha(p) != listed[rel]: errors.append('MISMATCH: ' + rel)
for rel in listed:
    if rel not in actual: errors.append('MISSING: ' + rel)
if errors:
    print('\n'.join(errors)); print('FAIL: %d integrity error(s)' % len(errors)); sys.exit(1)
print('PASS integrity verified: %d files' % len(listed))
