#!/usr/bin/env python3
from pathlib import Path
import json, hashlib
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'base/EnergyUp_ESG_GRI_Premium_UI_Clickable_v4.1_FIXED.html'
OUT=ROOT.parent/'EnergyUp_ESG_GRI_v17.1_v4_Live_Operational_Final.html'
src=BASE.read_text(encoding='utf-8'); edits=[]
def patch(find,repl,label):
 global src
 if find not in src: raise RuntimeError('anchor not found: '+label)
 src=src.replace(find,repl,1);edits.append(label)
patch("function renderScreen(s){\n if(!s) return","function renderScreen(s){\n if(window.V41_EXT&&window.V41_EXT.screen&&s){var _x=window.V41_EXT.screen(s);if(_x!=null)return `<div class=\"content\">${pageHeader(s)}${_x}</div>`;}\n if(!s) return","screen hook")
patch(" const body=state.active==='OVERVIEW'?overview():"," let _p=window.V41_EXT&&window.V41_EXT.page?window.V41_EXT.page(state.active):null;\n const body=_p!=null?`<div class=\"content\">${_p}</div>`:state.active==='OVERVIEW'?overview():","page hook")
patch("<button class=\"nav-overview ${state.active==='OVERVIEW'?'active':''}\" data-screen=\"OVERVIEW\">","${window.V41_EXT&&window.V41_EXT.navExtra?window.V41_EXT.navExtra():''}<button class=\"nav-overview ${state.active==='OVERVIEW'?'active':''}\" data-screen=\"OVERVIEW\">","nav extra")
patch("<button class=\"nav-screen ${state.active===s.id?'active':''}\" data-screen=\"${s.id}\">${icon(typeIcon(s.type))}","<button class=\"nav-screen ${state.active===s.id?'active':''}\" data-screen=\"${s.id}\">${window.V41_EXT&&window.V41_EXT.navDot?window.V41_EXT.navDot(s.id):''}${icon(typeIcon(s.type))}","status dots")
patch("document.querySelectorAll('[data-action]').forEach(el=>el.onclick=()=>{const a=el.dataset.action;","document.querySelectorAll('[data-action]').forEach(el=>el.onclick=()=>{const a=el.dataset.action;if(window.V41_EXT&&window.V41_EXT.action&&window.V41_EXT.action(a))return;","action hook")
patch("addEventListener('hashchange',","window.V41={state,render,go,toast,screen,card,kpi,badge,btn,icon,esc,tr,isAr,DATA,pageHeader,showModal:function(title,body,onSave){document.querySelectorAll('.x-modal').forEach(function(n){n.remove()});var m=document.createElement('div');m.className='x-modal';m.innerHTML='<div class=\"x-modal-card\"><div class=\"x-modal-head\"><h3>'+esc(title)+'</h3><button class=\"icon-btn\" data-x-close>✕</button></div><div class=\"x-modal-body\">'+body+'</div>'+(onSave?'<div class=\"x-modal-foot\"><button class=\"ghost-btn\" data-x-close>'+tr('Cancel','إلغاء')+'</button><button class=\"primary-btn\" data-x-save>'+tr('Save','حفظ')+'</button></div>':'')+'</div>';document.body.appendChild(m);m.querySelectorAll('[data-x-close]').forEach(function(b){b.onclick=function(){m.remove()}});var sv=m.querySelector('[data-x-save]');if(sv)sv.onclick=function(){var keep=onSave();if(keep!==false)m.remove()};m.onclick=function(e){if(e.target===m)m.remove()};return m;}};\naddEventListener('hashchange',","expose base")
order=['data/registry.js','data/library.js','data/journey.js','data/demo.js','modules/state.js','modules/translations.js','modules/audit.js','modules/permissions.js','modules/units.js','modules/calculations.js','modules/records.js','modules/evidence.js','modules/materiality.js','modules/gri.js','modules/gates.js','modules/principles.js','modules/journey.js','modules/tenant.js']
engine='\n'.join(';/* ===== '+f+' ===== */\n'+(ROOT/f).read_text(encoding='utf-8') for f in order)
css=(ROOT/'extension.css').read_text(encoding='utf-8');ext=(ROOT/'extension.js').read_text(encoding='utf-8')
src=src.replace('</head>','<style>\n'+css+'\n</style>\n</head>',1)
src=src.replace('</body>','<script>\n'+engine+'\n</script><script>\n'+ext+'\n</script></body>',1)
OUT.write_text(src,encoding='utf-8')
print(json.dumps({'output':OUT.name,'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'patches':edits,'engineModules':len(order)},indent=2))
