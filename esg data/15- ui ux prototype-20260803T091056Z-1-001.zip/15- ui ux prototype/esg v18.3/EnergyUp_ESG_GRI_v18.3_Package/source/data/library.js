/* CR-10 · data/library.js
   Controlled content-as-data libraries. No formula, factor, permission or gate
   rule is written in application code — every one of them is a managed object
   in this file and is versioned, sourced and approvable.
   ========================================================================== */
window.App = window.App || {}; App.Data = App.Data || {};

/* ------------------------------------------------- unit conversion registry ---
   CR-10.1 · P0-09 — every conversion is an identified, versioned, approved
   object rather than an anonymous multiplication inside the engine.          */
App.Data.conversions = [
  {id:'CNV-ENE-001', from:'Wh',    to:'kWh',   family:'energy',   factor:0.001,    formula:'kWh = Wh ÷ 1000',            version:'1.0', effectiveFrom:'2025-01-01', approval:'APPROVED', approvedBy:'Methodology Owner', source:'SI definition'},
  {id:'CNV-ENE-002', from:'kWh',   to:'MWh',   family:'energy',   factor:0.001,    formula:'MWh = kWh ÷ 1000',           version:'1.0', effectiveFrom:'2025-01-01', approval:'APPROVED', approvedBy:'Methodology Owner', source:'SI definition'},
  {id:'CNV-ENE-003', from:'MWh',   to:'GWh',   family:'energy',   factor:0.001,    formula:'GWh = MWh ÷ 1000',           version:'1.0', effectiveFrom:'2025-01-01', approval:'APPROVED', approvedBy:'Methodology Owner', source:'SI definition'},
  {id:'CNV-ENE-004', from:'kWh',   to:'GJ',    family:'energy',   factor:0.0036,   formula:'GJ = kWh × 0.0036',          version:'1.0', effectiveFrom:'2025-01-01', approval:'APPROVED', approvedBy:'Methodology Owner', source:'1 kWh = 3.6 MJ'},
  {id:'CNV-ENE-005', from:'MJ',    to:'GJ',    family:'energy',   factor:0.001,    formula:'GJ = MJ ÷ 1000',             version:'1.0', effectiveFrom:'2025-01-01', approval:'APPROVED', approvedBy:'Methodology Owner', source:'SI definition'},
  {id:'CNV-MAS-001', from:'g',     to:'kg',    family:'mass',     factor:0.001,    formula:'kg = g ÷ 1000',              version:'1.0', effectiveFrom:'2025-01-01', approval:'APPROVED', approvedBy:'Methodology Owner', source:'SI definition'},
  {id:'CNV-MAS-002', from:'kg',    to:'t',     family:'mass',     factor:0.001,    formula:'t = kg ÷ 1000',              version:'1.0', effectiveFrom:'2025-01-01', approval:'APPROVED', approvedBy:'Methodology Owner', source:'SI definition'},
  {id:'CNV-VOL-001', from:'litre', to:'m3',    family:'volume',   factor:0.001,    formula:'m³ = litre ÷ 1000',          version:'1.0', effectiveFrom:'2025-01-01', approval:'APPROVED', approvedBy:'Methodology Owner', source:'SI definition'},
  {id:'CNV-GHG-001', from:'kgCO2e',to:'tCO2e', family:'emissions',factor:0.001,    formula:'tCO2e = kgCO2e ÷ 1000',      version:'1.0', effectiveFrom:'2025-01-01', approval:'APPROVED', approvedBy:'Methodology Owner', source:'SI definition'},
  {id:'CNV-TIM-001', from:'hours', to:'days',  family:'time',     factor:0.0416667,formula:'days = hours ÷ 24',          version:'1.0', effectiveFrom:'2025-01-01', approval:'APPROVED', approvedBy:'Methodology Owner', source:'calendar definition'},
  {id:'CNV-FX-001',  from:'USD',   to:'EGP',   family:'currency', factor:null,     formula:'EGP = USD × rate',           version:'0.0', effectiveFrom:null,        approval:'NOT_APPROVED', approvedBy:null,
   source:'No approved FX source, date or version. Currency conversion is blocked until a rate is sourced and signed off (GAP-10).'}
];

/* ---------------------------------------------------------------- roles --- */
App.Data.roles = [
  {code:'PLATFORM_ADMIN',      en:'Platform Administrator',  ar:'مدير المنصة',            scope:'platform'},
  {code:'ORG_ADMIN',           en:'Organization Administrator', ar:'مدير المنظمة',        scope:'organization'},
  {code:'ESG_PROGRAMME_MANAGER',en:'ESG Programme Manager',  ar:'مدير برنامج الاستدامة',  scope:'cycle'},
  {code:'METHODOLOGY_OWNER',   en:'Methodology Owner',       ar:'مالك المنهجية',          scope:'tenant'},
  {code:'DATA_OWNER',          en:'Data Owner',              ar:'مالك البيانات',          scope:'department'},
  {code:'DATA_CONTRIBUTOR',    en:'Data Contributor',        ar:'مُدخل البيانات',         scope:'department'},
  {code:'ESG_TECH_REVIEWER',   en:'ESG Technical Reviewer',  ar:'المراجع الفني للاستدامة',scope:'cycle'},
  {code:'GOVERNANCE_APPROVER', en:'Governance Approver',     ar:'معتمد الحوكمة',          scope:'organization'},
  {code:'REPORT_AUTHOR',       en:'Report Author',           ar:'محرر التقرير',           scope:'cycle'},
  {code:'ASSURANCE_REVIEWER',  en:'Assurance Reviewer',      ar:'مراجع التأكيد',          scope:'engagement'},
  {code:'CONSULTANT',          en:'Consultant',              ar:'الاستشاري',              scope:'engagement'},
  {code:'EXECUTIVE_VIEWER',    en:'Executive Viewer',        ar:'مستعرض تنفيذي',          scope:'organization'},
  {code:'VIEWER',              en:'Viewer',                  ar:'مستعرض',                 scope:'organization'}
];

/* ------------------------------------------------------- permission matrix --- */
/* action → roles allowed. Absence = denied. Conditions are evaluated separately
   by App.Permissions (owner, reviewer independence, object status, SoD).      */
App.Data.permissions = {
  /* CR-11 · the tenant's own data, factors and output */
  'org.manage'         : ['ESG_PROGRAMME_MANAGER','ORG_ADMIN','PLATFORM_ADMIN'],
  'cycle.manage'       : ['ESG_PROGRAMME_MANAGER','ORG_ADMIN'],
  'boundary.approve'   : ['ESG_PROGRAMME_MANAGER','GOVERNANCE_APPROVER'],
  'methodology.manage' : ['METHODOLOGY_OWNER'],
  'record.create'      : ['DATA_CONTRIBUTOR','DATA_OWNER','ESG_PROGRAMME_MANAGER','CONSULTANT'],
  'record.edit'        : ['DATA_CONTRIBUTOR','DATA_OWNER','ESG_PROGRAMME_MANAGER','CONSULTANT'],
  'record.validate'    : ['DATA_CONTRIBUTOR','DATA_OWNER','ESG_PROGRAMME_MANAGER','ESG_TECH_REVIEWER','CONSULTANT'],
  'record.submit'      : ['DATA_CONTRIBUTOR','DATA_OWNER','CONSULTANT'],
  'record.review'      : ['DATA_OWNER','ESG_TECH_REVIEWER','ESG_PROGRAMME_MANAGER'],
  'record.return'      : ['DATA_OWNER','ESG_TECH_REVIEWER','ESG_PROGRAMME_MANAGER'],
  'record.approve'     : ['ESG_TECH_REVIEWER','ESG_PROGRAMME_MANAGER'],
  'record.reopen'      : ['ESG_PROGRAMME_MANAGER','GOVERNANCE_APPROVER'],
  'evidence.upload'    : ['DATA_CONTRIBUTOR','DATA_OWNER','ESG_PROGRAMME_MANAGER','CONSULTANT'],
  'evidence.supersede' : ['DATA_OWNER','ESG_PROGRAMME_MANAGER'],
  'calculation.run'    : ['ESG_TECH_REVIEWER','METHODOLOGY_OWNER','ESG_PROGRAMME_MANAGER'],
  'materiality.assess' : ['ESG_TECH_REVIEWER','ESG_PROGRAMME_MANAGER','CONSULTANT'],
  'materiality.approve': ['GOVERNANCE_APPROVER'],
  'omission.request'   : ['ESG_TECH_REVIEWER','ESG_PROGRAMME_MANAGER'],
  'omission.approve'   : ['GOVERNANCE_APPROVER'],
  'gate.evaluate'      : ['ESG_PROGRAMME_MANAGER','ESG_TECH_REVIEWER','METHODOLOGY_OWNER','GOVERNANCE_APPROVER'],
  'report.author'      : ['REPORT_AUTHOR','ESG_PROGRAMME_MANAGER'],
  'report.approve'     : ['GOVERNANCE_APPROVER'],
  'assurance.review'   : ['ASSURANCE_REVIEWER'],
  'assurance.finding'  : ['ASSURANCE_REVIEWER'],
  'publication.release': ['GOVERNANCE_APPROVER'],
  'admin.manage'       : ['PLATFORM_ADMIN','ORG_ADMIN'],
  'methodology.manage' : ['METHODOLOGY_OWNER'],
  'buildspec.view'     : ['PLATFORM_ADMIN','METHODOLOGY_OWNER','ORG_ADMIN'],
  'view'               : ['PLATFORM_ADMIN','ORG_ADMIN','ESG_PROGRAMME_MANAGER','METHODOLOGY_OWNER','DATA_OWNER','DATA_CONTRIBUTOR','ESG_TECH_REVIEWER','GOVERNANCE_APPROVER','REPORT_AUTHOR','ASSURANCE_REVIEWER','CONSULTANT','EXECUTIVE_VIEWER','VIEWER']
};

/* ------------------------------------------------------------ SoD rules --- */
App.Data.sodRules = [
  {id:'SOD-01', rule:'A contributor may not approve a record they created or last edited.',            check:'self_approval'},
  {id:'SOD-02', rule:'A reviewer who edited the record loses reviewer independence on that record.',   check:'reviewer_independence'},
  {id:'SOD-03', rule:'Governance approval may not be delegated to a preparer of the same object.',     check:'governance_independence'},
  {id:'SOD-04', rule:'Assurance personnel may not hold any preparation role in the same engagement.',  check:'assurance_impartiality'},
  {id:'SOD-05', rule:'A viewer role holds no write or decision permission anywhere in the product.',   check:'read_only'},
  {id:'SOD-06', rule:'Cross-tenant object access is refused irrespective of role.',                    check:'tenant_isolation'},
  {id:'SOD-07', rule:'The reporting claim is computed; no role may write it.',                         check:'claim_computed'}
];

/* --------------------------------------------------------- unit registry --- */
/* Conversion is only ever performed inside a family. A cross-family request is
   an error, never a silent multiplication. */
App.Data.units = {
  families:{
    energy:      {base:'kWh',  units:{'Wh':0.001,'kWh':1,'MWh':1000,'GWh':1000000,'GJ':277.777778,'TJ':277777.778}},
    mass:        {base:'kg',   units:{'g':0.001,'kg':1,'t':1000,'tonne':1000,'lb':0.45359237}},
    volume:      {base:'m3',   units:{'litre':0.001,'L':0.001,'m3':1,'m³':1,'Nm3':1,'Nm³':1,'ML':1000,'gal':0.00378541}},
    ghg:         {base:'kgCO2e',units:{'gCO2e':0.001,'kgCO2e':1,'tCO2e':1000}},
    ratio:       {base:'ratio',units:{'ratio':1,'%':0.01,'percent':0.01}},
    time:        {base:'hour', units:{'hour':1,'hours':1,'day':8,'shift':8}},
    count:       {base:'count',units:{'count':1,'number':1,'FTE':1,'headcount':1}},
    currency:    {base:'EGP',  units:{'EGP':1,'USD':48.5,'SAR':12.93,'AED':13.2}},
    distance:    {base:'km',   units:{'m':0.001,'km':1,'mile':1.60934}},
    area:        {base:'m2',   units:{'m2':1,'ha':10000,'km2':1000000}},
    intensity:   {base:'kgCO2e/unit',units:{'kgCO2e/unit':1,'tCO2e/unit':1000}}
  },
  /* Which family a raw unit belongs to */
  familyOf:function(u){
    var f=App.Data.units.families;
    for(var k in f){ if(f[k].units[u]!==undefined) return k; }
    return null;
  }
};

/* ---------------------------------------------------------- factor sets --- */
/* NO DEFAULT EMISSION FACTORS SHIP ACTIVE. Every factor below is demo content,
   flagged approval:'DEMO_ONLY', and is refused by the calculation engine unless
   the cycle is explicitly a demo cycle. Production requires methodology-owner
   sign-off per factor. */
App.Data.factorSets = [
  {id:'FS-EG-GRID-2025', name:'Egypt national grid electricity', factorId:'EF-EG-ELEC-2025',
   value:0.458, unit:'kgCO2e/kWh', inputFamily:'energy', outputFamily:'ghg',
   source:'Demo placeholder — client-specific grid factor required', geography:'EG', year:2025,
   gwpSet:'IPCC AR6 (100-yr)', approval:'DEMO_ONLY', effectiveFrom:'2025-01-01', superseded:false},
  {id:'FS-DIESEL-2025', name:'Diesel stationary combustion', factorId:'EF-DIESEL-2025',
   value:2.68, unit:'kgCO2e/litre', inputFamily:'volume', outputFamily:'ghg',
   source:'Demo placeholder — supplier or national inventory factor required', geography:'GLOBAL', year:2025,
   gwpSet:'IPCC AR6 (100-yr)', approval:'DEMO_ONLY', effectiveFrom:'2025-01-01', superseded:false},
  {id:'FS-NG-2025', name:'Natural gas combustion', factorId:'EF-NG-2025',
   value:2.02, unit:'kgCO2e/Nm3', inputFamily:'volume', outputFamily:'ghg',
   source:'Demo placeholder — national inventory factor required', geography:'EG', year:2025,
   gwpSet:'IPCC AR6 (100-yr)', approval:'DEMO_ONLY', effectiveFrom:'2025-01-01', superseded:false},
  {id:'FS-LPG-2025', name:'LPG combustion by mass', factorId:'EF-LPG-2025',
   value:3.00, unit:'kgCO2e/kg', inputFamily:'mass', outputFamily:'ghg',
   source:'Demo placeholder — approved national or supplier-specific LPG factor required', geography:'GLOBAL', year:2025,
   gwpSet:'IPCC AR6 (100-yr)', approval:'DEMO_ONLY', effectiveFrom:'2025-01-01', superseded:false}
];

/* --------------------------------------------------- calculation library --- */
/* Each method declares its own domain and output unit. Nothing is expressed in
   tCO2e unless the method's outputFamily is ghg. */
App.Data.calculationMethods = [
  {id:'CALC-GHG-S2-LOC', name:'Scope 2 location-based emissions', version:'1.0', domain:'GHG emissions',
   formula:'emissions = electricity_kWh × grid_factor', inputFamily:'energy', outputUnit:'tCO2e', outputFamily:'ghg',
   factorSet:'FS-EG-GRID-2025', appliesTo:['ACT-ENE-001','ACT-ENE-002'],
   uncertainty:'Factor uncertainty ±5% (demo)', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:120000, unit:'kWh', expected:54.96, expectedUnit:'tCO2e'}},
  {id:'CALC-GHG-S1-DIESEL', name:'Scope 1 diesel combustion', version:'1.0', domain:'GHG emissions',
   formula:'emissions = diesel_litres × diesel_factor', inputFamily:'volume', outputUnit:'tCO2e', outputFamily:'ghg',
   factorSet:'FS-DIESEL-2025', appliesTo:['ACT-ENE-004'],
   uncertainty:'Factor uncertainty ±5% (demo)', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:18000, unit:'litre', expected:48.24, expectedUnit:'tCO2e'}},
  {id:'CALC-GHG-S1-LPG', name:'Scope 1 LPG combustion', version:'1.0', domain:'GHG emissions',
   formula:'emissions = LPG_kg × LPG_factor', inputFamily:'mass', outputUnit:'tCO2e', outputFamily:'ghg',
   factorSet:'FS-LPG-2025', appliesTo:['ACT-ENE-005'],
   uncertainty:'Factor uncertainty ±5% (demo)', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:1000, unit:'kg', expected:3, expectedUnit:'tCO2e'}},
  {id:'CALC-GHG-S1-NG', name:'Scope 1 natural gas combustion', version:'1.0', domain:'GHG emissions',
   formula:'emissions = natural_gas_Nm3 × gas_factor', inputFamily:'volume', outputUnit:'tCO2e', outputFamily:'ghg',
   factorSet:'FS-NG-2025', appliesTo:['ACT-ENE-003'],
   uncertainty:'Factor uncertainty ±5% (demo)', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:1000, unit:'Nm3', expected:2.02, expectedUnit:'tCO2e'}},
  {id:'CALC-ENE-TOTAL', name:'Total energy consumption within the organization', version:'1.0', domain:'Energy',
   formula:'total_energy = Σ energy_streams (normalised to kWh)', inputFamily:'energy', outputUnit:'MWh', outputFamily:'energy',
   factorSet:null, appliesTo:['ACT-ENE-001','ACT-ENE-002'],
   uncertainty:'Metering tolerance ±2%', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:120000, unit:'kWh', expected:120, expectedUnit:'MWh'}},
  {id:'CALC-WAT-WITHDRAW', name:'Water withdrawal', version:'1.0', domain:'Water',
   formula:'withdrawal = Σ source_volumes', inputFamily:'volume', outputUnit:'m3', outputFamily:'volume',
   factorSet:null, appliesTo:['ACT-WAT-001','ACT-WAT-002'],
   uncertainty:'Meter tolerance ±3%', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:4200, unit:'m3', expected:4200, expectedUnit:'m3'}},
  {id:'CALC-WST-DIVERT', name:'Waste diverted from disposal (share)', version:'1.0', domain:'Waste',
   formula:'share = diverted_mass ÷ total_generated_mass', inputFamily:'mass', outputUnit:'%', outputFamily:'ratio',
   denominatorActivities:['ACT-WST-001'], denominatorUnit:'t', denominatorScope:'site',
   factorSet:null, appliesTo:['ACT-WST-002'],
   uncertainty:'Weighbridge tolerance ±1%', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:0.62, unit:'ratio', expected:62, expectedUnit:'%'}},
  {id:'CALC-OHS-LTIFR', name:'Lost-time injury frequency rate', version:'1.0', domain:'Health and safety',
   formula:'LTIFR = (lost_time_injuries × 1,000,000) ÷ hours_worked', inputFamily:'count', outputUnit:'per 1,000,000 hours', ratioMultiplier:1000000, outputFamily:'ratio',
   denominatorActivities:['ACT-OHS-001'], denominatorUnit:'hours', denominatorScope:'entity',
   factorSet:null, appliesTo:['ACT-OHS-002'],
   uncertainty:'Hours-worked completeness', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:3, unit:'count', expected:1.5, expectedUnit:'per 1,000,000 hours', denominator:2000000}},
  {id:'CALC-HR-TURNOVER', name:'Employee turnover rate', version:'1.0', domain:'Workforce',
   formula:'rate = leavers ÷ average_headcount', inputFamily:'count', outputUnit:'%', outputFamily:'ratio',
   denominatorActivities:['ACT-HR-001'], denominatorUnit:'count', denominatorScope:'entity',
   factorSet:null, appliesTo:['ACT-HR-003'],
   uncertainty:'Average headcount basis', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:24, unit:'count', expected:12, expectedUnit:'%', denominator:200}},
  {id:'CALC-TRN-HOURS', name:'Average training hours per employee', version:'1.0', domain:'Training',
   formula:'average = training_hours ÷ headcount', inputFamily:'time', outputUnit:'hours/employee', outputFamily:'ratio',
   denominatorActivities:['ACT-HR-001'], denominatorUnit:'count', denominatorScope:'entity',
   factorSet:null, appliesTo:['ACT-HR-005'],
   uncertainty:'Attendance record completeness', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:4200, unit:'hour', expected:21, expectedUnit:'hours/employee', denominator:200}},
  {id:'CALC-GOV-CORRUPT', name:'Confirmed incidents of corruption', version:'1.0', domain:'Governance',
   formula:'count = Σ confirmed_incidents', inputFamily:'count', outputUnit:'count', outputFamily:'count',
   factorSet:null, appliesTo:['ACT-ACR-003'],
   uncertainty:'Case closure timing', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:0, unit:'count', expected:0, expectedUnit:'count'}},
  {id:'CALC-ECO-EVD', name:'Economic value distributed', version:'1.0', domain:'Economic',
   formula:'EVD = operating_costs + wages + payments_to_providers + payments_to_government + community_investment',
   inputFamily:'currency', outputUnit:'EGP', outputFamily:'currency',
   factorSet:null, appliesTo:['ACT-ECO-001'],
   uncertainty:'Ledger cut-off', effectiveFrom:'2025-01-01', superseded:false,
   worked:{input:412000000, unit:'EGP', expected:412000000, expectedUnit:'EGP'}}
];

/* ------------------------------------------------------ standards registry --- */
App.Data.standards = [
  {code:'GRI 1',  title:'Foundation',           version:'2021', type:'Universal', published:'2021-10-05', effectiveFrom:'2023-01-01', supersedes:'GRI 101:2016', supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 2',  title:'General Disclosures',  version:'2021', type:'Universal', published:'2021-10-05', effectiveFrom:'2023-01-01', supersedes:'GRI 102:2016', supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 3',  title:'Material Topics',      version:'2021', type:'Universal', published:'2021-10-05', effectiveFrom:'2023-01-01', supersedes:'GRI 103:2016', supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 101',title:'Biodiversity',         version:'2024', type:'Topic',     published:'2024-01-25', effectiveFrom:'2026-01-01', supersedes:'GRI 304:2016', supersededBy:null, earlyAdoption:true,  status:'ACTIVE'},
  {code:'GRI 102',title:'Climate Change',       version:'2025', type:'Topic',     published:'2025-06-25', effectiveFrom:'2027-01-01', supersedes:null,          supersededBy:null, earlyAdoption:true,  status:'FUTURE'},
  {code:'GRI 103',title:'Energy',               version:'2025', type:'Topic',     published:'2025-06-25', effectiveFrom:'2027-01-01', supersedes:'GRI 302:2016',supersededBy:null, earlyAdoption:true,  status:'FUTURE'},
  {code:'GRI 201',title:'Economic Performance', version:'2016', type:'Topic',     published:'2016-10-19', effectiveFrom:'2018-07-01', supersedes:null, supersededBy:null, earlyAdoption:false, status:'ACTIVE',
   partialSupersession:[{disclosure:'201-2', supersededBy:'GRI 102:2025', from:'2027-01-01'}]},
  {code:'GRI 205',title:'Anti-corruption',      version:'2016', type:'Topic',     published:'2016-10-19', effectiveFrom:'2018-07-01', supersedes:null, supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 302',title:'Energy',               version:'2016', type:'Topic',     published:'2016-10-19', effectiveFrom:'2018-07-01', supersedes:null, supersededBy:'GRI 103:2025', earlyAdoption:false, status:'ACTIVE_UNTIL_2026-12-31'},
  {code:'GRI 303',title:'Water and Effluents',  version:'2018', type:'Topic',     published:'2018-08-01', effectiveFrom:'2021-01-01', supersedes:null, supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 305',title:'Emissions',            version:'2016', type:'Topic',     published:'2016-10-19', effectiveFrom:'2018-07-01', supersedes:null, supersededBy:'GRI 102:2025', earlyAdoption:false, status:'ACTIVE_UNTIL_2026-12-31'},
  {code:'GRI 306',title:'Waste',                version:'2020', type:'Topic',     published:'2020-05-05', effectiveFrom:'2022-01-01', supersedes:'GRI 306:2016', supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 401',title:'Employment',           version:'2016', type:'Topic',     published:'2016-10-19', effectiveFrom:'2018-07-01', supersedes:null, supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 403',title:'Occupational Health and Safety', version:'2018', type:'Topic', published:'2018-06-12', effectiveFrom:'2021-01-01', supersedes:'GRI 403:2016', supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 404',title:'Training and Education',version:'2016', type:'Topic',    published:'2016-10-19', effectiveFrom:'2018-07-01', supersedes:null, supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 405',title:'Diversity and Equal Opportunity', version:'2016', type:'Topic', published:'2016-10-19', effectiveFrom:'2018-07-01', supersedes:null, supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 11', title:'Oil and Gas Sector',   version:'2021', type:'Sector',    published:'2021-10-05', effectiveFrom:'2023-01-01', supersedes:null, supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 12', title:'Coal Sector',          version:'2022', type:'Sector',    published:'2022-03-31', effectiveFrom:'2024-01-01', supersedes:null, supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 13', title:'Agriculture, Aquaculture and Fishing Sectors', version:'2022', type:'Sector', published:'2022-06-30', effectiveFrom:'2024-01-01', supersedes:null, supersededBy:null, earlyAdoption:false, status:'ACTIVE'},
  {code:'GRI 14', title:'Mining Sector',        version:'2024', type:'Sector',    published:'2024-02-01', effectiveFrom:'2026-01-01', supersedes:null, supersededBy:null, earlyAdoption:false, status:'ACTIVE'}
];

/* ------------------------------------------------- permitted omission set --- */
App.Data.omissionReasons = [
  {code:'NOT_APPLICABLE',  en:'Not applicable',                       ar:'غير منطبق',                  explanationRequired:true},
  {code:'LEGAL_PROHIBITION',en:'Legal prohibitions',                  ar:'حظر قانوني',                 explanationRequired:true},
  {code:'CONFIDENTIALITY', en:'Confidentiality constraints',          ar:'قيود السرية',                explanationRequired:true},
  {code:'UNAVAILABLE',     en:'Information unavailable or incomplete',ar:'المعلومات غير متاحة أو غير مكتملة', explanationRequired:true}
];
/* Disclosures that may never carry an omission. Enforced in App.GRI, not in the UI. */
App.Data.omissionBlocked = ['2-1','2-2','2-3','2-4','2-5','3-1','3-2'];

/* --------------------------------------------------- publication gates --- */
App.Data.gates = [
  {id:'PG-01', name:'Organization configuration',  ar:'إعداد المنظمة',            blocking:'HARD', inputs:['organization','legalEntities','sites'],  requires:{approvals:['ORG_ADMIN'],evidence:false}},
  {id:'PG-02', name:'Reporting boundary',          ar:'حدود التقرير',             blocking:'HARD', inputs:['boundaryEntities','boundaryImpact','boundaryGHG'], requires:{approvals:['GOVERNANCE_APPROVER'],evidence:true}},
  {id:'PG-03', name:'Applicable standards',        ar:'المعايير المنطبقة',        blocking:'HARD', inputs:['cycleStandards'],                        requires:{approvals:['METHODOLOGY_OWNER'],evidence:false}},
  {id:'PG-04', name:'Materiality approval',        ar:'اعتماد الجوهرية',          blocking:'HARD', inputs:['impacts','materialTopics'],              requires:{approvals:['GOVERNANCE_APPROVER'],evidence:true}},
  {id:'PG-05', name:'Data completeness',           ar:'اكتمال البيانات',          blocking:'HARD', inputs:['records','dataRequests'],                requires:{approvals:[],evidence:false}},
  {id:'PG-06', name:'Evidence completeness',       ar:'اكتمال الأدلة',            blocking:'HARD', inputs:['records','evidence'],                    requires:{approvals:[],evidence:true}},
  {id:'PG-07', name:'Calculation readiness',       ar:'جاهزية الحسابات',          blocking:'HARD', inputs:['calculationRuns','factorSets'],          requires:{approvals:['METHODOLOGY_OWNER'],evidence:false}},
  {id:'PG-08', name:'Validation completion',       ar:'اكتمال التحقق',            blocking:'HARD', inputs:['records'],                               requires:{approvals:[],evidence:false}},
  {id:'PG-09', name:'Technical review',            ar:'المراجعة الفنية',          blocking:'HARD', inputs:['records','findings'],                    requires:{approvals:['ESG_TECH_REVIEWER'],evidence:false}},
  {id:'PG-10', name:'GRI 2 completion',            ar:'اكتمال إفصاحات GRI 2',     blocking:'HARD', inputs:['gri2'],                                  requires:{approvals:[],evidence:false}},
  {id:'PG-11', name:'Topic disclosures completion',ar:'اكتمال إفصاحات الموضوعات', blocking:'HARD', inputs:['materialTopics','topicDisclosures'],     requires:{approvals:[],evidence:false}},
  {id:'PG-12', name:'Reasons for omission',        ar:'أسباب الحذف',              blocking:'HARD', inputs:['omissions'],                             requires:{approvals:['GOVERNANCE_APPROVER'],evidence:false}},
  {id:'PG-13', name:'Content Index',               ar:'فهرس المحتوى',             blocking:'HARD', inputs:['contentIndex'],                          requires:{approvals:[],evidence:false}},
  {id:'PG-14', name:'Governance approval',         ar:'اعتماد الحوكمة',           blocking:'HARD', inputs:['reportApproval'],                        requires:{approvals:['GOVERNANCE_APPROVER'],evidence:true}},
  {id:'PG-15', name:'Publication and assurance readiness', ar:'جاهزية النشر والتأكيد', blocking:'HARD', inputs:['assurance','claim','gates'],      requires:{approvals:['GOVERNANCE_APPROVER'],evidence:true}}
];

/* --------------------------------------- materiality threshold models --- */
App.Data.thresholdModels = [
  {id:'TM-01', version:'1.2', name:'Delta Industrial Group 2025 threshold', approvedBy:'GOVERNANCE_APPROVER',
   approvedOn:'2026-02-12', effectiveFrom:'2026-01-01', sector:'Industrial manufacturing',
   negativeThreshold:12, positiveThreshold:10,
   /* CR-10.1 · P0-15 — a single machine-readable override. v1.0 documented
      severity>=4 in prose while the engine applied severity>=12; the two are
      now one field, read by the engine, the screens and the tests alike. */
   humanRightsOverride:{enabled:true, notDisableable:true, severityFloor:4,
     statement:'A potential negative human-rights impact whose severity reaches the floor is material regardless of likelihood.',
     statementAr:'التأثير السلبي المحتمل على حقوق الإنسان الذي تبلغ شدته الحد الأدنى يُعد جوهريًا بغض النظر عن الاحتمال.'},
   humanRightsFloor:'severity >= 4 is always material (non-compensatory)',
   calibrationNotes:'Anchors 1–5 defined per component; inter-assessor agreement 0.81 on the 12-impact calibration set.',
   changeHistory:[{v:'1.0',note:'Initial model',on:'2026-01-08'},{v:'1.1',note:'Human-rights floor added',on:'2026-01-27'},{v:'1.2',note:'Positive threshold separated from negative',on:'2026-02-12'}]}
];

/* ------------------------------------------------- validation rule set --- */
App.Data.validationRules = [
  {id:'VR-COM-001', severity:'BLOCKER', stage:'submit', en:'A value is mandatory for a shall-level datapoint.',            ar:'القيمة إلزامية لنقطة بيانات بمستوى shall.'},
  {id:'VR-LOG-003', severity:'BLOCKER', stage:'entry',  en:'The value must be numeric.',                                    ar:'القيمة يجب أن تكون رقمية.'},
  {id:'VR-LOG-005', severity:'BLOCKER', stage:'entry',  en:'A negative activity quantity is refused. Raise a restatement.', ar:'الكمية السالبة مرفوضة. استخدم إعادة عرض.'},
  {id:'VR-UOM-004', severity:'BLOCKER', stage:'entry',  en:'The unit must belong to the declared unit family.',             ar:'الوحدة يجب أن تنتمي إلى عائلة الوحدة المعلنة.'},
  {id:'VR-PER-001', severity:'BLOCKER', stage:'entry',  en:'The reporting period is required and must sit inside the cycle.',ar:'فترة التقرير مطلوبة ويجب أن تقع داخل الدورة.'},
  {id:'VR-EVD-001', severity:'BLOCKER', stage:'submit', en:'This datapoint requires linked evidence before submission.',    ar:'هذه النقطة تتطلب دليلًا مرتبطًا قبل الإرسال.'},
  {id:'VR-SIT-002', severity:'BLOCKER', stage:'entry',  en:'The site must sit inside the approved reporting boundary.',     ar:'الموقع يجب أن يقع داخل حدود التقرير المعتمدة.'},
  {id:'VR-EST-001', severity:'BLOCKER', stage:'submit', en:'An estimated value requires a documented estimation basis.',    ar:'القيمة المقدّرة تتطلب أساس تقدير موثقًا.'},
  {id:'VR-TRD-001', severity:'WARNING', stage:'submit', en:'Variance against the prior period exceeds 25%. Explain it.',    ar:'التباين مقابل الفترة السابقة يتجاوز 25%. يجب تفسيره.'},
  {id:'VR-DUP-001', severity:'BLOCKER', stage:'entry',  en:'A record already exists for this activity, site and period.',   ar:'يوجد سجل بالفعل لهذا النشاط والموقع والفترة.'}
];

/* ----------------------------------------------------- decision register --- */
App.Data.decisions = [
  {id:'DEC-01', decision:'The reporting claim is computed at the claim engine and is never user-writable.', status:'CLOSED', owner:'Methodology Owner', basis:'GRI 1:2021 requirements 1–9'},
  {id:'DEC-02', decision:'Standards are keyed on standard_code + publication_year; a unique key on code alone is refused.', status:'CLOSED', owner:'Methodology Owner', basis:'GRI reuse of codes 101/102/103/306'},
  {id:'DEC-03', decision:'No default emission factor ships active; every factor requires named sign-off.', status:'CLOSED', owner:'Methodology Owner', basis:'ISO 14064-1:2018 §6'},
  {id:'DEC-04', decision:'Seven disclosures are hard-blocked from omission (2-1…2-5, 3-1, 3-2).', status:'CLOSED', owner:'Methodology Owner', basis:'GRI 1:2021 requirement 6'},
  {id:'DEC-05', decision:'Three boundaries are modelled separately: reporting entities, impact/value chain, GHG organizational.', status:'CLOSED', owner:'ESG Technical Domain Lead', basis:'GRI 2-2 vs GRI 3-1 vs ISO 14064-1 §5'},
  {id:'DEC-06', decision:'Materiality significance is impact-based; stakeholder survey scores are schema-isolated from it.', status:'CLOSED', owner:'ESG Technical Domain Lead', basis:'GRI 3:2021'},
  {id:'DEC-07', decision:'Severity outranks likelihood for potential negative human-rights impacts; not configurable.', status:'CLOSED', owner:'ESG Technical Domain Lead', basis:'UNGPs / OECD Due Diligence Guidance'},
  {id:'DEC-08', decision:'The audit log is append-only; UPDATE and DELETE are revoked at grant level.', status:'CLOSED', owner:'Platform Administrator', basis:'ISAE 3000 (Revised) evidence integrity'},
  {id:'DEC-09', decision:'Product-development metrics are confined to Administration → Product Build Specification.', status:'CLOSED', owner:'Product Owner', basis:'CR-10 brief §2'},
  {id:'DEC-10', decision:'Role switching exists only inside a marked Demo/Developer control and never as a production action.', status:'CLOSED', owner:'Product Owner', basis:'CR-10 brief §5.1'},
  {id:'DEC-11', decision:'GRI licensing route (internal tool vs commercial SaaS) — unresolved; blocks commercial release.', status:'OPEN', owner:'Extreme Energy Group', basis:'GRI Copyright and Trademark Policy'},
  {id:'DEC-12', decision:'GRI Sector Standards 11–14 topic sets are registered but not yet populated with topic rows.', status:'OPEN', owner:'Methodology Owner', basis:'GRI Sector Program'}
];

/* ---------------------------------------------------------- gap register --- */
App.Data.gaps = [
  {id:'GAP-01', area:'Backend',    severity:'BLOCKER', gap:'No server-side enforcement: this build proves rules in the client only.', owner:'Engineering', action:'Implement PostgreSQL RLS + API guards mirroring App.Permissions', due:'Slice-1'},
  {id:'GAP-02', area:'Evidence',   severity:'BLOCKER', gap:'File hashes are simulated; no real SHA-256 over binary content.',        owner:'Engineering', action:'Compute SHA-256 server-side on upload; store digest with the object', due:'Slice-1'},
  {id:'GAP-03', area:'Content',    severity:'BLOCKER', gap:'Topic Standard disclosure rows are seeded for the demo topics only.',     owner:'ESG content workstream', action:'Load the full disclosure matrix (~2,774 datapoints) as managed content', due:'Content critical path'},
  {id:'GAP-04', area:'Legal',      severity:'BLOCKER', gap:'GRI licensing route unresolved; embedded GRI text is restricted.',        owner:'Extreme Energy Group', action:'Resolve internal-tool vs commercial-SaaS route before any client release', due:'Before launch'},
  {id:'GAP-05', area:'Sector',     severity:'MAJOR',   gap:'GRI 11–14 sector topic sets are registered but unpopulated.',             owner:'Methodology Owner', action:'Populate sector topics before any client in those sectors goes live', due:'Before sector client'},
  {id:'GAP-06', area:'Taxonomy',   severity:'MAJOR',   gap:'XBRL/iXBRL binding is designed but not implemented.',                     owner:'Engineering', action:'Import the official taxonomy package; never invent a QName', due:'Phase 2'},
  {id:'GAP-07', area:'Bilingual',  severity:'MAJOR',   gap:'Arabic parity is complete for the shipped UI surface only.',              owner:'Methodology Owner', action:'Human review of every methodology and report string; record review status', due:'Slice-1'},
  {id:'GAP-08', area:'Regulatory', severity:'MAJOR',   gap:'Egyptian FRA overlay not yet mapped; Decision 36/2026 unverified.',       owner:'ESG Technical Domain Lead', action:'Verify the instrument directly, then map requirements to disclosures', due:'Before EG client'},
  {id:'GAP-09', area:'Assurance',  severity:'MINOR',   gap:'Sampling and test selection is not implemented in this build.',           owner:'Engineering', action:'Implement reproducible sampling with recorded method and seed', due:'Phase 2'}
]