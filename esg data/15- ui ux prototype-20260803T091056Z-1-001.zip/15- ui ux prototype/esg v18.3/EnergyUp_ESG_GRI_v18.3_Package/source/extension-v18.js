/* ===== v18.2 · Corrected Premium Operational Baseline overlay =======================
   Merges the v18.1 corrections INTO the full v17.1/v18.0 engine (no regression):
   - P0-2 canonical full-dimensional duplicate key lives in modules/records.js
   - P0-3 client tenants boot truly empty (modules/state.js) + precondition gating here
   - P0-4 per-tenant IndexedDB namespaces (modules/state.js) + tenant switch here
   - Mobile-safe top banner, collapsible to a pill; mode chooser; Ctrl/Cmd+K
   ==================================================================================== */
(function () {
  'use strict';
  if (!window.App || !window.V41) return;
  var App = window.App, V = window.V41;
  var MODE_KEY = 'cr10.v18mode';      /* 'demo' | 'empty' */
  var TENANT_KEY = 'cr10.tenant';     /* 'TEN-EEG' | 'TEN-CLIENT-XXXX' */
  var CLIENT_KEY = 'cr10.tenant.client';

  function tr(en, ar) { return (App.State.lang === 'ar') ? ar : en; }
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function getMode() { return lsGet(MODE_KEY); }
  function isClient() { return !!App.State.isClientTenant; }
  function preSetup() { return isClient() && !App.State.tenantOwned; }

  /* ---------- precondition guards on the engines (P0-3) ---------- */
  var _claim = App.GRI.evaluateClaim, _index = App.GRI.contentIndex, _gates = App.Gates.reEvaluate;
  App.GRI.evaluateClaim = function () {
    if (preSetup()) { App.State.claim = { result: 'NOT_EVALUATED', reason: 'PRECONDITION_ORG_CYCLE' }; return App.State.claim; }
    return _claim.apply(App.GRI, arguments);
  };
  App.GRI.contentIndex = function () {
    if (preSetup()) return { status: 'NOT_GENERATED', reason: 'PRECONDITION_ORG_CYCLE', rows: [] };
    return _index.apply(App.GRI, arguments);
  };
  App.Gates.reEvaluate = function () {
    if (preSetup()) { App.Gates._cache = null; return []; }
    return _gates.apply(App.Gates, arguments);
  };

  /* ---------- page gating before organization exists (P0-3) ---------- */
  var ALLOW_PRE = { 'X-SETUP': 1, 'X-EXPERT': 1 };
  function preconditionCard() {
    return '<div class="v18-precondition"><div class="card">' +
      '<div class="ic">🏢</div>' +
      '<div class="eyebrow">NO_ORGANIZATION · NO_REPORTING_CYCLE</div>' +
      '<h2>' + tr('Create your organization first', 'أنشئ منظمتك أولًا') + '</h2>' +
      '<p>' + tr('This workspace is empty. Claims, gates, the content index and reports remain NOT_EVALUATED until the organization and reporting cycle are created.',
        'مساحة العمل هذه فارغة. تظل حالة الادعاء والبوابات وفهرس المحتوى والتقارير NOT_EVALUATED حتى إنشاء المنظمة ودورة التقرير.') + '</p>' +
      '<button class="primary-btn" data-action="x-setup">' + tr('Create organization & reporting cycle', 'إنشاء المنظمة ودورة التقرير') + '</button>' +
      '</div></div>';
  }
  var EXT = window.V41_EXT;
  if (EXT) {
    var _screen = EXT.screen, _page = EXT.page;
    EXT.screen = function (s) {
      if (preSetup() && s && !ALLOW_PRE[s.id]) return preconditionCard();
      return _screen.apply(EXT, arguments);
    };
    EXT.page = function (id) {
      if (preSetup() && !ALLOW_PRE[id] &&
          (id === 'OVERVIEW' || id === 'X-PATH' || id === 'X-OUTPUT')) return preconditionCard();
      return _page.apply(EXT, arguments);
    };
  }

  /* setup form must never show demo defaults in a client tenant */
  function scrubSetupDefaults() {
    if (!preSetup()) return;
    ['xoName', 'xoNameAr', 'xoSector', 'xoHq', 'xoCountry', 'xoEmp', 'xoContact', 'xoEmail']
      .forEach(function (id) {
        var el = document.getElementById(id);
        if (el && !el.dataset.v18) { el.value = ''; el.dataset.v18 = '1'; }
      });
    var wipe = document.getElementById('xoWipe');
    if (wipe && !wipe.dataset.v18) { wipe.checked = true; wipe.dataset.v18 = '1'; }
    var banned = ['Delta Industrial', 'دلتا الصناعية', 'FY2025', 'demonstration data', 'بيانات عرض'];
    var app = document.getElementById('app');
    if (app) Array.prototype.forEach.call(app.querySelectorAll('p,span,strong,td,small,h2,h3,div'), function (n) {
      if (n.children.length === 0 && banned.some(function (b) { return (n.textContent || '').indexOf(b) > -1; })) n.textContent = '';
    });
  }

  /* ---------- tenant switching (P0-4) ---------- */
  function clientTenantId() {
    var id = lsGet(CLIENT_KEY);
    if (!id) {
      var a = new Uint8Array(4);
      if (window.crypto && crypto.getRandomValues) crypto.getRandomValues(a);
      else for (var i = 0; i < 4; i++) a[i] = (Date.now() >> (i * 8)) & 255;
      id = 'TEN-CLIENT-' + Array.prototype.map.call(a, function (b) { return b.toString(16).padStart(2, '0'); }).join('').toUpperCase();
      lsSet(CLIENT_KEY, id);
    }
    return id;
  }
  function switchTenant(ns, mode) {
    lsSet(MODE_KEY, mode); lsSet(TENANT_KEY, ns);
    location.reload(); /* state.js re-opens the namespaced database on boot */
  }

  function resetDemo() {
    lsSet(MODE_KEY, 'demo'); lsSet(TENANT_KEY, 'TEN-EEG');
    try { localStorage.removeItem('cr10.prefs--TEN-EEG'); } catch (e) {}
    try {
      if (window.indexedDB) {
        var rq = indexedDB.deleteDatabase('cr10-esg-gri--TEN-EEG');
        rq.onsuccess = rq.onerror = rq.onblocked = function () { location.reload(); };
        setTimeout(function () { location.reload(); }, 800);
        return;
      }
    } catch (e) {}
    location.reload();
  }

  /* ---------- mode chooser (first login) ---------- */
  function showModeChooser() {
    if (document.getElementById('v18Mode')) return;
    var w = document.createElement('div'); w.id = 'v18Mode';
    w.innerHTML = '<div class="v18-card">' +
      '<h2>' + tr('How do you want to start?', 'كيف تريد أن تبدأ؟') + '</h2>' +
      '<p class="lead">' + tr('Each workspace is stored in its own isolated tenant database. Nothing moves between the sandbox and your organization.',
        'كل مساحة عمل تُخزَّن في قاعدة بيانات مستقلة لكل مستأجر. لا شيء ينتقل بين البيئة التجريبية ومنظمتك.') + '</p>' +
      '<div class="v18-choices">' +
      '<button class="v18-choice" id="v18Empty"><span class="ic">🏢</span>' +
        '<h3>' + tr('Start empty — my organization', 'ابدأ فارغًا — منظمتي') + '</h3>' +
        '<p>' + tr('A clean client tenant: no organization, no cycle, no records, no evidence, no claim. First action: create the organization and reporting cycle.',
          'مستأجر عميل نظيف: بلا منظمة أو دورة أو سجلات أو أدلة أو ادعاء. أول إجراء: إنشاء المنظمة ودورة التقرير.') + '</p>' +
        '<span class="tagline">EMPTY FIRST-USE · TEN-CLIENT</span></button>' +
      '<button class="v18-choice demo" id="v18Demo"><span class="ic">🧪</span>' +
        '<h3>' + tr('Explore with demo data', 'استكشف ببيانات تجريبية') + '</h3>' +
        '<p>' + tr('A labelled sandbox with 100+ records, evidence, findings and gates — clearly marked, never client data.',
          'بيئة تجريبية مُعلّمة بأكثر من 100 سجل وأدلة وملاحظات وبوابات — موسومة بوضوح وليست بيانات عميل.') + '</p>' +
        '<span class="tagline">DEMO / SANDBOX · TEN-EEG</span></button>' +
      '</div></div>';
    document.body.appendChild(w);
    document.getElementById('v18Demo').onclick = function () {
      var cur = lsGet(TENANT_KEY);
      if (cur && cur !== 'TEN-EEG') return switchTenant('TEN-EEG', 'demo');
      lsSet(MODE_KEY, 'demo'); lsSet(TENANT_KEY, 'TEN-EEG');
      w.remove(); V.render(); syncBanner();
      V.toast(tr('Demo sandbox loaded — isolated tenant TEN-EEG.', 'حُمّلت البيئة التجريبية — مستأجر معزول TEN-EEG.'));
    };
    document.getElementById('v18Empty').onclick = function () {
      var id = clientTenantId();
      if (App.State.tenantNamespace === id) { lsSet(MODE_KEY, 'empty'); w.remove(); V.go('X-SETUP'); syncBanner(); return; }
      switchTenant(id, 'empty');
    };
  }

  /* ---------- top banner (mobile-safe, collapsible) ---------- */
  var collapsed = false;
  function bannerSpec() {
    if (getMode() === 'demo' && !isClient() && App.Tenant.isDemo())
      return { cls: '', html: '<span class="v18-text">⚠ ' +
        'DEMO DATA — NOT CLIENT DATA — NOT FOR REPORTING OR ASSURANCE</span>' +
        '<span class="v18-spacer"></span>' +
        '<button id="v18StartOrg">' + tr('Start my organization', 'ابدأ منظمتي') + '</button>' +
        '<button id="v18Reset">' + tr('Reset demo data', 'إعادة ضبط البيانات') + '</button>' +
        '<button class="v18-collapse" id="v18Coll" title="collapse">▾</button>' };
    if (preSetup())
      return { cls: 'info', html: '<span class="v18-text">ℹ ' +
        tr('EMPTY WORKSPACE — tenant ', 'مساحة عمل فارغة — المستأجر ') + App.State.tenantNamespace +
        tr(' — first action: create your organization and reporting cycle.', ' — أول إجراء: إنشاء المنظمة ودورة التقرير.') + '</span>' +
        '<span class="v18-spacer"></span>' +
        '<button id="v18GoSetup">' + tr('Create organization & cycle', 'إنشاء المنظمة والدورة') + '</button>' +
        '<button class="v18-collapse" id="v18Coll" title="collapse">▾</button>' };
    return null;
  }
  function syncBanner() {
    var spec = bannerSpec();
    var el = document.getElementById('v18Banner');
    if (!spec) {
      if (el) el.remove();
      document.body.classList.remove('v18-banner-top', 'v18-banner-collapsed');
      return;
    }
    if (!el) { el = document.createElement('div'); el.id = 'v18Banner'; document.body.appendChild(el); }
    el.className = spec.cls + (collapsed ? ' collapsed' : '');
    el.innerHTML = spec.html;
    document.body.classList.add('v18-banner-top');
    document.body.classList.toggle('v18-banner-collapsed', collapsed);
    var c = document.getElementById('v18Coll'); if (c) c.onclick = function () { collapsed = !collapsed; syncBanner(); };
    if (collapsed) el.onclick = function (e) { if (e.target.tagName !== 'BUTTON') { collapsed = false; syncBanner(); } };
    var r = document.getElementById('v18Reset'); if (r) r.onclick = function () {
      if (confirm(tr('Restore the original demo dataset? Sandbox changes will be discarded.', 'استعادة البيانات التجريبية الأصلية؟ ستُتجاهل تعديلات البيئة التجريبية.'))) resetDemo();
    };
    var s = document.getElementById('v18StartOrg'); if (s) s.onclick = function () { switchTenant(clientTenantId(), 'empty'); };
    var g = document.getElementById('v18GoSetup'); if (g) g.onclick = function () { V.go('X-SETUP'); };
  }

  /* ---------- Ctrl/Cmd + K ---------- */
  addEventListener('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && String(e.key).toLowerCase() === 'k') {
      var q = document.getElementById('globalSearch');
      if (q) { e.preventDefault(); q.focus(); q.select(); }
    }
  });

  /* ---------- login hook ---------- */
  var enter = document.getElementById('enterPlatform');
  if (enter) enter.addEventListener('click', function () {
    if (!getMode()) showModeChooser();
    if (getMode() === 'empty' && preSetup()) V.go('X-SETUP');
    syncBanner();
  });

  /* ---------- keep overlay synced across re-renders ---------- */
  var appRoot = document.getElementById('app');
  if (appRoot && window.MutationObserver) {
    var pending = false;
    new MutationObserver(function () {
      if (pending) return; pending = true;
      requestAnimationFrame(function () { pending = false; syncBanner(); scrubSetupDefaults(); });
    }).observe(appRoot, { childList: true, subtree: true });
  }
  var login = document.getElementById('standaloneLogin');
  if (login && login.classList.contains('hidden')) { if (!getMode()) showModeChooser(); }
  syncBanner();

  window.V18 = { version: '18.2.0', getMode: getMode, isClient: isClient, preSetup: preSetup,
    tenant: function () { return App.State.tenantNamespace; }, clientTenantId: clientTenantId,
    switchTenant: switchTenant, showModeChooser: showModeChooser, syncBanner: syncBanner,
    resetDemo: resetDemo, preconditionCard: preconditionCard };
})();
