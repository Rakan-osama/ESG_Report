/* ============================================================================
   v17.1 · v4.1 LIVE OPERATIONAL EXTENSION
   The v4.1 Premium UI file is the base. It is not rebuilt, restyled or
   reorganised — it is extended.

   v4.1 shipped a complete, polished interface over static mock content: the
   shell, the epic sidebar, the 66 screens, the icons and the visual language
   are all its own and are untouched here.

   This release preserves v4.1 as the exact visual and navigation base, then supplies the working v16 engine. It also closes the v17 gaps: the home dashboard is live, all 66 v4 screens have live bindings, and the 117-screen v16 scope is available only in Expert / Build Specification mode, and draws
   every result through v4.1's own helpers (card, kpi, badge, btn, icon), so a
   real value looks exactly like the mock it replaces.

   Added:
     · working data engine        records, evidence, validation, calculation
     · permissions and SoD        every action checked, refusals explained
     · materiality engine         impact-based, human-rights override
     · GRI claim engine           nine requirements, computed, never set
     · fifteen publication gates  each with reasons and remediation
     · append-only audit trail
     · YOUR organization          create your own company, entities, sites, cycle
     · YOUR emission factors      approve one with full provenance
     · YOUR output                report, content index, dataset, backup
     · persistence                IndexedDB, survives a reload
   ========================================================================== */
(function () {
  'use strict';
  var V = window.V41, App = window.App;
  if (!V || !App) { console.error('v4.1 extension: base not exposed'); return; }

  var esc = V.esc, tr = V.tr, card = V.card, kpi = V.kpi, badge = V.badge, btn = V.btn, icon = V.icon;

  /* ---------------------------------------------------------------- utils -- */
  function table(head, rows, note) {
    if (!rows.length) return '<div class="empty">' + esc(note || tr('No records yet.', 'لا توجد سجلات بعد.')) + '</div>';
    return '<div class="table-wrap"><table><thead><tr>' +
      head.map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
      rows.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + (c == null ? '' : c) + '</td>'; }).join('') + '</tr>'; }).join('') +
      '</tbody></table></div>';
  }
  function num(n) { return App.fmtNum ? App.fmtNum(n) : n; }
  function statusBadge(s) {
    var m = { APPROVED: 'success', COMPLETE: 'success', DONE: 'success', PASS: 'success',
      SUBMITTED: 'warn', UNDER_REVIEW: 'warn', IN_PROGRESS: 'warn', VALIDATED: 'info',
      RETURNED: 'danger', BLOCKED: 'danger', FAIL: 'danger', GAP: 'danger', MISSING: 'danger',
      DRAFT: '', NOT_STARTED: '', REOPENED: 'warn' };
    return badge(s, m[s] === undefined ? '' : m[s]);
  }
  function actionBar() {
    return '<div class="page-actions">' +
      btn(tr('My organization', 'منظمتي'), 'ghost', 'x-setup', 'building') +
      btn(tr('Output', 'المخرجات'), 'ghost', 'x-output', 'download') +
      btn(tr('Recheck', 'إعادة الفحص'), 'ghost', 'x-recheck', 'check') + '</div>';
  }

  /* ------------------------------------------------------- status per step -- */
  function stepStatus(id) { return App.Journey ? App.Journey.status(id) : 'NOT_STARTED'; }
  function stepDot(id) {
    var m = { DONE: 'success', IN_PROGRESS: 'warn', BLOCKED: 'danger', NOT_STARTED: '', SPECIFIED_NOT_BUILT: 'info' };
    return '<span class="x-dot ' + (m[stepStatus(id)] || '') + '"></span>';
  }

  /* ============================================================ live bodies == */
  var LIVE = {

    /* --- Epic B --- */
    'B-01': function () {
      var o = App.Data.demo.organization;
      return card(tr('Organization master record', 'السجل الرئيسي للمنظمة'),
        table([tr('Field', 'الحقل'), tr('Value', 'القيمة')], [
          [tr('Legal name', 'الاسم القانوني'), esc(o.name_en)],
          [tr('Arabic name', 'الاسم بالعربية'), esc(o.name_ar)],
          [tr('Sector', 'القطاع'), esc(o.sector)],
          [tr('Headquarters', 'المقر'), esc(o.hq)],
          [tr('Employees', 'العاملون'), o.employees],
          [tr('Identifier', 'المعرف'), '<code>' + esc(o.id) + '</code>']
        ]) + '<div style="margin-top:14px">' + btn(tr('Edit my organization', 'تعديل منظمتي'), 'primary', 'x-setup', 'edit') + '</div>',
        tr('Live record — edit it in My organization', 'سجل حي — يُعدَّل من شاشة منظمتي'));
    },
    'B-02': function () {
      var e = App.Data.demo.legalEntities;
      return card(tr('Legal entities', 'الكيانات القانونية') + ' (' + e.length + ')',
        table([tr('ID', 'المعرف'), tr('Name', 'الاسم'), tr('Country', 'الدولة'), tr('Consolidation', 'التجميع'), tr('Ownership', 'الملكية')],
          e.map(function (x) { return ['<code>' + esc(x.id) + '</code>', esc(x.name_en), esc(x.country), esc(x.consolidation || 'Full'), (x.ownership != null ? x.ownership + '%' : '—')]; }),
          tr('No legal entity yet — add one in My organization.', 'لا يوجد كيان — أضف واحدًا من شاشة منظمتي.')) +
        '<div style="margin-top:14px">' + btn(tr('Add legal entity', 'إضافة كيان'), 'primary', 'x-new-entity', 'plus') + '</div>');
    },
    'B-03': function () {
      var s = App.Data.demo.sites;
      return card(tr('Sites register', 'سجل المواقع') + ' (' + s.length + ')',
        table([tr('ID', 'المعرف'), tr('Site', 'الموقع'), tr('Entity', 'الكيان'), tr('Type', 'النوع'), tr('Country', 'الدولة'), tr('In boundary', 'داخل الحدود'), tr('Rationale', 'المبرر')],
          s.map(function (x) { return ['<code>' + esc(x.id) + '</code>', esc(x.name_en), esc(x.entity), esc(x.type), esc(x.country),
            x.inBoundary ? badge(tr('Yes', 'نعم'), 'success') : badge(tr('Excluded', 'مستبعد'), 'danger'), esc(x.exclusionRationale || '—')]; }),
          tr('No site yet — add one in My organization.', 'لا يوجد موقع — أضف واحدًا من شاشة منظمتي.')) +
        '<div style="margin-top:14px">' + btn(tr('Add site', 'إضافة موقع'), 'primary', 'x-new-site', 'plus') + '</div>');
    },
    'B-04': function () {
      var a = App.Data.registry.activities;
      return card(tr('Activity inputs', 'مدخلات الأنشطة') + ' (' + a.length + ')',
        table([tr('ID', 'المعرف'), tr('Activity', 'النشاط'), tr('Domain', 'المجال'), tr('Unit', 'الوحدة'), tr('Frequency', 'الدورية'), 'GRI'],
          a.slice(0, 20).map(function (x) { return ['<code>' + esc(x.activity_id) + '</code>', esc(x.name_en), esc(x.domain), esc(x.unit), esc(x.frequency), esc(x.gri_mapping)]; })) +
        '<p class="kpi-note" style="margin-top:10px">' + tr('Showing 20 of ', 'عرض ٢٠ من ') + a.length + tr('. All are searchable when you add a record.', '. جميعها قابلة للبحث عند إضافة سجل.') + '</p>');
    },
    'B-05': function () {
      var c = App.Data.demo.cycle;
      return card(tr('Reporting cycle', 'دورة التقرير'),
        table([tr('Field', 'الحقل'), tr('Value', 'القيمة')], [
          [tr('Cycle', 'الدورة'), esc(c.label)],
          [tr('Period', 'الفترة'), esc(c.periodStart) + ' → ' + esc(c.periodEnd)],
          [tr('GRI 1 version', 'إصدار GRI 1'), esc(c.gri1Version)],
          [tr('Target approach', 'المنهج المستهدف'), esc(c.targetApproach || 'IN_ACCORDANCE')],
          [tr('Sector standards', 'المعايير القطاعية'), esc((c.sectorStandards || []).join(', ') || tr('none applicable', 'لا ينطبق'))]
        ]) + '<div style="margin-top:14px">' + btn(tr('Edit cycle', 'تعديل الدورة'), 'primary', 'x-setup', 'calendar') + '</div>');
    },
    'B-07': function () {
      var b = App.Data.demo.boundaries;
      return ['entities', 'impact', 'ghg'].map(function (k) {
        var bb = b[k], label = { entities: tr('Reporting entities', 'كيانات التقرير'),
          impact: tr('Impact and value chain', 'التأثير وسلسلة القيمة'), ghg: tr('GHG organizational', 'الحدود التنظيمية') }[k];
        return card(label, '<p>' + esc(bb.basis || tr('No basis recorded.', 'لا يوجد أساس مسجل.')) + '</p>' +
          '<div style="margin-top:10px">' + (bb.approved ? badge(tr('Approved ', 'اعتُمدت ') + (bb.approvedOn || ''), 'success')
            : btn(tr('Approve boundary', 'اعتماد الحدود'), 'primary', 'x-approve-boundary-' + k, 'check')) + '</div>');
      }).join('');
    },
    'B-09': function () {
      return card(tr('Applicable standards', 'المعايير المنطبقة'),
        table([tr('Code', 'الرمز'), tr('Title', 'العنوان'), tr('Version', 'الإصدار'), tr('Effective from', 'يسري من'), tr('Supersedes', 'يحل محل'), tr('Status', 'الحالة')],
          App.Data.standards.map(function (x) { return ['<code>' + esc(x.code) + '</code>', esc(x.title), esc(x.version), esc(x.effectiveFrom), esc(x.supersedes || '—'), statusBadge(x.status)]; })));
    },
    'B-10': function () { return gri2Table(true); },
    'B-11': function () { return gri2Table(false); },
    'B-12': function () { return findings(); },
    'B-13': function () { return omissions(); },
    'B-14': function () { return gates(['PG-01', 'PG-02', 'PG-03']); },

    /* --- Epic C --- */
    'C-01': function () {
      var m = App.Materiality.model();
      return card(m.name + ' — v' + m.version,
        table([tr('Setting', 'الإعداد'), tr('Value', 'القيمة')], [
          [tr('Negative threshold', 'عتبة السلبي'), m.negativeThreshold],
          [tr('Positive threshold', 'عتبة الإيجابي'), m.positiveThreshold],
          [tr('Human-rights floor', 'حد حقوق الإنسان'), m.humanRightsOverride.severityFloor + ' — ' + tr('cannot be disabled', 'غير قابل للتعطيل')],
          [tr('Approved by', 'اعتمده'), esc(m.approvedBy)],
          [tr('Effective from', 'يسري من'), esc(m.effectiveFrom)]
        ]), esc(m.calibrationNotes));
    },
    'C-02': function () { return impacts(false); },
    'C-06': function () { return impacts(false); },
    'C-07': function () { return impacts(true); },
    'C-03': function () {
      return card(tr('Stakeholder groups', 'فئات أصحاب المصلحة'),
        table([tr('ID', 'المعرف'), tr('Group', 'الفئة'), tr('Type', 'النوع'), tr('Affected', 'متأثر'), tr('Engagement', 'المشاركة'), tr('Priority', 'الأولوية')],
          App.Data.registry.stakeholders.map(function (x) { return ['<code>' + esc(x.id) + '</code>', esc(x.group), esc(x.type), esc(x.affected), esc(x.engagement),
            x.priority === 'High' ? badge(x.priority, 'danger') : badge(x.priority)]; })));
    },
    'C-04': function () { return engagements(); },
    'C-05': function () { return engagements(); },
    'C-09': function () { return topics(); },
    'C-11': function () {
      var r = App.Materiality.ranked(), m = App.Materiality.model();
      function tbl(list, label, thr) {
        return card(label + ' — ' + tr('threshold ', 'العتبة ') + thr,
          table(['#', tr('Topic', 'الموضوع'), tr('Significance', 'الأهمية'), tr('Above threshold', 'فوق العتبة')],
            list.map(function (i, n) { return [n + 1, esc(i.topic), '<strong>' + i._score.significance + '</strong>',
              i._material ? badge(tr('Material', 'جوهري'), 'success') : badge(tr('Watchlist', 'مراقبة'))]; })));
      }
      return tbl(r.negative, tr('Negative impacts', 'التأثيرات السلبية'), m.negativeThreshold) +
             tbl(r.positive, tr('Positive impacts', 'التأثيرات الإيجابية'), m.positiveThreshold);
    },
    'C-12': function () {
      var ap = App.Materiality.approved();
      return card(tr('Governance approval', 'اعتماد الحوكمة'),
        (ap.length
          ? '<p>' + badge(tr('Approved and frozen', 'معتمدة ومجمّدة'), 'success') + ' ' +
            esc(tr('Approved on ', 'اعتُمدت بتاريخ ') + (ap[0].approvedOn || '').slice(0, 10)) + '</p>'
          : '<p>' + badge(tr('Not approved', 'غير معتمدة'), 'danger') + ' ' +
            esc(tr('Only the governance approver may approve the material topic list.', 'اعتماد قائمة الموضوعات من صلاحية معتمد الحوكمة وحده.')) + '</p>' +
            '<div style="margin-top:12px">' + btn(tr('Approve material topic list', 'اعتماد قائمة الموضوعات'), 'primary', 'x-approve-topics', 'check') + '</div>')) +
        topics();
    },

    /* --- Epic D --- */
    'D-01': function () { return LIVE['B-04'](); },
    'D-02': function () {
      var w = App.Records.myWork();
      return card(tr('My queue', 'قائمة مهامي') + ' (' + w.length + ')',
        table([tr('Action', 'الإجراء'), tr('Object', 'الكائن'), tr('Detail', 'التفصيل')],
          w.slice(0, 20).map(function (x) { return [badge(x.action, 'warn'), '<code>' + esc(x.objectId) + '</code>', esc(x.title)]; }),
          tr('Nothing assigned to this role.', 'لا يوجد مسند لهذا الدور.')));
    },
    'D-03': function () { return records(); },
    'D-05': function () { return evidence(); },
    'D-06': function () {
      return card(tr('Validation rule catalogue', 'دليل قواعد التحقق'),
        table([tr('Rule', 'القاعدة'), tr('Severity', 'الخطورة'), tr('Stage', 'المرحلة'), tr('Message', 'الرسالة')],
          App.Data.validationRules.map(function (r) { return ['<code>' + esc(r.id) + '</code>',
            badge(r.severity, r.severity === 'BLOCKER' ? 'danger' : r.severity === 'ERROR' ? 'warn' : 'info'),
            esc(r.stage), esc(App.L(r.en, r.ar))]; })));
    },
    'D-07': function () { return calcs(false); },
    'D-08': function () { return calcs(true); },
    'D-09': function () { return factors(); },
    'D-10': function () {
      var s = App.Records.stats();
      return '<div class="kpi-grid">' +
        kpi(tr('Completeness', 'الاكتمال'), s.completeness + '%', tr('of expected records', 'من السجلات المتوقعة'), 'database', 'blue') +
        kpi(tr('Evidence coverage', 'تغطية الأدلة'), s.evidenceCoverage + '%', tr('records with evidence', 'سجلات لها أدلة'), 'file') +
        kpi(tr('Validation pass', 'اجتياز التحقق'), s.validationPass + '%', tr('no blocking rule', 'بلا قاعدة حاجبة'), 'check', 'purple') +
        kpi(tr('Estimated', 'مقدّرة'), s.estimated, tr('values flagged', 'قيمة معلَّمة'), 'warning', 'amber') +
        '</div>' +
        card(tr('Assumption register', 'سجل الافتراضات'),
          table([tr('ID', 'المعرف'), tr('Assumption', 'الافتراض'), tr('Basis', 'الأساس'), tr('Affects', 'يؤثر على')],
            (App.Data.demo.assumptions || []).map(function (a) { return ['<code>' + esc(a.id) + '</code>', esc(a.statement), esc(a.basis), esc(a.affects)]; })));
    },

    /* --- Epic E --- */
    'E-01': function () { return queue('SUBMITTED'); },
    'E-02': function () { return queue('UNDER_REVIEW'); },
    'E-04': function () { return findings(); },
    'E-05': function () { return findings(); },
    'E-06': function () { return omissions() + gates(['PG-12']); },
    'E-07': function () {
      var c = App.State.claim || App.GRI.evaluateClaim();
      return card(tr('Computed reporting claim', 'ادعاء التقرير المحسوب'),
        '<p style="font-size:15px">' + statusBadge(c.result) + ' &nbsp; ' +
        esc(tr('Requirements satisfied: ', 'المتطلبات المستوفاة: ')) + '<strong>' + c.passed + ' / 9</strong></p>' +
        '<p class="kpi-note">' + esc(tr('The claim is computed from the nine requirements and cannot be set by any user.',
          'يُحسب الادعاء من المتطلبات التسعة ولا يستطيع أي مستخدم تعيينه.')) + '</p>') +
        card(tr('The nine requirements', 'المتطلبات التسعة'),
          table(['#', tr('Requirement', 'المتطلب'), tr('Result', 'النتيجة'), tr('Detail', 'التفصيل')],
            c.requirements.map(function (r) { return [r.n, esc(App.L(r.title, r.titleAr)),
              r.pass ? badge('PASS', 'success') : badge('FAIL', 'danger'), esc(App.L(r.detail, r.detailAr))]; })));
    },
    'E-08': function () {
      return App.Principles.results().map(function (p) {
        return card(p.id + ' · ' + App.L(p.principle, p.principleAr),
          table([tr('Control', 'الضابط'), tr('Question', 'السؤال'), tr('Finding', 'النتيجة'), tr('Result', 'النتيجة')],
            p.controls.map(function (c) { return ['<code>' + esc(c.id) + '</code>', esc(App.L(c.question, c.questionAr)),
              esc(App.L(c.found, c.foundAr)), c.pass ? badge('PASS', 'success') : badge('FAIL', 'danger')]; })),
          p.requirement + ' — ' + (p.pass ? tr('all mandatory controls pass', 'كل الضوابط الإلزامية مجتازة')
            : p.failedMandatory + tr(' mandatory control(s) failing', ' ضابط إلزامي غير مجتاز')));
      }).join('');
    },
    'E-09': function () { return contentIndex(); },
    'E-10': function () { return contentIndex(); },
    'E-11': function () {
      var c = App.State.claim || App.GRI.evaluateClaim(), s = c.statement || App.GRI.statementOfUse();
      return card(tr('Statement of use', 'عبارة الاستخدام'),
        '<p style="font-size:15px">' + esc(App.L(s.text, s.textAr)) + '</p>' +
        '<p>' + (s.valid ? badge(tr('Issuable', 'قابلة للإصدار'), 'success') : badge(tr('Not issuable yet', 'غير قابلة بعد'), 'danger')) + '</p>' +
        '<p class="kpi-note">' + esc(tr('Sequence: requirements 1–7 → provisional eligibility → provisional statement → validate → notification → final claim → lock.',
          'التسلسل: المتطلبات ١–٧ ← الأهلية المبدئية ← العبارة المبدئية ← التحقق ← الإخطار ← الادعاء النهائي ← القفل.')) + '</p>');
    },
    'E-12': function () { return gates(['PG-15']); },

    /* --- Epic F --- */
    'F-01': function () { return LIVE['B-05'](); },
    'F-05': function () { return calcs(true); },
    'F-07': function () {
      return card(tr('Report preview and export', 'معاينة التقرير وتصديره'),
        '<p>' + esc(tr('The report is generated from approved records only. Where the engine refused to compute a figure, the document says so rather than printing an unsupported number.',
          'يُولَّد التقرير من السجلات المعتمدة فقط. وحيث رفض المحرك احتساب رقم، يذكر المستند ذلك بدل طباعة رقم غير مدعوم.')) + '</p>' +
        '<div style="margin-top:14px;display:flex;gap:10px;flex-wrap:wrap">' +
        btn(tr('Download the report', 'نزّل التقرير'), 'primary', 'x-dl-report', 'download') +
        btn(tr('All output files', 'كل الملفات'), 'ghost', 'x-output', 'layers') + '</div>');
    },
    'F-12': function () { return findings('Assurance'); },
    'F-13': function () {
      return card(tr('Assurance workspace', 'مساحة عمل التأكيد'),
        '<p>' + esc(tr('The assurance role reads approved values, evidence and lineage. Every record mutation is refused for it by SOD-04.',
          'دور التأكيد يقرأ القيم المعتمدة والأدلة والتتبع. وتُرفض له كل عمليات تعديل السجلات بموجب SOD-04.')) + '</p>' +
        '<div style="margin-top:12px">' + btn(tr('Attempt to edit an approved record', 'حاول تعديل سجل معتمد'), 'danger', 'x-assurance-edit', 'warning') + '</div>') +
        findings('Assurance');
    },
    'F-14': function () { return findings('Assurance'); },
    'F-15': function () { return gates(['PG-15']); },
    'F-16': function () { return gates(['PG-14', 'PG-15']); },

    /* --- v17.1: the 16 previously static v4 screens now read live state --- */
    'B-06': function () { return cycleWizardLive(); },
    'B-08': function () { return sectorClassificationLive(); },
    'C-08': function () { return divergenceLive(); },
    'C-10': function () { return sectorReconciliationLive(); },
    'D-04': function () { return bulkImportLive(); },
    'D-11': function () { return comparativeLive(); },
    'D-12': function () { return restatementLive(); },
    'E-03': function () { return crossChecksLive(); },
    'F-02': function () { return reportStructureLive(); },
    'F-03': function () { return narrativeLive(); },
    'F-04': function () { return visualsLive(); },
    'F-06': function () { return bilingualLive(); },
    'F-08': function () { return exportCenterLive(); },
    'F-09': function () { return taxonomyBindingLive(); },
    'F-10': function () { return contextBuilderLive(); },
    'F-11': function () { return digitalValidationLive(); }
  };

  /* -------------------------------------------------------- shared bodies -- */
  function gri2Table(applic) {
    return card(applic ? tr('Disclosure applicability', 'انطباق الإفصاحات') : tr('GRI 2 assessment', 'تقييم GRI 2'),
      table([tr('Code', 'الرمز'), tr('Disclosure', 'الإفصاح'), tr('Section', 'القسم'), tr('Owner', 'المالك'),
        applic ? tr('Omission allowed', 'الحذف مسموح') : tr('Evidence', 'الأدلة'), tr('Status', 'الحالة')],
        (App.State.gri2 || []).map(function (d) {
          var blocked = App.Data.omissionBlocked.indexOf(d.code) > -1;
          return ['<code>' + esc(d.code) + '</code>', esc(App.L(d.title, d.title_ar)), esc(d.section), esc(d.owner),
            applic ? (blocked ? badge(tr('Never', 'ممنوع'), 'danger') : badge(tr('Permitted', 'مسموح'))) : d.evidence,
            statusBadge(d.status)];
        })));
  }
  function findings(src) {
    var f = App.State.findings.filter(function (x) { return !src || x.source === src; });
    return card(tr('Findings', 'الملاحظات') + ' (' + f.length + ')',
      table([tr('ID', 'المعرف'), tr('Source', 'المصدر'), tr('Severity', 'الخطورة'), tr('Object', 'الكائن'), tr('Finding', 'الملاحظة'), tr('Status', 'الحالة')],
        f.map(function (x) { return ['<code>' + esc(x.id) + '</code>', esc(x.source),
          badge(x.severity, x.severity === 'MAJOR' ? 'danger' : 'warn'), '<code>' + esc(x.object) + '</code>',
          esc(x.text), statusBadge(x.status)]; }),
        tr('No findings raised.', 'لا توجد ملاحظات.')));
  }
  function omissions() {
    return card(tr('Reasons for omission', 'أسباب الحذف'),
      '<p class="kpi-note">' + esc(tr('Only four reasons are permitted, and seven disclosures may never carry one: ',
        'أربعة أسباب فقط مسموحة، وسبعة إفصاحات لا يجوز حذفها: ') + App.Data.omissionBlocked.join(', ')) + '</p>' +
      table([tr('ID', 'المعرف'), tr('Disclosure', 'الإفصاح'), tr('Reason', 'السبب'), tr('Explanation', 'التفسير'), tr('Status', 'الحالة')],
        App.State.omissions.map(function (o) { return ['<code>' + esc(o.id) + '</code>', esc(o.disclosure), esc(o.reason), esc(o.explanation), statusBadge(o.status)]; }),
        tr('No omission recorded.', 'لا يوجد حذف مسجل.')));
  }
  function gates(ids) {
    return App.Gates.results().filter(function (g) { return ids.indexOf(g.id) > -1; }).map(function (g) {
      return card(g.id + ' · ' + App.L(g.name, g.nameAr),
        (g.pass ? '<p>' + badge('PASS', 'success') + ' ' + esc(tr('All evaluation rules pass.', 'كل قواعد التقييم مجتازة.')) + '</p>'
          : '<p>' + badge('FAIL', 'danger') + '</p><ul>' +
            g.failures.map(function (f) { return '<li>' + esc(App.L(f.en, f.ar)) + '</li>'; }).join('') + '</ul>' +
            '<p style="margin-top:10px"><strong>' + tr('Remediation', 'المعالجة') + '</strong></p><ul>' +
            g.remediation.map(function (r) { return '<li>' + esc(App.L(r.en, r.ar)) +
              (r.responsibleRole ? ' ' + badge(App.roleLabelOf(r.responsibleRole)) : '') + '</li>'; }).join('') + '</ul>'));
    }).join('');
  }
  function impacts(assessed) {
    var r = App.Materiality.ranked();
    var head = [tr('ID', 'المعرف'), tr('Topic', 'الموضوع'), tr('Description', 'الوصف'), tr('Class', 'التصنيف'), tr('Value chain', 'سلسلة القيمة')];
    if (assessed) head = head.concat([tr('Scale', 'الحجم'), tr('Scope', 'النطاق'), tr('Irrem.', 'المعالجة'), tr('Likelihood', 'الاحتمال'), tr('Significance', 'الأهمية')]);
    return card(tr('Impact register', 'سجل التأثيرات') + ' (' + r.all.length + ')',
      table(head, r.all.map(function (i) {
        var c = ['<code>' + esc(i.id) + '</code>', esc(i.topic), esc(String(i.description).slice(0, 58)),
          badge(i._score.class.replace(/_/g, ' '), i.polarity === 'Negative' ? 'danger' : 'success'), esc(i.valueChain)];
        if (assessed) c = c.concat([i.scale, i.scope, i.irremediability, i.likelihood,
          '<strong>' + i._score.significance + '</strong>' + (i._score.override ? ' ' + badge(tr('HR override', 'أولوية حقوق'), 'danger') : '')]);
        return c;
      })));
  }
  function topics() {
    var p = App.Materiality.proposedTopics(), a = App.Materiality.approved();
    return card(tr('Material topics', 'الموضوعات الجوهرية'),
      table([tr('Topic', 'الموضوع'), tr('Category', 'الفئة'), tr('Impacts', 'التأثيرات'), tr('Max significance', 'أعلى أهمية'), tr('Human rights', 'حقوق إنسان'), tr('Status', 'الحالة')],
        p.map(function (x) {
          var ap = a.filter(function (y) { return y.topic === x.topic; })[0];
          return [esc(x.topic), esc(x.category), x.impacts.length, x.maxSignificance,
            x.humanRights ? badge(tr('Yes', 'نعم'), 'danger') : '—',
            ap ? badge('APPROVED', 'success') : badge(tr('Proposed', 'مقترح'), 'warn')];
        })));
  }
  function engagements() {
    return card(tr('Engagement records', 'سجلات المشاركة'),
      '<p class="kpi-note">' + esc(tr('Engagement evidence informs impact identification. It is never read by the significance calculation.',
        'أدلة المشاركة تُثري تحديد التأثيرات ولا تقرأها حسابات الأهمية.')) + '</p>' +
      table([tr('ID', 'المعرف'), tr('Group', 'الفئة'), tr('Method', 'الطريقة'), tr('Date', 'التاريخ'), tr('Participants', 'المشاركون'), tr('Outcome', 'النتيجة')],
        App.Materiality.stakeholderInput().map(function (e) { return ['<code>' + esc(e.id) + '</code>', esc(e.group), esc(e.method), esc(e.date), e.participants, esc(e.outcome)]; })));
  }
  function records() {
    var s = App.Records.stats(), recs = App.State.records.filter(function (r) { return !r.frozen; });
    return '<div class="kpi-grid">' +
      kpi(tr('Records', 'السجلات'), s.total, tr('in this cycle', 'في هذه الدورة'), 'database', 'blue') +
      kpi(tr('Approved', 'معتمدة'), s.approved, tr('locked to a version', 'مقفولة على إصدار'), 'check') +
      kpi(tr('In review', 'قيد المراجعة'), s.submitted + s.review, tr('awaiting a decision', 'بانتظار قرار'), 'eye', 'purple') +
      kpi(tr('Returned', 'مُعادة'), s.returned, tr('with a written reason', 'بسبب مكتوب'), 'warning', 'amber') +
      '</div>' +
      card(tr('Data records', 'سجلات البيانات'),
        table([tr('ID', 'المعرف'), tr('Activity', 'النشاط'), tr('Site', 'الموقع'), tr('Period', 'الفترة'), tr('Value', 'القيمة'), tr('Status', 'الحالة'), ''],
          recs.slice(0, 20).map(function (r) {
            var a = App.Records.activity(r.activityId);
            return ['<code>' + esc(r.id) + '</code>', esc(a ? a.name_en : r.activityId), esc(App.siteName(r.siteId)),
              esc(r.periodLabel), num(r.rawValue) + ' ' + esc(r.rawUnit), statusBadge(r.status),
              '<button class="ghost-btn" style="min-height:31px;padding:0 10px" data-action="x-rec-' + esc(r.id) + '">' + tr('Open', 'افتح') + '</button>'];
          }), tr('No record yet. Add the first one.', 'لا يوجد سجل بعد. أضف الأول.')) +
        '<div style="margin-top:14px">' + btn(tr('Add record', 'إضافة سجل'), 'primary', 'x-new-record', 'plus') + '</div>');
  }
  function evidence() {
    var h = App.Evidence.hashSummary();
    return card(tr('Evidence repository', 'مستودع الأدلة'),
      '<p>' + badge(h.VERIFIED_BROWSER_SHA256 + ' ' + tr('browser-computed SHA-256', 'SHA-256 محسوبة'), 'success') + ' ' +
      badge(h.SIMULATED_PROTOTYPE_DIGEST + ' ' + tr('simulated prototype digest', 'بصمة محاكاة')) + '</p>' +
      table([tr('ID', 'المعرف'), tr('File', 'الملف'), tr('Type', 'النوع'), tr('Version', 'الإصدار'), tr('Digest', 'البصمة'), tr('Records', 'السجلات'), tr('Status', 'الحالة')],
        App.State.evidence.slice(0, 20).map(function (e) {
          var c = App.Evidence.classifyEvidenceHash(e);
          return ['<code>' + esc(e.id) + '</code>', esc(e.fileName), esc(e.fileType), 'v' + e.version,
            '<code style="font-size:10px">' + esc(String(e.hash).slice(0, 18)) + '…</code> ' + badge(c.label, c.verified ? 'success' : ''),
            (e.relatedIds || []).length, statusBadge(e.status)];
        }), tr('No evidence uploaded yet.', 'لا توجد أدلة بعد.')));
  }
  function calcs(lineage) {
    var runs = App.State.calcRuns;
    return card(tr('Calculation runs', 'تشغيلات الحساب'),
      '<p>' + esc(tr('Product Mode refuses any calculation whose emission factor is not approved, and any ratio without an approved denominator record.',
        'يرفض وضع المنتج أي حساب عامله غير معتمد، وأي نسبة بلا سجل مقام معتمد.')) + '</p>' +
      '<div style="margin:12px 0">' + btn(tr('Run calculations', 'تشغيل الحسابات'), 'primary', 'x-calc', 'chart') + '</div>' +
      table([tr('Record', 'السجل'), tr('Method', 'الطريقة'), tr('Domain', 'المجال'), tr('Factor', 'العامل'), tr('Output', 'الناتج'), tr('Unit', 'الوحدة')]
        .concat(lineage ? [tr('Trace', 'الأثر')] : []),
        runs.slice(0, 20).map(function (r) {
          var c = ['<code>' + esc(r.recordId || '—') + '</code>', '<code>' + esc(r.methodId) + '</code>', esc(r.domain),
            esc(r.factorId || '—'), '<strong>' + num(r.output) + '</strong>', esc(r.outputUnit)];
          if (lineage) c.push('<code style="font-size:10px">' + esc((r.trace || []).map(function (x) { return x.step; }).join(' → ')) + '</code>');
          return c;
        }), tr('No calculation has run. Approve an emission factor first.', 'لم يُشغَّل أي حساب. اعتمد عامل انبعاث أولًا.')));
  }
  function factors() {
    return card(tr('Emission factor sets', 'مجموعات عوامل الانبعاث'),
      '<p>' + esc(tr('A factor cannot be approved without its source, publication, geography, year and GWP set — a factor without them cannot be defended to a verifier.',
        'لا يُعتمد العامل بدون مصدره ومنشوره ونطاقه وسنته ومجموعة GWP — والعامل بدونها لا يمكن الدفاع عنه أمام المحقق.')) + '</p>' +
      table([tr('Factor', 'العامل'), tr('Value', 'القيمة'), tr('Unit', 'الوحدة'), tr('Source', 'المصدر'), tr('Geography', 'النطاق'), tr('Year', 'السنة'), 'GWP', tr('Approval', 'الاعتماد'), ''],
        App.Data.factorSets.map(function (f) {
          return ['<code>' + esc(f.factorId) + '</code>', f.value, esc(f.unit), esc(f.source), esc(f.geography), f.year, esc(f.gwpSet),
            f.approval === 'APPROVED' ? badge('APPROVED', 'success') : badge(f.approval, 'danger'),
            '<button class="' + (f.approval === 'APPROVED' ? 'ghost' : 'primary') + '-btn" style="min-height:31px;padding:0 11px" data-action="x-factor-' + esc(f.factorId) + '">' +
              (f.approval === 'APPROVED' ? tr('Revise', 'تعديل') : tr('Approve', 'اعتماد')) + '</button>'];
        })));
  }
  function queue(status) {
    var q = App.State.records.filter(function (r) { return r.status === status; });
    return card(tr('Queue', 'قائمة الانتظار') + ' — ' + status + ' (' + q.length + ')',
      table([tr('ID', 'المعرف'), tr('Activity', 'النشاط'), tr('Site', 'الموقع'), tr('Period', 'الفترة'), tr('Value', 'القيمة'), ''],
        q.slice(0, 20).map(function (r) {
          var a = App.Records.activity(r.activityId);
          return ['<code>' + esc(r.id) + '</code>', esc(a ? a.name_en : r.activityId), esc(App.siteName(r.siteId)),
            esc(r.periodLabel), num(r.rawValue) + ' ' + esc(r.rawUnit),
            '<button class="ghost-btn" style="min-height:31px;padding:0 10px" data-action="x-rec-' + esc(r.id) + '">' + tr('Open', 'افتح') + '</button>'];
        }), tr('The queue is empty.', 'القائمة فارغة.')));
  }
  function contentIndex() {
    var ci = App.GRI.contentIndex();
    return card(ci.title,
      '<p>' + esc(App.L(ci.statementOfUse.text, ci.statementOfUse.textAr)) + '</p>' +
      '<p class="kpi-note">' + ci.rows.length + tr(' rows generated from approved records · ', ' صفًا مولّدًا من السجلات المعتمدة · ') +
        ci.missingLocation + tr(' without a location', ' بلا موقع') + '</p>' +
      '<div style="margin:12px 0">' + btn(tr('Download the content index', 'نزّل الفهرس'), 'primary', 'x-dl-index', 'download') + '</div>' +
      table([tr('Standard', 'المعيار'), tr('Code', 'الرمز'), tr('Disclosure', 'الإفصاح'), tr('Location', 'الموقع'), tr('Omission', 'الحذف'), tr('Status', 'الحالة')],
        ci.rows.slice(0, 60).map(function (r) {
          return [esc(r.standard), '<code>' + esc(r.code) + '</code>', esc(r.title),
            r.location ? esc(r.location) : badge(tr('no location', 'بلا موقع'), 'danger'),
            esc(r.omission || '—'), statusBadge(r.status)];
        })));
  }


  /* ================================================= v17.1 closed live screens == */
  function noteStore() { App.State.notes = App.State.notes || {}; return App.State.notes; }
  function pct(a,b) { return b ? Math.round(a * 1000 / b) / 10 : 0; }
  function allCurrentRecords() { return App.State.records.filter(function(r){return !r.frozen;}); }
  function reportSections() {
    var n=noteStore();
    if(!n.reportSections) n.reportSections=[
      {id:'RS-01',title:'About the organization',titleAr:'عن المنظمة',owner:'CLIENT_COORDINATOR',status:'APPROVED',source:'B-01 to B-09'},
      {id:'RS-02',title:'Material topics and impacts',titleAr:'الموضوعات والتأثيرات',owner:'ESG_PROGRAMME_MANAGER',status:App.Materiality.isApproved()?'APPROVED':'DRAFT',source:'C-01 to C-12'},
      {id:'RS-03',title:'Environmental performance',titleAr:'الأداء البيئي',owner:'DATA_OWNER',status:App.Records.approved().length?'IN_REVIEW':'DRAFT',source:'Approved E records'},
      {id:'RS-04',title:'Social performance',titleAr:'الأداء الاجتماعي',owner:'DATA_OWNER',status:App.Records.approved().length?'IN_REVIEW':'DRAFT',source:'Approved S records'},
      {id:'RS-05',title:'Governance performance',titleAr:'أداء الحوكمة',owner:'ESG_PROGRAMME_MANAGER',status:'DRAFT',source:'Approved G records'},
      {id:'RS-06',title:'GRI content index',titleAr:'فهرس محتوى GRI',owner:'ESG_TECH_REVIEWER',status:(App.GRI.contentIndex().missingLocation===0?'APPROVED':'IN_REVIEW'),source:'E-09'}
    ];
    return n.reportSections;
  }
  function narrativeBlocks(){
    var n=noteStore();
    if(!n.narratives) n.narratives=[
      {id:'NB-01',section:'RS-01',title:'Reporting basis',en:'This report covers the entities, sites and period approved in the reporting boundary.',ar:'يغطي هذا التقرير الكيانات والمواقع والفترة المعتمدة ضمن حدود التقرير.',status:'APPROVED',sources:['B-07','B-09']},
      {id:'NB-02',section:'RS-02',title:'Materiality method',en:'Material topics were determined from actual and potential impacts, with severity taking precedence for potential human-rights impacts.',ar:'حُددت الموضوعات الجوهرية من التأثيرات الفعلية والمحتملة مع أولوية الشدة لتأثيرات حقوق الإنسان المحتملة.',status:App.Materiality.isApproved()?'APPROVED':'IN_REVIEW',sources:['C-07','C-11','C-12']},
      {id:'NB-03',section:'RS-03',title:'Performance narrative',en:'Performance figures are bound only to approved records and controlled calculation runs.',ar:'ترتبط أرقام الأداء فقط بالسجلات المعتمدة وتشغيلات الحساب المحكومة.',status:'IN_REVIEW',sources:['D-07','D-08']}
    ]; return n.narratives;
  }
  function visualBindings(){
    var runs=App.State.calcRuns.filter(function(r){return !r.sandbox;});
    var by={}; runs.forEach(function(r){by[r.domain]=by[r.domain]||{domain:r.domain,unit:r.outputUnit,count:0,total:0};by[r.domain].count++;by[r.domain].total+=Number(r.output||0);});
    return Object.keys(by).map(function(k,i){var x=by[k];return {id:'VIS-'+String(i+1).padStart(2,'0'),title:k+' performance',type:i%2?'Table':'Chart',source:x.count+' controlled run(s)',unit:x.unit,status:x.count?'BOUND':'MISSING'};});
  }
  function taxonomyState(){var n=noteStore();return n.taxonomyPackage||null;}
  function digitalContexts(){
    var m={}; App.Records.approved().forEach(function(r){var k=[r.entityId,r.siteId,r.periodStart,r.periodEnd].join('|');m[k]=m[k]||{id:'CTX-'+(Object.keys(m).length+1),entity:r.entityId,site:r.siteId,start:r.periodStart,end:r.periodEnd,records:0};m[k].records++;});return Object.keys(m).map(function(k){return m[k];});
  }
  function cycleWizardLive(){
    var d=App.Data.demo,c=d.cycle,b=d.boundaries,checks=[
      ['Organization profile',!!d.organization.name_en,'B-01'],['Legal entities',d.legalEntities.length>0,'B-02'],['Sites',d.sites.length>0,'B-03'],
      ['Reporting period',!!c.periodStart&&!!c.periodEnd,'B-05'],['Reporting entities boundary',!!b.entities.approved,'B-07'],['Impact boundary',!!b.impact.approved,'B-07'],
      ['GHG boundary',!!b.ghg.approved,'B-07'],['Sector classification',!!d.organization.sector,'B-08'],['Applicable standards',!!App.GRI.applicableVersion('GRI 1',c.publicationTarget),'B-09']
    ];var done=checks.filter(function(x){return x[1];}).length;
    return '<div class="kpi-grid">'+kpi(tr('Setup progress','تقدم الإعداد'),done+'<small>/'+checks.length+'</small>',pct(done,checks.length)+'%','chart','blue')+
      kpi(tr('Cycle','الدورة'),esc(c.label),esc(c.periodStart+' → '+c.periodEnd),'calendar')+
      kpi(tr('Target approach','المنهج المستهدف'),esc(c.targetApproach),tr('final claim is computed','الادعاء النهائي محسوب'),'shield','purple')+'</div>'+
      card(tr('Resumable setup checklist','قائمة إعداد قابلة للاستكمال'),table([tr('Configuration','الإعداد'),tr('Status','الحالة'),''],checks.map(function(x){return [esc(x[0]),x[1]?badge('COMPLETE','success'):badge('REQUIRED','danger'),'<button class="ghost-btn" data-screen="'+x[2]+'">'+tr('Open','افتح')+'</button>'];})))+
      card(tr('Edit cycle configuration','تعديل إعدادات الدورة'),'<p>'+esc(tr('Use My organization to change the organization, entities, sites and reporting period.','استخدم منظمتي لتعديل المنظمة والكيانات والمواقع وفترة التقرير.'))+'</p><div style="margin-top:12px">'+btn(tr('Open My organization','افتح منظمتي'),'primary','x-setup','building')+'</div>');
  }
  function sectorClassificationLive(){
    var o=App.Data.demo.organization,c=App.Data.demo.cycle,ss=c.sectorStandards||[];
    return card(tr('Approved sector profile','ملف القطاع المعتمد'),table([tr('Field','الحقل'),tr('Current value','القيمة الحالية'),tr('Control status','حالة الضبط')],[
      [tr('Primary sector','القطاع الرئيسي'),esc(o.sector||'—'),o.sector?badge('SET','success'):badge('MISSING','danger')],
      [tr('Organization country','دولة المنظمة'),esc(o.country||o.hq||'—'),badge('CONTEXT','info')],
      [tr('Sector Standards','المعايير القطاعية'),esc(ss.join(', ')||tr('No applicable standard recorded','لا يوجد معيار منطبق مسجل')),ss.length?badge('REVIEWED','success'):badge('REVIEW REQUIRED','warn')]
    ])) + card(tr('Classification evidence and transition check','أدلة التصنيف وفحص الانتقال'),
      '<p>'+esc(tr('Sector classification drives Sector Standard applicability but does not replace impact-based materiality.','تصنيف القطاع يحدد انطباق المعايير القطاعية ولا يستبدل الجوهرية القائمة على التأثير.'))+'</p><div style="margin-top:12px">'+btn(tr('Edit sector and cycle','تعديل القطاع والدورة'),'primary','x-setup','edit')+'</div>');
  }
  function divergenceRows(){
    var resolved=(noteStore().divergenceResolved||{});
    return App.Materiality.ranked().all.map(function(i){var a=Number(i._score.significance||0),b=Math.max(1,Math.round((Number(i.scale||0)+Number(i.scope||0)+Number(i.irremediability||0))/3));var variance=Math.abs(a-b);return {id:i.id,topic:i.topic,assessor:a,reviewer:b,variance:variance,status:resolved[i.id]?'RESOLVED':(variance>=4?'OPEN':'NO_MATERIAL_DIVERGENCE')};}).filter(function(x){return x.variance>=2||x.status==='RESOLVED';});
  }
  function divergenceLive(){var rows=divergenceRows();return card(tr('Divergence reconciliation queue','قائمة تسوية الاختلافات'),
    '<p class="kpi-note">'+esc(tr('Scores are never silently averaged. Material variances require a recorded reconciliation decision.','لا تُحسب متوسطات صامتة. الفروق الجوهرية تتطلب قرار تسوية مسجل.'))+'</p>'+
    table([tr('Impact','التأثير'),tr('Topic','الموضوع'),tr('Assessor','المقيّم'),tr('Reviewer','المراجع'),tr('Variance','الفرق'),tr('Status','الحالة'),''],rows.map(function(x){return ['<code>'+x.id+'</code>',esc(x.topic),x.assessor,x.reviewer,x.variance,statusBadge(x.status),x.status==='OPEN'?'<button class="primary-btn" data-action="x-resolve-div-'+x.id+'">'+tr('Resolve','سوِّ')+'</button>':'—'];}),tr('No material divergence is open.','لا يوجد اختلاف جوهري مفتوح.')));
  }
  function sectorReconciliationLive(){var c=App.Data.demo.cycle,topics=App.Materiality.proposedTopics(),secs=c.sectorStandards||[];return card(tr('Sector Standard reconciliation','مواءمة المعايير القطاعية'),
    '<p>'+ (secs.length?badge(secs.length+' '+tr('applicable standard(s)','معيار منطبق'),'success'):badge(tr('No Sector Standard configured','لا يوجد معيار قطاعي مضبوط'),'warn'))+'</p>'+table([tr('Candidate topic','الموضوع المرشح'),tr('Highest impact','أعلى تأثير'),tr('Sector reference','مرجع القطاع'),tr('Decision','القرار')],topics.map(function(t){return [esc(t.topic),t.maxSignificance,secs.length?esc(secs.join(', ')):tr('Not configured','غير مضبوط'),t._material?badge(tr('Retain','الإبقاء'),'success'):badge(tr('Review','مراجعة'),'warn')];}))+
    '<div style="margin-top:12px">'+btn(tr('Edit sector classification','تعديل تصنيف القطاع'),'primary','go-B-08','edit')+'</div>');}
  function bulkImportLive(){var n=noteStore(),b=n.lastImport||null;return card(tr('Controlled bulk import','الاستيراد المجمع المحكوم'),
    '<div class="alert info"><div><strong>'+tr('Required columns','الأعمدة المطلوبة')+'</strong><span>activityId, siteId, periodStart, periodEnd, rawValue, rawUnit, dataSource</span></div></div>'+
    '<div class="x-field full" style="margin-top:14px"><label>'+tr('CSV file','ملف CSV')+'</label><input id="xImportFile" type="file" accept=".csv,text/csv"></div><div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap">'+
    btn(tr('Download template','تنزيل القالب'),'ghost','x-dl-import-template','download')+btn(tr('Validate and import','تحقق واستورد'),'primary','x-import-csv','upload')+'</div>')+
    (b?card(tr('Last import batch','آخر دفعة استيراد'),table([tr('Batch','الدفعة'),tr('Rows','الصفوف'),tr('Imported','المستوردة'),tr('Rejected','المرفوضة'),tr('Date','التاريخ')],[[esc(b.id),b.rows,b.imported,b.rejected,esc(b.at)]])):'' );}
  function comparativeRows(){var groups={};allCurrentRecords().forEach(function(r){var k=r.activityId+'|'+r.siteId;groups[k]=groups[k]||[];groups[k].push(r);});var out=[];Object.keys(groups).forEach(function(k){var a=groups[k].sort(function(x,y){return String(x.periodStart).localeCompare(String(y.periodStart));});for(var i=1;i<a.length;i++){var p=Number(a[i-1].rawValue),v=Number(a[i].rawValue);if(!isFinite(p)||!isFinite(v)||p===0)continue;var change=Math.round((v-p)*1000/p)/10;if(Math.abs(change)>=10)out.push({id:a[i].id,activity:a[i].activityId,site:a[i].siteId,period:a[i].periodLabel,change:change,expl:a[i].varianceExplanation||''});}});return out;}
  function comparativeLive(){var r=comparativeRows();return '<div class="kpi-grid">'+kpi(tr('Material variances','الفروق الجوهرية'),r.length,tr('threshold ±10%','العتبة ±10%'),'chart','amber')+kpi(tr('Explained','مفسرة'),r.filter(function(x){return x.expl;}).length,'','check')+'</div>'+card(tr('Comparative analysis','التحليل المقارن'),table([tr('Record','السجل'),tr('Activity','النشاط'),tr('Site','الموقع'),tr('Period','الفترة'),tr('Change','التغير'),tr('Explanation','التفسير'),''],r.map(function(x){return ['<code>'+x.id+'</code>',esc(x.activity),esc(x.site),esc(x.period),badge((x.change>0?'+':'')+x.change+'%',Math.abs(x.change)>=25?'danger':'warn'),esc(x.expl||'—'),x.expl?'—':'<button class="primary-btn" data-action="x-explain-'+x.id+'">'+tr('Explain','فسّر')+'</button>'];}),tr('No variance over the threshold.','لا يوجد فرق فوق العتبة.')));}
  function restatementLive(){var frozen=App.State.records.filter(function(r){return r.frozen;});var current=allCurrentRecords().filter(function(r){return Number(r.version)>1||r.status==='REOPENED';});return '<div class="kpi-grid">'+kpi(tr('Preserved versions','إصدارات محفوظة'),frozen.length,tr('immutable approved history','تاريخ اعتماد غير قابل للتغيير'),'file','blue')+kpi(tr('Active restatements','إعادات عرض جارية'),current.length,'','warning','amber')+'</div>'+card(tr('Restatement and version history','إعادة العرض وتاريخ الإصدارات'),table([tr('Record','السجل'),tr('Version','الإصدار'),tr('Status','الحالة'),tr('Reason','السبب'),tr('Approved','الاعتماد')],frozen.concat(current).map(function(r){return ['<code>'+esc(r.id)+'</code>',r.version,statusBadge(r.status),esc(r.reopenReason||r.returnReason||'—'),esc(r.approvedAt||'—')];}),tr('No restatement has been initiated.','لم تبدأ إعادة عرض.')));}
  function crossCheckResults(){var s=App.Records.stats(),checks=[];function add(id,name,pass,detail){checks.push({id:id,name:name,pass:pass,detail:detail});}add('CC-01','Approved records have evidence',s.evidenceCoverage===100,s.evidenceCoverage+'% evidence coverage');add('CC-02','No open technical-review major finding',!App.State.findings.some(function(f){return f.source==='Technical review'&&f.status==='OPEN'&&f.severity==='MAJOR';}),App.State.findings.filter(function(f){return f.source==='Technical review'&&f.status==='OPEN';}).length+' open');add('CC-03','Calculated outputs have lineage',App.State.calcRuns.every(function(r){return r.trace&&r.trace.length;}),App.State.calcRuns.length+' run(s)');add('CC-04','GRI 2 and Content Index status agree',App.State.gri2.filter(function(d){return d.status==='COMPLETE';}).length<=App.GRI.contentIndex().rows.length,App.State.gri2.filter(function(d){return d.status==='COMPLETE';}).length+' complete disclosures');add('CC-05','Boundary sites and data sites reconcile',allCurrentRecords().every(function(r){var s=App.Data.demo.sites.filter(function(x){return x.id===r.siteId;})[0];return s&&s.inBoundary;}),'records tested: '+allCurrentRecords().length);return checks;}
  function crossChecksLive(){var c=crossCheckResults();return '<div class="kpi-grid">'+kpi(tr('Checks passed','فحوص مجتازة'),c.filter(function(x){return x.pass;}).length+'<small>/'+c.length+'</small>','','check')+kpi(tr('Blocking inconsistencies','تعارضات حاجبة'),c.filter(function(x){return !x.pass;}).length,'','warning','red')+'</div>'+card(tr('Cross-disclosure and cross-period controls','ضوابط الاتساق بين الإفصاحات والفترات'),table([tr('Control','الضابط'),tr('Description','الوصف'),tr('Result','النتيجة'),tr('Evidence','الدليل')],c.map(function(x){return ['<code>'+x.id+'</code>',esc(x.name),x.pass?badge('PASS','success'):badge('FAIL','danger'),esc(x.detail)];})));}
  function reportStructureLive(){var s=reportSections();return card(tr('Controlled report structure','هيكل التقرير المحكوم'),table([tr('ID','المعرف'),tr('Chapter','الفصل'),tr('Owner','المالك'),tr('Source','المصدر'),tr('Status','الحالة')],s.map(function(x){return ['<code>'+x.id+'</code>',esc(App.L(x.title,x.titleAr)),esc(App.roleLabelOf(x.owner)),esc(x.source),statusBadge(x.status)];}))+'<div style="margin-top:12px">'+btn(tr('Approve current structure','اعتماد الهيكل الحالي'),'primary','x-approve-structure','check')+'</div>');}
  function narrativeLive(){var b=narrativeBlocks();return card(tr('Narrative blocks with source references','كتل السرد بمراجع المصدر'),table([tr('Block','الكتلة'),tr('Section','القسم'),tr('Narrative','السرد'),tr('Sources','المصادر'),tr('Status','الحالة')],b.map(function(x){return ['<code>'+x.id+'</code>',esc(x.section),esc(App.L(x.en,x.ar)),esc(x.sources.join(', ')),statusBadge(x.status)];}))+'<div style="margin-top:12px">'+btn(tr('Approve reviewed narratives','اعتماد السرد المراجع'),'primary','x-approve-narratives','check')+'</div>');}
  function visualsLive(){var v=visualBindings();return card(tr('Tables and charts bound to controlled outputs','جداول ورسوم مرتبطة بمخرجات محكومة'),table([tr('ID','المعرف'),tr('Visual','العرض'),tr('Type','النوع'),tr('Source','المصدر'),tr('Unit','الوحدة'),tr('Status','الحالة')],v.map(function(x){return ['<code>'+x.id+'</code>',esc(x.title),esc(x.type),esc(x.source),esc(x.unit||'—'),statusBadge(x.status)];}),tr('Run approved calculations to create report visuals.','شغّل الحسابات المعتمدة لإنشاء عروض التقرير.')));}
  function bilingualLive(){var blocks=narrativeBlocks(),missing=blocks.filter(function(x){return !x.en||!x.ar;});var parity=pct(blocks.length-missing.length,blocks.length);return '<div class="kpi-grid">'+kpi(tr('Narrative parity','تكافؤ السرد'),parity+'%',tr('English and Arabic','الإنجليزية والعربية'),'file',parity===100?'':'amber')+kpi(tr('Missing translations','ترجمات ناقصة'),missing.length,'','warning',missing.length?'red':'')+'</div>'+card(tr('Block-level parity register','سجل التكافؤ على مستوى الكتل'),table([tr('Block','الكتلة'),tr('English','الإنجليزية'),tr('Arabic','العربية'),tr('Status','الحالة')],blocks.map(function(x){return ['<code>'+x.id+'</code>',x.en?badge('PRESENT','success'):badge('MISSING','danger'),x.ar?badge('PRESENT','success'):badge('MISSING','danger'),x.en&&x.ar?badge('PARITY','success'):badge('GAP','danger')];})));}
  function exportCenterLive(){var claim=App.State.claim||App.GRI.evaluateClaim(),g=App.Gates.summary();return '<div class="kpi-grid">'+kpi(tr('Claim readiness','جاهزية الادعاء'),claim.passed+'<small>/9</small>',claim.result,'shield','amber')+kpi(tr('Publication gates','بوابات النشر'),g.passed+'<small>/'+g.total+'</small>',tr('passed','مجتازة'),'check',g.passed===g.total?'':'red')+'</div>'+card(tr('Controlled exports','التصديرات المحكومة'),'<div style="display:flex;gap:10px;flex-wrap:wrap">'+btn(tr('Sustainability report','تقرير الاستدامة'),'primary','x-dl-report','download')+btn(tr('GRI content index','فهرس GRI'),'ghost','x-dl-index','download')+btn(tr('Underlying dataset','البيانات الأساسية'),'ghost','x-dl-dataset','download')+btn(tr('Full backup','نسخة احتياطية'),'ghost','x-dl-backup','download')+'</div><p class="kpi-note" style="margin-top:12px">'+esc(tr('Every export writes an audit event. A failed publication gate remains visible and is not bypassed.','كل تصدير يكتب حدث تدقيق. بوابة النشر الفاشلة تظل ظاهرة ولا يتم تجاوزها.'))+'</p>');}
  function taxonomyBindingLive(){var t=taxonomyState(),bind=(noteStore().taxonomyBindings||[]);return card(tr('Official taxonomy package registry','سجل حزمة التصنيف الرسمية'),(t?table([tr('Package','الحزمة'),tr('File','الملف'),tr('SHA-256','SHA-256'),tr('Imported','الاستيراد')],[[esc(t.name),esc(t.fileName),'<code>'+esc(t.sha256)+'</code>',esc(t.importedAt)]]) : '<div class="alert warning"><div><strong>'+tr('No official taxonomy package imported','لم تُستورد حزمة تصنيف رسمية')+'</strong><span>'+tr('No QName is invented. Digital binding remains blocked until an official package is supplied.','لا يتم اختراع QName. يظل الربط محجوبًا حتى تقديم حزمة رسمية.')+'</span></div></div>')+'<div class="x-field full" style="margin-top:14px"><label>'+tr('Import official taxonomy package or controlled JSON index','استيراد حزمة التصنيف الرسمية أو فهرس JSON محكوم')+'</label><input id="xTaxFile" type="file" accept=".zip,.xml,.xsd,.json"></div><div style="margin-top:12px">'+btn(tr('Register package','تسجيل الحزمة'),'primary','x-import-taxonomy','upload')+'</div>')+card(tr('Bindings','الروابط')+' ('+bind.length+')',table([tr('Disclosure','الإفصاح'),tr('QName','QName'),tr('Source package','حزمة المصدر'),tr('Status','الحالة')],bind.map(function(x){return [esc(x.disclosure),'<code>'+esc(x.qname)+'</code>',esc(x.package),statusBadge(x.status)];}),tr('No binding is permitted until a package is registered.','لا يسمح بأي ربط قبل تسجيل الحزمة.')));}
  function contextBuilderLive(){var c=digitalContexts();return '<div class="kpi-grid">'+kpi(tr('Unique contexts','السياقات الفريدة'),c.length,tr('entity + site + period','كيان + موقع + فترة'),'layers','blue')+kpi(tr('Approved records covered','السجلات المعتمدة المغطاة'),c.reduce(function(a,x){return a+x.records;},0),'','database')+'</div>'+card(tr('XBRL-ready context model','نموذج سياقات جاهز للوسم الرقمي'),table([tr('Context','السياق'),tr('Entity','الكيان'),tr('Site','الموقع'),tr('Start','البداية'),tr('End','النهاية'),tr('Records','السجلات')],c.map(function(x){return ['<code>'+x.id+'</code>',esc(x.entity),esc(x.site),esc(x.start),esc(x.end),x.records];}),tr('Approved records are required before contexts can be generated.','السجلات المعتمدة مطلوبة قبل توليد السياقات.')));}
  function digitalValidationLive(){var t=taxonomyState(),c=digitalContexts(),b=noteStore().taxonomyBindings||[],checks=[{id:'XV-01',name:'Official package registered',pass:!!t,detail:t?t.fileName:'missing'},{id:'XV-02',name:'No invented QName',pass:b.every(function(x){return x.package&&x.qname&&x.status!=='INVENTED';}),detail:b.length+' binding(s)'},{id:'XV-03',name:'Contexts valid and deduplicated',pass:c.length>0,detail:c.length+' context(s)'},{id:'XV-04',name:'Publication gates passed',pass:App.Gates.summary().passed===App.Gates.summary().total,detail:App.Gates.summary().passed+'/'+App.Gates.summary().total}];return card(tr('Digital-report validation','التحقق من التقرير الرقمي'),'<div class="alert info"><div><strong>'+tr('Frontend readiness control','ضابط جاهزية الواجهة')+'</strong><span>'+tr('This does not claim conformance validation against a licensed official taxonomy processor.','هذا لا يدعي تحقق المطابقة بواسطة معالج رسمي مرخص للتصنيف.')+'</span></div></div>'+table([tr('Rule','القاعدة'),tr('Control','الضابط'),tr('Result','النتيجة'),tr('Detail','التفصيل')],checks.map(function(x){return ['<code>'+x.id+'</code>',esc(x.name),x.pass?badge('PASS','success'):badge('BLOCKED','danger'),esc(x.detail)];})));}
  function expertPage(){
    var screens=Object.keys(App.Data.registry.screens).map(function(k){return App.Data.registry.screens[k];}),q=(App.State.notes.specQuery||'').toLowerCase();if(q)screens=screens.filter(function(s){return (s.id+' '+s.en+' '+s.ar+' '+s.fn).toLowerCase().indexOf(q)>-1;});
    var ready=screens.filter(function(s){return s.ready==='BASELINE_READY';}).length,blocked=screens.filter(function(s){return s.ready==='BLOCKED';}).length,conditional=screens.filter(function(s){return s.ready==='CONDITIONAL';}).length;
    return pageHead(tr('Expert / Build Specification','وضع الخبير / مواصفة البناء'),tr('The 117-screen v16 scope is kept out of the daily journey and available here for Product, Methodology, Engineering and QA.','نطاق v16 المكوّن من 117 شاشة خارج الرحلة اليومية ومتاح هنا للمنتج والمنهجية والهندسة والجودة.'),'set')+
      '<div class="kpi-grid">'+kpi(tr('Controlled screens','الشاشات المحكومة'),117,tr('specification registry','سجل المواصفات'),'layers','blue')+kpi(tr('Baseline ready','جاهزة كأساس'),ready,'','check')+kpi(tr('Conditional','مشروطة'),conditional,'','warning','amber')+kpi(tr('Blocked','محجوبة'),blocked,'','warning','red')+kpi(tr('Workspaces','مساحات العمل'),App.Data.registry.workspaces.length,'','layers','purple')+'</div>'+
      card(tr('Screen registry','سجل الشاشات'),'<div class="filters"><input class="filter-input" id="xSpecSearch" placeholder="'+tr('Search ID, title or function','ابحث بالمعرف أو العنوان أو الوظيفة')+'" value="'+esc(App.State.notes.specQuery||'')+'"><button class="primary-btn" data-action="x-spec-search">'+tr('Search','بحث')+'</button></div>'+table([tr('ID','المعرف'),tr('Screen','الشاشة'),tr('Phase','المرحلة'),tr('Role','الدور'),tr('Readiness','الجاهزية'),tr('Fields','الحقول'),tr('Rules','القواعد'),tr('Tests','الاختبارات'),''],screens.slice(0,80).map(function(s){return ['<code>'+s.id+'</code>',esc(App.L(s.en,s.ar)),esc(s.ph+' / '+s.st),esc(App.roleLabelOf(s.role)),statusBadge(s.ready),s.nf,s.nr,s.nt,'<button class="ghost-btn" data-action="x-spec-'+s.id+'">'+tr('Open','افتح')+'</button>'];}))+
      '<p class="kpi-note" style="margin-top:10px">'+esc(tr('Only the first 80 matching rows are displayed; use search to narrow the registry.','يُعرض أول 80 صفًا مطابقًا؛ استخدم البحث لتضييق السجل.'))+'</p>');
  }
  function liveOverview(){
    var c=App.Data.demo.cycle,next=App.Journey.nextAction(),sum=App.Journey.summary(),s=App.Records.stats(),claim=App.State.claim||App.GRI.evaluateClaim(),gs=App.Gates.summary(),griDone=(App.State.gri2||[]).filter(function(d){return d.status==='COMPLETE';}).length,bl=App.Journey.blockers(),aud=App.State.audit.slice(-6).reverse();
    return pageHead(tr('Reporting overview','نظرة عامة على التقرير'),tr('One active report, one current step, and live status from the operational engine.','تقرير نشط واحد وخطوة حالية واحدة وحالة حية من المحرك التشغيلي.'),'home')+
      card(tr('Active report','التقرير النشط')+' · '+esc(c.label),'<div class="two-col"><div><p>'+badge(c.status,'info')+' '+badge(tr('Phase ','المرحلة ')+next.phase.code)+' '+statusBadge(next.status)+'</p><h2 style="margin:12px 0 5px">'+esc(next.step.id+' · '+App.L(next.step.title,next.step.title_ar))+'</h2><p>'+esc(App.L(next.step.purpose,next.step.purpose_ar))+'</p>'+(next.why?'<div class="alert danger" style="margin-top:12px"><div><strong>'+tr('What is blocking progress','ما يعطل التقدم')+'</strong><span>'+esc(next.why)+'</span></div></div>':'')+'<div style="margin-top:14px">'+btn(tr('Continue report','استكمل التقرير')+' →','primary','go-'+next.step.id,'arrow')+btn(tr('Open full path','افتح المسار الكامل'),'ghost','x-path','target')+'</div></div><div>'+table([tr('Report field','بيان التقرير'),tr('Value','القيمة')],[[tr('Period','الفترة'),esc(c.periodStart+' → '+c.periodEnd)],[tr('Target approach','المنهج المستهدف'),esc(c.targetApproach)],[tr('Responsible role','الدور المسؤول'),esc(App.roleLabelOf(next.owner))],[tr('Completion criterion','شرط الإكمال'),esc(next.gate)],[tr('Evaluable steps completed','الخطوات القابلة للتقييم المكتملة'),sum.done+' / '+(sum.total-sum.notBuilt)],[tr('Backend-dependent steps','خطوات تعتمد على الـBackend'),sum.notBuilt+' / '+sum.total]])+'</div></div>')+
      '<div class="kpi-grid">'+kpi(tr('Journey progress','تقدم الرحلة'),pct(sum.done,sum.total-sum.notBuilt)+'%',sum.done+'/'+(sum.total-sum.notBuilt)+' · '+sum.notBuilt+' '+tr('backend-dependent','تعتمد على الـBackend'),'chart','blue')+kpi(tr('Data completeness','اكتمال البيانات'),s.completeness+'%',s.approved+' '+tr('approved','معتمد'),'database')+kpi(tr('Evidence coverage','تغطية الأدلة'),s.evidenceCoverage+'%',App.State.evidence.length+' '+tr('evidence objects','دليل'),'file','purple')+kpi(tr('GRI 2','GRI 2'),griDone+'<small>/30</small>',tr('complete disclosures','إفصاحات مكتملة'),'book','amber')+kpi(tr('GRI requirements','متطلبات GRI'),claim.passed+'<small>/9</small>',claim.result,'shield','red')+kpi(tr('Publication gates','بوابات النشر'),gs.passed+'<small>/'+gs.total+'</small>',gs.blockers+' '+tr('blocking','حاجبة'),'check',gs.blockers?'red':'')+'</div>'+
      '<div class="dashboard-grid"><div class="card span-2"><div class="card-head"><div><h2>'+tr('Phase progress','تقدم المراحل')+'</h2><p>'+tr('Completion is derived from domain gates, not manual percentages.','الاكتمال مشتق من بوابات النطاق وليس نسبًا يدوية.')+'</p></div></div><div class="card-body">'+App.Data.phases.map(function(p){var pr=App.Journey.phaseProgress(p.code);return '<div class="progress-row"><span>'+esc(p.code+' · '+App.L(p.title,p.title_ar))+'</span><div class="progress"><span style="width:'+pr.pct+'%"></span></div><strong>'+pr.pct+'%</strong></div>';}).join('')+'</div></div><div class="card"><div class="card-head"><div><h2>'+tr('Needs attention','يحتاج تدخل')+'</h2><p>'+bl.length+' '+tr('blocking item(s)','عنصر حاجب')+'</p></div></div><div class="card-body">'+(bl.length?bl.slice(0,5).map(function(b){return '<div class="overdue-item"><div class="bullet">!</div><div><strong>'+esc(b.step+' · '+b.reasons[0])+'</strong><span>'+esc((b.remediation||[])[0]||'')+'</span></div><button class="ghost-btn" data-screen="'+b.step+'">'+tr('Open','افتح')+'</button></div>';}).join(''):'<div class="empty">'+tr('No blocking action.','لا يوجد إجراء حاجب.')+'</div>')+'</div></div></div>'+
      card(tr('Recent controlled activity','آخر الأنشطة المحكومة'),table([tr('Time','الوقت'),tr('Action','الإجراء'),tr('Object','الكائن'),tr('Role','الدور')],aud.map(function(a){return [esc(String(a.timestamp||'').slice(0,19).replace('T',' ')),esc(a.action),esc(a.objectType+' · '+a.objectId),esc(a.role||'—')];}),tr('No user activity yet.','لا يوجد نشاط للمستخدم بعد.')));
  }

  /* ============================================================ new pages == */
  function pageHead(title, sub, ico) {
    return '<div class="breadcrumbs">' + icon('home') + '<span>' + tr('Modules', 'الموديولات') +
      '</span><span class="crumb-sep">›</span><strong>' + esc(title) + '</strong></div>' +
      '<div class="page-head"><div class="page-title-wrap"><div class="title-icon">' + icon(ico) + '</div><div>' +
      '<div class="title-line"><h1 class="page-title">' + esc(title) + '</h1></div>' +
      '<p class="page-sub">' + esc(sub) + '</p></div></div>' + actionBar() + '</div>';
  }

  function fld(id, label, inner, full) {
    return '<div class="x-field' + (full ? ' full' : '') + '"><label>' + esc(label) + '</label>' + inner + '</div>';
  }

  var PAGES = {
    'OVERVIEW': function () { return liveOverview(); },
    'X-EXPERT': function () { return expertPage(); },
    'X-SETUP': function () {
      var d = App.Data.demo, own = App.State.tenantOwned;
      return pageHead(tr('My organization', 'منظمتي'),
        tr('Put your own company in. Everything downstream is built from what you enter here.',
           'أدخل شركتك أنت. كل ما يليه يُبنى مما تدخله هنا.'), 'building') +
        card(own ? tr('You are working on your own organization', 'أنت تعمل على منظمتك')
                 : tr('You are looking at demonstration data', 'أنت تنظر إلى بيانات عرض'),
          '<p>' + (own ? badge(esc(d.organization.name_en), 'success') + ' ' + esc(d.cycle.label)
            : esc(tr('Delta Industrial Group is a fictitious reference organization. Create your own below.',
                     'مجموعة دلتا الصناعية منظمة مرجعية افتراضية. أنشئ منظمتك أدناه.'))) + '</p>') +
        card('1 · ' + tr('Organization', 'المنظمة'),
          '<div class="x-form">' +
          fld('xoName', tr('Legal name (English)', 'الاسم القانوني'), '<input id="xoName" value="' + esc(d.organization.name_en) + '">') +
          fld('xoNameAr', tr('Legal name (Arabic)', 'الاسم بالعربية'), '<input id="xoNameAr" value="' + esc(d.organization.name_ar) + '">') +
          fld('xoSector', tr('Sector', 'القطاع'), '<input id="xoSector" value="' + esc(d.organization.sector) + '">') +
          fld('xoHq', tr('Headquarters', 'المقر'), '<input id="xoHq" value="' + esc(d.organization.hq) + '">') +
          fld('xoCountry', tr('Country', 'الدولة'), '<input id="xoCountry" value="' + esc(d.organization.country || '') + '">') +
          fld('xoEmp', tr('Employees', 'عدد العاملين'), '<input id="xoEmp" type="number" value="' + esc(d.organization.employees) + '">') +
          fld('xoContact', tr('Reporting contact', 'جهة الاتصال'), '<input id="xoContact" value="' + esc(d.organization.contact || '') + '">') +
          fld('xoEmail', tr('Contact email', 'البريد الإلكتروني'), '<input id="xoEmail" value="' + esc(d.organization.contactEmail || '') + '">') +
          '</div><label class="x-check"><input type="checkbox" id="xoWipe"> <span>' +
          esc(tr('Start empty — remove the demonstration records, evidence, impacts and topics',
                 'ابدأ فارغًا — احذف سجلات العرض والأدلة والتأثيرات والموضوعات')) + '</span></label>' +
          '<div style="margin-top:14px">' + btn(tr('Save organization', 'حفظ المنظمة'), 'primary', 'x-save-org', 'check') + '</div>') +
        card('2 · ' + tr('Legal entities', 'الكيانات القانونية') + ' (' + d.legalEntities.length + ')',
          table([tr('ID', 'المعرف'), tr('Name', 'الاسم'), tr('Country', 'الدولة')],
            d.legalEntities.map(function (e) { return ['<code>' + esc(e.id) + '</code>', esc(e.name_en), esc(e.country)]; }),
            tr('A reporting boundary needs at least one.', 'حدود التقرير تحتاج كيانًا واحدًا على الأقل.')) +
          '<div style="margin-top:14px">' + btn(tr('Add legal entity', 'إضافة كيان'), 'primary', 'x-new-entity', 'plus') + '</div>') +
        card('3 · ' + tr('Sites', 'المواقع') + ' (' + d.sites.length + ')',
          table([tr('ID', 'المعرف'), tr('Site', 'الموقع'), tr('Entity', 'الكيان'), tr('In boundary', 'داخل الحدود')],
            d.sites.map(function (s) { return ['<code>' + esc(s.id) + '</code>', esc(s.name_en), esc(s.entity),
              s.inBoundary ? badge(tr('Yes', 'نعم'), 'success') : badge(tr('Excluded', 'مستبعد'), 'danger')]; }),
            tr('Data is collected per site.', 'تُجمع البيانات لكل موقع.')) +
          '<div style="margin-top:14px">' + btn(tr('Add site', 'إضافة موقع'), 'primary', 'x-new-site', 'plus') + '</div>') +
        card('4 · ' + tr('Reporting cycle', 'دورة التقرير'),
          '<div class="x-form">' +
          fld('xcLabel', tr('Cycle label', 'اسم الدورة'), '<input id="xcLabel" value="' + esc(d.cycle.label) + '">') +
          fld('xcApproach', tr('Target approach', 'المنهج المستهدف'),
            '<select id="xcApproach"><option value="IN_ACCORDANCE">' + tr('Aim for in accordance', 'الهدف: وفقًا للمعايير') +
            '</option><option value="WITH_REFERENCE">' + tr('With reference', 'بالرجوع') +
            '</option><option value="UNDECIDED">' + tr('Undecided', 'غير محدد') + '</option></select>') +
          fld('xcStart', tr('Period start', 'بداية الفترة'), '<input id="xcStart" type="date" value="' + esc(d.cycle.periodStart) + '">') +
          fld('xcEnd', tr('Period end', 'نهاية الفترة'), '<input id="xcEnd" type="date" value="' + esc(d.cycle.periodEnd) + '">') +
          '</div><p class="kpi-note">' + esc(tr('You may state the approach you are aiming for. The claim itself is computed from the nine requirements and cannot be set.',
            'يمكنك ذكر المنهج المستهدف. أما الادعاء فيُحسب من المتطلبات التسعة ولا يمكن تعيينه.')) + '</p>' +
          '<div style="margin-top:14px">' + btn(tr('Save cycle', 'حفظ الدورة'), 'primary', 'x-save-cycle', 'calendar') + '</div>');
    },

    'X-OUTPUT': function () {
      var claim = App.State.claim || App.GRI.evaluateClaim(), g = App.Gates.summary(), ci = App.GRI.contentIndex();
      return pageHead(tr('Output', 'المخرجات'),
        tr('Real files you can open, print, send to your accountant or hand to a verifier.',
           'ملفات حقيقية تفتحها وتطبعها وترسلها لمحاسبك أو تسلّمها للمحقق.'), 'download') +
        '<div class="kpi-grid">' +
        kpi(tr('Computed claim', 'الادعاء المحسوب'), claim.passed + '<small>/9</small>', claim.result, 'shield', claim.result === 'IN_ACCORDANCE' ? '' : 'amber') +
        kpi(tr('Publication gates', 'بوابات النشر'), g.passed + '<small>/' + g.total + '</small>', tr('passed', 'مجتازة'), 'check', g.passed === g.total ? '' : 'red') +
        kpi(tr('Approved records', 'سجلات معتمدة'), App.Records.approved().length, tr('bound to a version', 'مقفولة على إصدار'), 'database', 'blue') +
        kpi(tr('Index rows', 'صفوف الفهرس'), ci.rows.length, tr('generated', 'مولّدة'), 'file', 'purple') +
        '</div>' +
        card(tr('Sustainability report', 'تقرير الاستدامة'),
          '<p>' + esc(tr('Cover, statement of use, boundary, material topics, performance, the full content index and the basis of preparation. Opens in any browser; print to PDF.',
            'الغلاف وعبارة الاستخدام والحدود والموضوعات والأداء والفهرس الكامل وأساس الإعداد. يفتح في أي متصفح ويُطبع PDF.')) + '</p>' +
          '<div style="margin-top:12px">' + btn(tr('Download the report', 'نزّل التقرير'), 'primary', 'x-dl-report', 'download') + '</div>') +
        card(tr('GRI content index', 'فهرس محتوى GRI'),
          '<p>' + esc(tr('Every row from approved records, with locations, omissions and source record identifiers. Opens in Excel.',
            'كل صف من السجلات المعتمدة مع المواقع وأسباب الحذف ومعرفات المصدر. يفتح في Excel.')) + '</p>' +
          '<div style="margin-top:12px">' + btn(tr('Download the index', 'نزّل الفهرس'), 'primary', 'x-dl-index', 'download') + '</div>') +
        card(tr('Underlying dataset', 'مجموعة البيانات'),
          '<p>' + esc(tr('Every record with value, unit, measured or estimated status, assumptions, uncertainty, evidence links and approval. This is what a verifier asks for first.',
            'كل سجل بقيمته ووحدته وحالته وافتراضاته وعدم يقينه وأدلته واعتماده. هذا أول ما يطلبه المحقق.')) + '</p>' +
          '<div style="margin-top:12px">' + btn(tr('Download the dataset', 'نزّل البيانات'), 'primary', 'x-dl-dataset', 'download') + '</div>') +
        card(tr('Full backup', 'نسخة احتياطية كاملة'),
          '<p>' + esc(tr('Your organization, boundary, factors, records, evidence, impacts, topics and audit trail in one file. Restore it on any machine.',
            'منظمتك وحدودك وعواملك وسجلاتك وأدلتك وتأثيراتك وسجل التدقيق في ملف واحد. استعدها على أي جهاز.')) + '</p>' +
          '<div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap">' +
          btn(tr('Download a backup', 'نزّل نسخة'), 'primary', 'x-dl-backup', 'download') + '</div>' +
          '<div class="x-field full" style="margin-top:14px"><label>' + tr('Restore from a backup file', 'استعادة من ملف') +
          '</label><input id="xRestore" type="file" accept=".json"></div>' +
          '<div style="margin-top:10px">' + btn(tr('Restore', 'استعادة'), 'danger', 'x-restore', 'upload') + '</div>');
    },

    'X-PATH': function () {
      var next = App.Journey.nextAction(), sum = App.Journey.summary(), bl = App.Journey.blockers();
      return pageHead(tr('My path', 'مساري'),
        tr('Five phases · 66 controlled steps · one next action at a time', 'خمس مراحل · ٦٦ خطوة · إجراء تالٍ واحد'), 'target') +
        card(next.status === 'BLOCKED' ? tr('You are blocked here', 'أنت محجوب هنا') : tr('Start here', 'ابدأ من هنا'),
          '<h3 style="margin:0 0 6px;font-size:19px">' + esc(next.step.id) + ' · ' + esc(next.label) + '</h3>' +
          '<p>' + esc(App.L(next.step.purpose, next.step.purpose_ar)) + '</p>' +
          '<p style="margin-top:8px">' + badge(tr('Phase ', 'المرحلة ') + next.phase.code) + ' ' +
            badge(App.roleLabelOf(next.owner), 'info') + ' ' + statusBadge(next.status) + '</p>' +
          '<p style="margin-top:8px"><strong>' + tr('To finish this step: ', 'لإنهاء الخطوة: ') + '</strong>' + esc(next.gate) + '</p>' +
          (next.why ? '<p style="color:var(--red)"><strong>' + tr('What is holding it: ', 'ما يعطلها: ') + '</strong>' + esc(next.why) + '</p>' : '') +
          '<div style="margin-top:14px">' + btn(tr('Open this step', 'افتح الخطوة') + ' →', 'primary', 'go-' + next.step.id, 'arrow') + '</div>') +
        '<div class="kpi-grid">' +
        kpi(tr('Steps done', 'خطوات مكتملة'), sum.done + '<small>/' + (sum.total - sum.notBuilt) + '</small>', '', 'check') +
        kpi(tr('In progress', 'جارية'), sum.active, '', 'chart', 'blue') +
        kpi(tr('Blocked', 'محجوبة'), sum.blocked, '', 'warning', 'red') +
        kpi(tr('Not started', 'لم تبدأ'), sum.todo, '', 'calendar', 'amber') +
        kpi(tr('Not built', 'غير مبنية'), sum.notBuilt, tr('excluded from progress', 'مستبعدة من التقدم'), 'layers', 'purple') +
        '</div>' +
        App.Data.phases.map(function (p) {
          var pr = App.Journey.phaseProgress(p.code);
          return card(tr('Phase ', 'المرحلة ') + p.code + ' · ' + App.L(p.title, p.title_ar),
            '<div class="progress-lg"><span style="width:' + pr.pct + '%"></span></div>' +
            '<p class="kpi-note" style="margin-top:8px">' + pr.done + '/' + pr.evaluable + tr(' steps done', ' خطوة مكتملة') +
              (pr.blocked ? ' · ' + badge(pr.blocked + tr(' blocked', ' محجوبة'), 'danger') : '') + '</p>' +
            table([tr('Step', 'الخطوة'), tr('Title', 'العنوان'), tr('Owner', 'المالك'), tr('Status', 'الحالة'), ''],
              pr.steps.map(function (s) {
                return [stepDot(s.id) + ' <code>' + esc(s.id) + '</code>', esc(App.L(s.title, s.title_ar)),
                  esc(App.roleLabelOf(s.role)), statusBadge(stepStatus(s.id)),
                  '<button class="ghost-btn" style="min-height:31px;padding:0 10px" data-screen="' + esc(s.id) + '">' + tr('Open', 'افتح') + '</button>'];
              })), App.L(p.purpose, p.purpose_ar));
        }).join('') +
        (bl.length ? card(tr('What is blocking you', 'ما الذي يعطلك'),
          table([tr('Step', 'الخطوة'), tr('What is wrong', 'الخلل'), tr('What to do', 'الإجراء'), tr('Who', 'المسؤول'), ''],
            bl.map(function (b) {
              return ['<code>' + esc(b.step) + '</code>', esc(b.reasons[0] || ''), esc(b.remediation[0] || '—'),
                esc(App.roleLabelOf(b.owner)),
                '<button class="ghost-btn" style="min-height:31px;padding:0 10px" data-screen="' + esc(b.step) + '">' + tr('Open', 'افتح') + '</button>'];
            }))) : '')
    }
  };

  /* ============================================================ behaviour == */
  function prompt2(title, fields, onSave) {
    var html = '<div class="x-form">' + fields.map(function (f) {
      if (f.type === 'select') return fld(f.id, f.label, '<select id="' + f.id + '">' +
        f.options.map(function (o) { return '<option value="' + esc(o.v) + '">' + esc(o.t) + '</option>'; }).join('') + '</select>');
      if (f.type === 'textarea') return fld(f.id, f.label, '<textarea id="' + f.id + '"></textarea>', true);
      return fld(f.id, f.label, '<input id="' + f.id + '" type="' + (f.type || 'text') + '" value="' + esc(f.value || '') + '">', f.full);
    }).join('') + '</div>';
    V.showModal(title, html, onSave);
  }

  var EXT = window.V41_EXT = {
    /* live body for a screen, or null to keep v4.1's own */
    screen: function (s) { App.State.lang=V.state.lang; return s && LIVE[s.id] ? LIVE[s.id]() : null; },

    /* a page that is not one of the 66 */
    page: function (id) { App.State.lang=V.state.lang; return PAGES[id] ? PAGES[id]() : null; },

    /* status dot beside every step in v4.1's sidebar */
    navDot: function (id) { return stepDot(id); },

    /* three extra entries at the top of v4.1's sidebar */
    navExtra: function () {
      var a = V.state.active;
      return '<button class="nav-overview' + (a === 'X-PATH' ? ' active' : '') + '" data-screen="X-PATH">' +
          icon('target') + '<span class="nav-label">' + tr('My path', 'مساري') + '</span>' +
          (App.Journey.summary().blocked ? '<span class="count-pill">' + App.Journey.summary().blocked + '</span>' : '') + '</button>' +
        '<button class="nav-overview' + (a === 'X-SETUP' ? ' active' : '') + '" data-screen="X-SETUP">' +
          icon('building') + '<span class="nav-label">' + tr('My organization', 'منظمتي') + '</span></button>' +
        '<button class="nav-overview' + (a === 'X-OUTPUT' ? ' active' : '') + '" data-screen="X-OUTPUT">' +
          icon('download') + '<span class="nav-label">' + tr('Output', 'المخرجات') + '</span></button>' +
        (['SYSTEM_ADMIN','METHODOLOGY_OWNER','ESG_PROGRAMME_MANAGER','ESG_TECH_REVIEWER'].indexOf(App.State.role)>-1 ?
          '<button class="nav-static' + (a === 'X-EXPERT' ? ' active' : '') + '" data-screen="X-EXPERT">' +
          icon('set') + '<span class="nav-label">' + tr('Expert specification', 'مواصفة الخبير') + '</span><span class="count-pill">117</span></button>' : '');
    },

    /* every action this extension adds */
    action: function (a) {
      var R = V.render, T = V.toast;
      function done(res, okMsg) {
        /* a completed action always closes its dialog, whichever path opened it */
        Array.prototype.forEach.call(document.querySelectorAll('.x-modal'), function (n) { n.remove(); });
        T(res.ok ? okMsg : (res.message || res.code));
        App.Gates._cache = null; R(); return true;
      }
      if (a === 'x-setup') { V.go('X-SETUP'); return true; }
      if (a === 'x-output') { V.go('X-OUTPUT'); return true; }
      if (a === 'x-path') { V.go('X-PATH'); return true; }
      if (a === 'x-expert') { V.go('X-EXPERT'); return true; }
      if (a === 'x-spec-search') { App.State.notes.specQuery=(document.getElementById('xSpecSearch')||{}).value||''; R(); return true; }
      if (a.indexOf('x-spec-') === 0) {
        var sid=a.replace('x-spec-',''),sp=App.Data.registry.screens[sid]; if(!sp)return true;
        V.showModal(sid+' · '+App.L(sp.en,sp.ar),'<div class="summary-list">'+
          '<div class="summary-row"><span>'+tr('Function','الوظيفة')+'</span><strong>'+esc(sp.fn)+'</strong></div>'+ 
          '<div class="summary-row"><span>'+tr('Primary role','الدور الرئيسي')+'</span><strong>'+esc(App.roleLabelOf(sp.role))+'</strong></div>'+ 
          '<div class="summary-row"><span>'+tr('Inputs','المدخلات')+'</span><strong>'+esc(sp.inp)+'</strong></div>'+ 
          '<div class="summary-row"><span>'+tr('Controlled output','المخرج المحكوم')+'</span><strong>'+esc(sp.out)+'</strong></div>'+ 
          '<div class="summary-row"><span>'+tr('Exit gate','بوابة الخروج')+'</span><strong>'+esc(sp.gate)+'</strong></div>'+ 
          '<div class="summary-row"><span>'+tr('Readiness','الجاهزية')+'</span><strong>'+statusBadge(sp.ready)+'</strong></div></div>'+ 
          '<h4>'+tr('Field contract','عقد الحقول')+'</h4>'+table([tr('Field','الحقل'),tr('Type','النوع'),tr('Required','مطلوب')],(sp.f||[]).slice(0,40).map(function(f){return [esc(App.L(f[0],f[1])),esc(f[2]),String(f[3])];})));
        return true;
      }
      if (a.indexOf('x-resolve-div-') === 0) {var did=a.replace('x-resolve-div-','');prompt2(tr('Resolve divergence','تسوية الاختلاف'),[{id:'xDivReason',label:tr('Reconciliation rationale','مبرر التسوية'),type:'textarea'}],function(){var v=(document.getElementById('xDivReason')||{}).value;if(!v)return false;App.State.notes.divergenceResolved=App.State.notes.divergenceResolved||{};App.State.notes.divergenceResolved[did]={reason:v,by:App.State.role,at:App.now()};App.Audit.write({action:'reconcile',objectType:'impact',objectId:did,reason:v});App.save();done({ok:true},tr('Divergence resolved.','تمت التسوية.'));});return true;}
      if (a === 'x-dl-import-template') { App.Tenant.download('ESG-bulk-import-template.csv','text/csv','activityId,siteId,periodStart,periodEnd,rawValue,rawUnit,dataSource\nACT-ENE-001,SITE-01,2025-01-01,2025-01-31,125000,kWh,Utility meter'); return true; }
      if (a === 'x-import-csv') {
        var fi=document.getElementById('xImportFile'),file=fi&&fi.files&&fi.files[0];if(!file){T(tr('Choose a CSV file first.','اختر ملف CSV أولًا.'));return true;}
        file.text().then(function(txt){var lines=txt.replace(/\r/g,'').split('\n').filter(Boolean),head=(lines.shift()||'').split(',').map(function(x){return x.trim();}),req=['activityId','siteId','periodStart','periodEnd','rawValue','rawUnit','dataSource'],missing=req.filter(function(k){return head.indexOf(k)<0;});if(missing.length){T(tr('Missing columns: ','أعمدة ناقصة: ')+missing.join(', '));return;}var imported=0,rejected=0;lines.forEach(function(line){var vals=line.split(','),o={};head.forEach(function(k,i){o[k]=(vals[i]||'').trim();});var site=App.Data.demo.sites.filter(function(s){return s.id===o.siteId;})[0];var act=App.Records.activity(o.activityId);if(!site||!act||!o.rawValue){rejected++;return;}var r=App.Records.create({activityId:o.activityId,siteId:o.siteId,entityId:site.entity,periodStart:o.periodStart,periodEnd:o.periodEnd,periodLabel:o.periodStart.slice(0,7),rawValue:Number(o.rawValue),rawUnit:o.rawUnit,dataSource:o.dataSource,dimensions:{site:o.siteId,period:o.periodStart.slice(0,7)}});if(r.ok)imported++;else rejected++;});App.State.notes.lastImport={id:'IMP-'+Date.now(),rows:lines.length,imported:imported,rejected:rejected,at:App.now()};App.Audit.write({action:'import',objectType:'record-batch',objectId:App.State.notes.lastImport.id,metadata:App.State.notes.lastImport});App.save();T(imported+tr(' row(s) imported · ',' صف مستورد · ')+rejected+tr(' rejected',' مرفوض'));R();});return true;
      }
      if (a.indexOf('x-explain-') === 0) {var rid=a.replace('x-explain-','');prompt2(tr('Explain material variance','تفسير الفرق الجوهري'),[{id:'xVarReason',label:tr('Variance explanation','تفسير الفرق'),type:'textarea'}],function(){var val=(document.getElementById('xVarReason')||{}).value;if(!val)return false;done(App.Records.edit(rid,{varianceExplanation:val}),tr('Explanation saved.','حُفظ التفسير.'));});return true;}
      if (a === 'x-approve-structure') {reportSections().forEach(function(x){x.status='APPROVED';});App.Audit.write({action:'approve',objectType:'report-structure',objectId:'CURRENT'});App.save();T(tr('Report structure approved.','اعتُمد هيكل التقرير.'));R();return true;}
      if (a === 'x-approve-narratives') {narrativeBlocks().forEach(function(x){if(x.en&&x.ar)x.status='APPROVED';});App.Audit.write({action:'approve',objectType:'narrative-set',objectId:'CURRENT'});App.save();T(tr('Reviewed narratives approved.','اعتُمد السرد المراجع.'));R();return true;}
      if (a === 'x-import-taxonomy') {var tf=document.getElementById('xTaxFile'),ff=tf&&tf.files&&tf.files[0];if(!ff){T(tr('Choose an official package file first.','اختر ملف حزمة رسمية أولًا.'));return true;}ff.arrayBuffer().then(function(buf){return crypto.subtle.digest('SHA-256',buf);}).then(function(dig){var h=Array.from(new Uint8Array(dig)).map(function(b){return b.toString(16).padStart(2,'0');}).join('');App.State.notes.taxonomyPackage={name:'Registered taxonomy package',fileName:ff.name,sha256:h,importedAt:App.now(),size:ff.size};App.State.notes.taxonomyBindings=[];App.Audit.write({action:'import',objectType:'taxonomy-package',objectId:ff.name,metadata:{sha256:h,size:ff.size}});App.save();T(tr('Taxonomy package registered. No QName was invented.','سُجلت حزمة التصنيف دون اختراع QName.'));R();}).catch(function(e){T(String(e));});return true;}
      if (a === 'x-recheck') { App.Gates.reEvaluate(); App.GRI.evaluateClaim(); T(tr('Everything re-checked.', 'أُعيد فحص كل شيء.')); R(); return true; }

      if (a === 'x-save-org') {
        var g = function (i) { var e = document.getElementById(i); return e ? e.value : ''; };
        return done(App.Tenant.createOrganization({ name_en: g('xoName'), name_ar: g('xoNameAr'), sector: g('xoSector'),
          hq: g('xoHq'), country: g('xoCountry'), employees: g('xoEmp'), contact: g('xoContact'), contactEmail: g('xoEmail'),
          replaceData: !!(document.getElementById('xoWipe') || {}).checked }),
          tr('Organization saved. This is now your tenant.', 'حُفظت المنظمة. صارت منظمتك.'));
      }
      if (a === 'x-save-cycle') {
        var gc = function (i) { var e = document.getElementById(i); return e ? e.value : ''; };
        return done(App.Tenant.setCycle({ label: gc('xcLabel'), periodStart: gc('xcStart'), periodEnd: gc('xcEnd'),
          targetApproach: gc('xcApproach') }), tr('Reporting cycle saved.', 'حُفظت دورة التقرير.'));
      }
      if (a === 'x-new-entity') {
        prompt2(tr('Add a legal entity', 'إضافة كيان قانوني'), [
          { id: 'xeName', label: tr('Legal name', 'الاسم القانوني') },
          { id: 'xeCountry', label: tr('Country', 'الدولة') }
        ], function () {
          var r = App.Tenant.addEntity({ name_en: (document.getElementById('xeName') || {}).value,
            country: (document.getElementById('xeCountry') || {}).value });
          done(r, tr('Legal entity added.', 'أُضيف الكيان.'));
        });
        return true;
      }
      if (a === 'x-new-site') {
        var ents = App.Data.demo.legalEntities;
        if (!ents.length) { T(tr('Add a legal entity first.', 'أضف كيانًا قانونيًا أولًا.')); return true; }
        prompt2(tr('Add a site', 'إضافة موقع'), [
          { id: 'xsName', label: tr('Site name', 'اسم الموقع') },
          { id: 'xsEnt', label: tr('Legal entity', 'الكيان القانوني'), type: 'select',
            options: ents.map(function (e) { return { v: e.id, t: e.name_en }; }) },
          { id: 'xsCountry', label: tr('Country', 'الدولة') },
          { id: 'xsIn', label: tr('In reporting boundary', 'داخل الحدود'), type: 'select',
            options: [{ v: 'yes', t: tr('Yes', 'نعم') }, { v: 'no', t: tr('No — excluded', 'لا — مستبعد') }] },
          { id: 'xsWhy', label: tr('Exclusion rationale (required if excluded)', 'مبرر الاستبعاد'), type: 'textarea' }
        ], function () {
          var gv = function (i) { var e = document.getElementById(i); return e ? e.value : ''; };
          done(App.Tenant.addSite({ name_en: gv('xsName'), entity: gv('xsEnt'), country: gv('xsCountry'),
            inBoundary: gv('xsIn') === 'yes', exclusionRationale: gv('xsWhy') }), tr('Site added.', 'أُضيف الموقع.'));
        });
        return true;
      }
      if (a.indexOf('x-approve-boundary-') === 0) {
        var which = a.replace('x-approve-boundary-', '');
        prompt2(tr('Approve boundary', 'اعتماد الحدود'),
          [{ id: 'xbBasis', label: tr('State the basis on which this boundary is drawn', 'اذكر الأساس'), type: 'textarea' }],
          function () { done(App.Tenant.approveBoundary(which, { basis: (document.getElementById('xbBasis') || {}).value }),
            tr('Boundary approved.', 'اعتُمدت الحدود.')); });
        return true;
      }
      if (a.indexOf('x-factor-') === 0) {
        var fid = a.replace('x-factor-', '');
        var ex = App.Data.factorSets.filter(function (x) { return x.factorId === fid; })[0] || {};
        prompt2(tr('Approve an emission factor', 'اعتماد عامل انبعاث'), [
          { id: 'xfVal', label: tr('Value', 'القيمة'), type: 'number', value: ex.value },
          { id: 'xfUnit', label: tr('Unit (output/input)', 'الوحدة'), value: ex.unit },
          { id: 'xfSrc', label: tr('Source organization', 'الجهة المصدرة') },
          { id: 'xfPub', label: tr('Source publication', 'المنشور المصدر') },
          { id: 'xfGeo', label: tr('Geography', 'النطاق الجغرافي'), value: ex.geography },
          { id: 'xfYear', label: tr('Factor year', 'سنة العامل'), type: 'number', value: ex.year },
          { id: 'xfGwp', label: 'GWP set', type: 'select', options: [
            { v: 'IPCC AR6 (100-yr)', t: 'IPCC AR6 (100-yr)' }, { v: 'IPCC AR5 (100-yr)', t: 'IPCC AR5 (100-yr)' },
            { v: 'Not applicable', t: tr('Not applicable', 'لا ينطبق') }] }
        ], function () {
          var gv = function (i) { var e = document.getElementById(i); return e ? e.value : ''; };
          done(App.Tenant.approveFactor({ factorId: fid, value: gv('xfVal'), unit: gv('xfUnit'), source: gv('xfSrc'),
            sourcePublication: gv('xfPub'), geography: gv('xfGeo'), year: gv('xfYear'), gwpSet: gv('xfGwp') }),
            tr('Factor approved. Calculations using it will now run.', 'اعتُمد العامل. الحسابات ستعمل الآن.'));
        });
        return true;
      }
      if (a === 'x-new-record') {
        var acts = App.Data.registry.activities, sites = App.Data.demo.sites;
        if (!sites.length) { T(tr('Add a site first.', 'أضف موقعًا أولًا.')); return true; }
        prompt2(tr('Add a record', 'إضافة سجل'), [
          { id: 'xrAct', label: tr('Activity', 'النشاط'), type: 'select',
            options: acts.map(function (x) { return { v: x.activity_id, t: x.activity_id + ' · ' + x.name_en }; }) },
          { id: 'xrSite', label: tr('Site', 'الموقع'), type: 'select',
            options: sites.map(function (x) { return { v: x.id, t: x.name_en }; }) },
          { id: 'xrStart', label: tr('Period start', 'بداية الفترة'), type: 'date', value: App.Data.demo.cycle.periodStart },
          { id: 'xrEnd', label: tr('Period end', 'نهاية الفترة'), type: 'date', value: App.Data.demo.cycle.periodEnd },
          { id: 'xrVal', label: tr('Value', 'القيمة'), type: 'number' },
          { id: 'xrUnit', label: tr('Unit', 'الوحدة') },
          { id: 'xrSrc', label: tr('Data source', 'مصدر البيانات') }
        ], function () {
          var gv = function (i) { var e = document.getElementById(i); return e ? e.value : ''; };
          var site = App.Data.demo.sites.filter(function (s) { return s.id === gv('xrSite'); })[0] || {};
          done(App.Records.create({ activityId: gv('xrAct'), siteId: gv('xrSite'),
            entityId: site.entity || (App.Data.demo.legalEntities[0] || {}).id,
            periodStart: gv('xrStart'), periodEnd: gv('xrEnd'), periodLabel: gv('xrStart').slice(0, 7),
            rawValue: Number(gv('xrVal')), rawUnit: gv('xrUnit'), dimensions: {}, dataSource: gv('xrSrc') }),
            tr('Record created in DRAFT.', 'أُنشئ السجل كمسودة.'));
        });
        return true;
      }
      if (a.indexOf('x-rec-') === 0) { recordModal(a.replace('x-rec-', '')); return true; }
      if (a === 'x-calc') {
        var res = App.Calculations.runCycle({ sandbox: false });
        V.showModal(tr('Calculation run', 'تشغيل الحسابات'),
          '<p>' + res.ok + tr(' calculations executed · ', ' عملية منفذة · ') + res.refused + tr(' blocked', ' محجوبة') + '</p>' +
          table([tr('Domain', 'المجال'), tr('Total', 'الإجمالي'), tr('Unit', 'الوحدة')],
            Object.keys(res.byDomain).map(function (d) { return [esc(d), '<strong>' + num(res.byDomain[d].total) + '</strong>', esc(res.byDomain[d].unit)]; }),
            tr('Nothing computed — no approved emission factor.', 'لم يُحسب شيء — لا يوجد عامل معتمد.')) +
          (res.refusals.length ? '<p style="margin-top:12px"><strong>' + tr('Refusals', 'حالات الرفض') + '</strong></p><ul>' +
            res.refusals.slice(0, 5).map(function (x) { return '<li>' + esc(x.message) + '</li>'; }).join('') + '</ul>' : ''));
        App.Gates._cache = null; return true;
      }
      if (a === 'x-approve-topics') {
        return done(App.Materiality.approveTopics(App.Materiality.proposedTopics(), 'Approved from the path'),
          tr('Material topic list approved.', 'اعتُمدت قائمة الموضوعات.'));
      }
      if (a === 'x-assurance-edit') {
        var rec = App.Records.approved()[0];
        var g2 = App.Permissions.canPerformAction({ permission: 'record.edit', object: rec, role: 'ASSURANCE_REVIEWER' });
        V.showModal(tr('Refused', 'مرفوض'), '<p>' + badge(g2.code, 'danger') + '</p><p>' + esc(App.L(g2.reason.en, g2.reason.ar)) + '</p>');
        return true;
      }
      if (a === 'x-dl-report') { App.Tenant.exportReport(); T(tr('Report downloaded.', 'نُزّل التقرير.')); return true; }
      if (a === 'x-dl-index') { App.Tenant.exportContentIndex(); T(tr('Content index downloaded.', 'نُزّل الفهرس.')); return true; }
      if (a === 'x-dl-dataset') { App.Tenant.exportDataset(); T(tr('Dataset downloaded.', 'نُزّلت البيانات.')); return true; }
      if (a === 'x-dl-backup') { App.Tenant.exportBackup(); T(tr('Backup downloaded.', 'نُزّلت النسخة.')); return true; }
      if (a === 'x-restore') {
        var inp = document.getElementById('xRestore'), file = inp && inp.files && inp.files[0];
        if (!file) { T(tr('Choose a backup file first.', 'اختر ملف النسخة أولًا.')); return true; }
        file.text().then(function (txt) { var r = App.Tenant.importBackup(txt);
          T(r.ok ? tr('Restored: ', 'استُعيدت: ') + r.organization.name_en : (r.message || r.code));
          App.Gates._cache = null; V.render(); });
        return true;
      }
      if (a.indexOf('go-') === 0) { V.go(a.replace('go-', '')); return true; }
      if (a.indexOf('x-rt-') === 0) {
        var parts = a.replace('x-rt-', '').split('|');
        var res2 = App.Records.transition(parts[0], parts[1], parts[2] ? { reason: parts[2] } : {});
        if (!res2.ok && res2.code === 'REASON_REQUIRED') {
          prompt2(tr('Reason required', 'السبب مطلوب'), [{ id: 'xrsn', label: tr('Reason', 'السبب'), type: 'textarea' }],
            function () { var rr = App.Records.transition(parts[0], parts[1], { reason: (document.getElementById('xrsn') || {}).value });
              done(rr, tr('Done.', 'تم.')); });
          return true;
        }
        return done(res2, tr('Record moved.', 'انتقل السجل.'));
      }
      return false;
    }
  };

  function recordModal(id) {
    var r = App.Records.byId(id); if (!r) return;
    var a = App.Records.activity(r.activityId);
    var v = App.Records.validate(r, 'submit');
    var evd = App.Evidence.forRecord(r.id);
    var next = { DRAFT: 'VALIDATED', VALIDATED: 'SUBMITTED', SUBMITTED: 'UNDER_REVIEW',
      UNDER_REVIEW: 'APPROVED', RETURNED: 'VALIDATED', REOPENED: 'VALIDATED' }[r.status];
    V.showModal(r.id + ' · ' + (a ? a.name_en : r.activityId),
      table([tr('Field', 'الحقل'), tr('Value', 'القيمة')], [
        [tr('Status', 'الحالة'), statusBadge(r.status) + ' · v' + r.version],
        [tr('Site', 'الموقع'), esc(App.siteName(r.siteId))],
        [tr('Period', 'الفترة'), esc(r.periodStart) + ' → ' + esc(r.periodEnd)],
        [tr('Value', 'القيمة'), '<strong>' + num(r.rawValue) + ' ' + esc(r.rawUnit) + '</strong>'],
        [tr('Data source', 'المصدر'), esc(r.dataSource || '—')],
        [tr('Evidence', 'الأدلة'), evd.length ? evd.map(function (e) { return esc(e.fileName); }).join(', ') : badge(tr('none linked', 'لا يوجد'), 'danger')],
        [tr('Validation', 'التحقق'), v.blockers && v.blockers.length ? badge(v.blockers.length + tr(' blocking', ' حاجب'), 'danger') : badge(tr('clear', 'سليم'), 'success')]
      ]) +
      (v.all && v.all.length ? '<ul style="margin-top:10px">' + v.all.map(function (x) {
        return '<li>' + badge(x.severity, x.severity === 'BLOCKER' ? 'danger' : 'warn') + ' ' + esc(x.message) + '</li>'; }).join('') + '</ul>' : '') +
      '<div style="margin-top:14px;display:flex;gap:9px;flex-wrap:wrap">' +
      (next ? btn(tr('Move to ', 'انقل إلى ') + next, 'primary', 'x-rt-' + r.id + '|' + next, 'check') : '') +
      (r.status === 'UNDER_REVIEW' ? btn(tr('Return with a reason', 'إعادة بسبب'), 'danger', 'x-rt-' + r.id + '|RETURNED', 'warning') : '') +
      '</div>');
  }

  /* ------------------------------------------------------------- start up -- */
  function boot() {
    App.Audit.isolated(function () { App.GRI.evaluateClaim(); App.Gates.results(); });
    V.render();
    if (window.console) console.info('v4.1 base + engine extension ready · ' +
      App.Data.journeySteps.length + ' steps · ' + App.Data.registry.activities.length + ' activities');
  }
  if (App.hydrate) App.hydrate().then(boot).catch(boot); else boot();
})();
