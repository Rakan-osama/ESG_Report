/* CR-10 · modules/audit.js
   Append-only audit model. Events are frozen on creation and the array is only
   ever pushed to — there is no update or delete path in this module, and no
   other module writes to App.State.audit directly.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  var counter = 0;
  var correlation = null;

  /* CR-10.1 · P0-19 — self-tests and startup evaluation must not pollute the
     business audit trail. suspend() opens an isolated window: events are frozen
     into a sink and never enter App.State.audit or Recent Activity. */
  var suspended = 0, sink = [];

  var Audit = App.Audit = {
    /* start a correlated unit of work (a submit, an approval, a gate run…) */
    begin: function (label) { correlation = 'COR-' + (++counter) + '-' + label; return correlation; },
    end: function () { correlation = null; },

    suspend: function () { suspended++; return sink; },
    resume: function () { suspended = Math.max(0, suspended - 1); var out = sink.slice(); if (!suspended) sink = []; return out; },
    suspended: function () { return suspended > 0; },
    sink: function () { return sink.slice(); },

    /* run fn with the business audit trail sealed; always resumes, even on throw */
    isolated: function (fn) {
      Audit.suspend();
      try { return fn(); } finally { Audit.resume(); }
    },

    write: function (o) {
      var S = App.State;
      if (suspended) {
        var iso = Object.freeze({ isolated: true, action: o.action, objectType: o.objectType || null,
          objectId: o.objectId || null, timestamp: App.now(), reason: o.reason || null });
        sink.push(iso);
        return iso;                 /* never reaches App.State.audit */
      }
      var ev = Object.freeze({
        eventId: 'AUD-' + String(++counter).padStart(6, '0'),
        tenantId: App.State.tenantNamespace || 'TEN-EEG',
        user: S.user.id,
        userName: S.user.name,
        role: S.role,
        action: o.action,
        objectType: o.objectType || null,
        objectId: o.objectId || null,
        objectVersion: o.objectVersion || null,
        previousStatus: o.previousStatus || null,
        newStatus: o.newStatus || null,
        timestamp: App.now(),
        reason: o.reason || null,
        correlationId: o.correlationId || correlation || null,
        metadata: Object.freeze(o.metadata || {})
      });
      S.audit.unshift(ev);          /* append only */
      if (S.audit.length > 1000) S.audit.length = 1000;  /* prototype ring buffer, oldest dropped, never edited */
      App.save();
      return ev;
    },

    /* read models */
    forObject: function (id) { return App.State.audit.filter(function (e) { return e.objectId === id; }); },
    byAction: function (a) { return App.State.audit.filter(function (e) { return e.action === a; }); },
    recent: function (n) { return App.State.audit.slice(0, n || 10); }
  };

  /* the actions this build emits — used by the QA runner to assert coverage */
  Audit.ACTIONS = ['create', 'edit', 'validate', 'submit', 'review', 'return', 'approve', 'reopen',
    'evidence.link', 'evidence.supersede', 'calculation.run', 'claim.evaluate',
    'gate.evaluate', 'report.approve', 'export', 'permission.denied', 'login', 'logout',
    'materiality.approve', 'omission.request', 'omission.approve'];
})(window.App)