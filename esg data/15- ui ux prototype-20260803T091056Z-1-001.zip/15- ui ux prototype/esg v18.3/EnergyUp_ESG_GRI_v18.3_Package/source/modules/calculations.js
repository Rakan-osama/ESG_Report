/* CR-10 · modules/calculations.js
   Runs only registered methods. There is no keyword matching on activity names
   and no fallback factor of 1. A method that has no approved factor refuses to
   run and says so. Output units come from the method, so a workforce or waste
   indicator is never expressed in tCO2e.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  var C = App.Calculations = {

    /* One activity can feed several indicators — an electricity reading is both
       an energy figure and a Scope 2 emissions figure. The engine therefore
       returns every applicable method and never guesses by array order. */
    methodsFor: function (activityId) {
      return App.Data.calculationMethods.filter(function (m) {
        return !m.superseded && m.appliesTo.indexOf(activityId) > -1;
      });
    },
    methodFor: function (activityId, methodId) {
      var list = C.methodsFor(activityId);
      if (methodId) return list.filter(function (m) { return m.id === methodId; })[0] || null;
      return list[0] || null;
    },
    factor: function (id) {
      return App.Data.factorSets.filter(function (f) { return f.id === id; })[0] || null;
    },

    /* run a single approved record through its method */
    run: function (record, opts) {
      opts = opts || {};
      var method = C.methodFor(record.activityId, opts.methodId);
      if (!method) return refuse('NO_METHOD', opts.methodId
        ? 'Method ' + opts.methodId + ' does not cover activity ' + record.activityId + '.'
        : 'No registered calculation method covers activity ' + record.activityId + '.');

      /* CR-10.1 · P0-06 — a demo factor may only run inside the developer
         sandbox, which is reachable from Administration → Demo controls and
         nowhere else. Product Mode has no path that sets sandbox: true. */
      var sandbox = opts.sandbox === true;
      var factor = method.factorSet ? C.factor(method.factorSet) : null;
      if (method.factorSet && !factor) return refuse('FACTOR_MISSING', 'Method ' + method.id + ' references factor set ' + method.factorSet + ' which is not registered.');
      if (factor) {
        var required = ['factorId', 'value', 'unit', 'source', 'geography', 'year', 'approval'];
        var incomplete = required.filter(function (k) { return factor[k] === undefined || factor[k] === null || factor[k] === ''; });
        if (incomplete.length && !sandbox)
          return refuse('FACTOR_INCOMPLETE', 'CALCULATION BLOCKED — factor ' + factor.factorId + ' is missing: ' + incomplete.join(', ') + '.');
        if (factor.approval !== 'APPROVED' && !sandbox)
          return refuse('FACTOR_NOT_APPROVED', 'CALCULATION BLOCKED — NO APPROVED APPLICABLE FACTOR. Factor ' + factor.factorId + ' is ' + factor.approval + '; a methodology owner must sign off its source, geography, year and GWP set.');
        if (factor.supersededBy && !sandbox)
          return refuse('FACTOR_SUPERSEDED', 'CALCULATION BLOCKED — factor ' + factor.factorId + ' is superseded by ' + factor.supersededBy + '.');
      }

      var out, trace, denominatorTrace = null;
      if (factor) {
        var r = App.Units.applyFactor(record.rawValue, record.rawUnit, factor);
        if (!r.ok) return refuse(r.code, r.message);
        var toTarget = App.Units.convert(r.value, r.unit, method.outputUnit);
        if (!toTarget.ok) return refuse(toTarget.code, toTarget.message);
        out = toTarget.value; trace = r.trace.concat(toTarget.trace);
      } else {
        var conv = App.Units.convert(record.rawValue, record.rawUnit, method.outputUnit);
        if (!conv.ok) {
          /* ratio-style methods carry a denominator instead of a unit conversion */
          if (method.outputFamily === 'ratio') {
            /* CR-10.1 · P0-07 — the denominator is resolved from approved
               records in the same scope and period. A worked-example value is
               accepted only inside the developer sandbox. */
            var den = C.resolveDenominator(method, record, opts);
            if (!den.ok) return refuse(den.code, den.message);
            var mult = method.ratioMultiplier || (method.outputUnit === '%' ? 100 : 1);
            out = record.rawValue / den.value * mult;
            denominatorTrace = den;
            trace = [{ step: 'denominator', expression: 'denominator = ' + round(den.value) + ' ' + den.unit + '  [' + den.basis + ']' },
                     { step: 'ratio', expression: record.rawValue + ' ÷ ' + round(den.value) +
              (mult !== 1 ? ' × ' + mult.toLocaleString('en-US') : '') + ' = ' + round(out) + ' ' + method.outputUnit }];
          } else return refuse(conv.code, conv.message);
        } else { out = conv.value; trace = conv.trace; }
      }

      var run = {
        id: 'CALC-RUN-' + (App.State.calcRuns.length + 1001),
        recordId: record.id, recordVersion: record.version,
        methodId: method.id, methodVersion: method.version, domain: method.domain,
        factorId: factor ? factor.factorId : null, factorApproval: factor ? factor.approval : null,
        gwpSet: factor ? factor.gwpSet : null,
        input: record.rawValue, inputUnit: record.rawUnit,
        output: round(out), outputUnit: method.outputUnit,
        uncertainty: method.uncertainty, estimated: !!record.estimated,
        numeratorRecordIds: [record.id],
        denominatorRecordIds: denominatorTrace ? denominatorTrace.recordIds : [],
        denominatorValue: denominatorTrace ? round(denominatorTrace.value) : null,
        denominatorUnit: denominatorTrace ? denominatorTrace.unit : null,
        denominatorBasis: denominatorTrace ? denominatorTrace.basis : null,
        sandbox: sandbox === true,
        executedAt: App.now(), executedBy: App.State.role,
        reviewStatus: 'PENDING_REVIEW',
        trace: trace
      };
      App.State.calcRuns.push(run);
      App.Audit.write({
        action: 'calculation.run', objectType: 'record', objectId: record.id, objectVersion: record.version,
        metadata: { method: method.id, factor: run.factorId, output: run.output + ' ' + run.outputUnit }
      });
      return { ok: true, run: run };

      function refuse(code, message) {
        App.Audit.write({ action: 'calculation.run', objectType: 'record', objectId: record.id, reason: code, metadata: { refused: true, message: message } });
        return { ok: false, code: code, message: message };
      }
    },

    /* Resolve a ratio denominator from approved records: same organisation,
       same cycle, same entity or site scope, compatible period. */
    resolveDenominator: function (method, record, opts) {
      opts = opts || {};
      if (opts.sandbox && opts.denominator)
        return { ok: true, value: opts.denominator, unit: method.denominatorUnit || 'unit', recordIds: [], basis: 'DEMO worked-example denominator — sandbox only' };

      var sources = method.denominatorActivities || [];
      if (!sources.length)
        return { ok: false, code: 'DENOMINATOR_UNDEFINED',
          message: 'CALCULATION BLOCKED — method ' + method.id + ' declares no denominator activity. The methodology owner must define one.' };

      var pool = App.Records.approved().filter(function (r) {
        if (sources.indexOf(r.activityId) === -1) return false;
        if (r.cycleId && record.cycleId && r.cycleId !== record.cycleId) return false;
        if (method.denominatorScope === 'site' && r.siteId !== record.siteId) return false;
        if (method.denominatorScope === 'entity' && r.entityId !== record.entityId) return false;
        if (record.periodStart && record.periodEnd && r.periodStart && r.periodEnd) {
          if (r.periodEnd < record.periodStart || r.periodStart > record.periodEnd) return false;
        }
        return true;
      });

      if (!pool.length)
        return { ok: false, code: 'DENOMINATOR_MISSING',
          message: 'CALCULATION BLOCKED — REQUIRED DENOMINATOR RECORD NOT AVAILABLE. Approve a record for ' + sources.join(' or ') + ' in the same scope and period.' };

      var unit = method.denominatorUnit || pool[0].rawUnit;
      var total = 0, used = [];
      for (var i = 0; i < pool.length; i++) {
        var conv = App.Units.convert(pool[i].rawValue, pool[i].rawUnit, unit);
        if (!conv.ok) return { ok: false, code: conv.code, message: 'CALCULATION BLOCKED — denominator record ' + pool[i].id + ': ' + conv.message };
        total += conv.value; used.push(pool[i].id);
      }
      if (!total) return { ok: false, code: 'DENOMINATOR_ZERO', message: 'CALCULATION BLOCKED — the resolved denominator is zero.' };
      return { ok: true, value: total, unit: unit, recordIds: used,
        basis: used.length + ' approved record(s) for ' + sources.join(', ') + ' in the same scope and period' };
    },

    /* Product Mode entry point — no sandbox, ever */
    runProduct: function (record) { return C.run(record, { sandbox: false }); },

    /* Developer sandbox — demo factors and worked-example denominators permitted,
       output is stamped and can never satisfy a gate or a claim */
    runSandbox: function (record, opts) {
      opts = opts || {}; opts.sandbox = true;
      var res = C.run(record, opts);
      if (res.ok) { res.run.sandbox = true; res.run.reportable = false; res.run.watermark = 'DEMO CALCULATION — NOT FOR REPORTING, APPROVAL, ASSURANCE, OR PUBLICATION'; }
      return res;
    },

    /* run every approved record; returns a summary by domain */
    runCycle: function (opts) {
      var cor = App.Audit.begin('calc-cycle');
      var results = { ok: 0, refused: 0, byDomain: {}, refusals: [] };
      App.Records.approved().forEach(function (r) {
        var methods = C.methodsFor(r.activityId);
        if (!methods.length) {
          results.refused++;
          results.refusals.push({ record: r.id, code: 'NO_METHOD', message: 'No registered method covers activity ' + r.activityId + '.' });
          return;
        }
        methods.forEach(function (m) {
          var o = {}; for (var k in opts) o[k] = opts[k];
          o.methodId = m.id;
          /* CR-10.1: no worked-example fallback. A missing denominator blocks. */
          var res = C.run(r, o);
          if (res.ok) {
            results.ok++;
            var d = res.run.domain;
            results.byDomain[d] = results.byDomain[d] || { total: 0, unit: res.run.outputUnit, count: 0 };
            results.byDomain[d].total = round(results.byDomain[d].total + res.run.output);
            results.byDomain[d].count++;
          } else { results.refused++; results.refusals.push({ record: r.id, code: res.code, message: res.message }); }
        });
      });
      App.Audit.end();
      App.save();
      return results;
    },

    /* self-test of every registered method against its worked example */
    selfTest: function () {
      /* Method self-tests run in a disposable state window. Earlier builds
         isolated audit events but still appended synthetic CALC-RUN rows,
         contaminating Product Mode and gate history. */
      var beforeRuns = App.clone(App.State.calcRuns);
      try { return App.Audit.isolated(function () { return C._selfTest(); }); }
      finally { App.State.calcRuns = beforeRuns; }
    },
    _selfTest: function () {
      return App.Data.calculationMethods.map(function (m) {
        var rec = { id: 'SELFTEST', version: 1, activityId: m.appliesTo[0], rawValue: m.worked.input, rawUnit: m.worked.unit, estimated: false };
        var res = C.run(rec, { sandbox: true, denominator: m.worked.denominator, methodId: m.id });
        var pass = res.ok && Math.abs(res.run.output - m.worked.expected) <= Math.max(0.01, Math.abs(m.worked.expected) * 0.001)
          && res.run.outputUnit === m.worked.expectedUnit;
        return { method: m.id, expected: m.worked.expected + ' ' + m.worked.expectedUnit,
          actual: res.ok ? res.run.output + ' ' + res.run.outputUnit : (res.code + ': ' + res.message),
          pass: !!pass };
      });
    },

    runsFor: function (recordId) { return App.State.calcRuns.filter(function (r) { return r.recordId === recordId; }); }
  };

  function round(n) { return Math.round(n * 100) / 100; }
})(window.App)