/* CR-10 · modules/evidence.js
   Evidence is an object, not a text reference. One evidence object may support
   many records and one record may carry many evidence objects. Superseding
   preserves the previous version — nothing is deleted.

   Hashing: this standalone build does not read file bytes, so hashes are
   SIMULATED and labelled as such everywhere they appear. No screen claims a
   real digest.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  /* CR-10.1 · P0-01 — where the browser exposes SubtleCrypto over a real file
     the digest is computed from the bytes and marked SHA-256. Seeded objects
     keep a declared SIM- digest. The product never presents one as the other. */
  function hashBytes(buf) {
    if (!(window.crypto && window.crypto.subtle && window.crypto.subtle.digest)) return Promise.resolve(null);
    return window.crypto.subtle.digest('SHA-256', buf).then(function (d) {
      return Array.prototype.map.call(new Uint8Array(d), function (b) { return ('00' + b.toString(16)).slice(-2); }).join('');
    }).catch(function () { return null; });
  }

  var E = App.Evidence = {
    hashFile: function (file) {
      if (!file || !file.arrayBuffer) return Promise.resolve(null);
      return file.arrayBuffer().then(hashBytes);
    },
    all: function () { return App.State.evidence; },
    active: function () { return App.State.evidence.filter(function (e) { return e.status === 'ACTIVE'; }); },
    byId: function (id) { return App.State.evidence.filter(function (e) { return e.id === id; })[0] || null; },
    forRecord: function (recordId) {
      var r = App.Records.byId(recordId);
      return (r && r.evidenceIds || []).map(E.byId).filter(Boolean);
    },
    recordsFor: function (evidenceId) {
      return App.State.records.filter(function (r) { return (r.evidenceIds || []).indexOf(evidenceId) > -1; });
    },

    /* deterministic simulated digest — clearly not a cryptographic hash */
    simulatedHash: function (seed) {
      var h = 0x811c9dc5, s = String(seed);
      for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = (h * 0x01000193) >>> 0; }
      return 'SIM-' + h.toString(16).padStart(8, '0');
    },

    create: function (data) {
      if (!App.Permissions.guard('evidence.upload', null)) return { ok: false, code: 'DENIED' };
      var e = Object.assign({
        id: App.nextId('EV'), version: 1, status: 'ACTIVE', previousVersion: null,
        uploader: App.State.role, uploadedAt: App.now(), relatedType: 'record', relatedIds: [],
        sensitivity: 'Internal', retention: '7 years', reviewStatus: 'Pending', notes: '',
        hashMethod: 'SIMULATED (no binary read in this build)'
      }, data);
      /* a real digest is used when one was computed from the file bytes */
      if (data && data.hash && data.hashMethod === 'SHA-256') { e.hash = data.hash; e.hashMethod = 'SHA-256'; }
      else { e.hash = E.simulatedHash(e.id + e.fileName + e.uploadedAt); e.hashMethod = 'SIMULATED (no binary read)'; }
      e.originalFileName = data && data.originalFileName ? data.originalFileName : e.fileName;
      App.State.evidence.push(e);
      App.Audit.write({ action: 'create', objectType: 'evidence', objectId: e.id, newStatus: 'ACTIVE', metadata: { file: e.fileName, hash: e.hash, simulated: e.hashMethod !== 'SHA-256' } });
      App.save();
      return { ok: true, evidence: e };
    },

    link: function (evidenceId, recordId) {
      var r = App.Records.byId(recordId), e = E.byId(evidenceId);
      if (!r || !e) return { ok: false, code: 'NOT_FOUND' };
      if (!App.Permissions.guard('evidence.upload', r)) return { ok: false, code: 'DENIED' };
      if (e.status === 'SUPERSEDED') return { ok: false, code: 'SUPERSEDED', message: App.L('A superseded evidence object cannot be linked.', 'لا يمكن ربط دليل مُستبدل.') };
      if ((r.evidenceIds || []).indexOf(evidenceId) === -1) r.evidenceIds.push(evidenceId);
      if (e.relatedIds.indexOf(recordId) === -1) e.relatedIds.push(recordId);
      App.Audit.write({ action: 'evidence.link', objectType: 'evidence', objectId: e.id, metadata: { record: recordId } });
      App.save();
      return { ok: true };
    },

    unlinkLegacy: function (evidenceId, recordId) {
      var r = App.Records.byId(recordId), e = E.byId(evidenceId);
      if (!r || !e) return { ok: false, code: 'NOT_FOUND' };
      if (!App.Permissions.guard('evidence.upload', r)) return { ok: false, code: 'DENIED' };
      r.evidenceIds = r.evidenceIds.filter(function (x) { return x !== evidenceId; });
      e.relatedIds = e.relatedIds.filter(function (x) { return x !== recordId; });
      App.Audit.write({ action: 'evidence.link', objectType: 'evidence', objectId: e.id, reason: 'unlink', metadata: { record: recordId } });
      App.save();
      return { ok: true };
    },

    /* supersede: previous version stays, marked SUPERSEDED, links carried forward */
    /* unlinking is a governed act: it removes support from a record, so the
       reason is mandatory and it is written to the audit log */
    unlinkWithReason: function (evidenceId, recordId, reason) {
      if (!reason) return { ok: false, code: 'REASON_REQUIRED', message: App.L('A reason is required to unlink evidence.', 'السبب مطلوب لفك ربط الدليل.') };
      var e = E.byId(evidenceId), r = App.Records.byId(recordId);
      if (!e || !r) return { ok: false, code: 'NOT_FOUND' };
      if (!App.Permissions.guard('evidence.upload', r)) return { ok: false, code: 'DENIED' };
      if (['SUBMITTED', 'UNDER_REVIEW', 'APPROVED'].indexOf(r.status) > -1)
        return { ok: false, code: 'STATUS_LOCKED', message: App.L('Evidence cannot be unlinked while the record is in ' + r.status + '.', 'لا يمكن فك ربط الدليل والسجل في حالة ' + r.status + '.') };
      e.relatedIds = (e.relatedIds || []).filter(function (x) { return x !== recordId; });
      r.evidenceIds = (r.evidenceIds || []).filter(function (x) { return x !== evidenceId; });
      App.Audit.write({ action: 'evidence.link', objectType: 'evidence', objectId: evidenceId, previousStatus: 'LINKED', newStatus: 'UNLINKED', reason: reason, metadata: { record: recordId } });
      App.save();
      return { ok: true, evidence: e };
    },

    supersede: function (oldId, data) {
      var old = E.byId(oldId);
      if (!old) return { ok: false, code: 'NOT_FOUND' };
      if (!App.Permissions.guard('evidence.supersede', null)) return { ok: false, code: 'DENIED' };
      var res = E.create(Object.assign({}, data, {
        version: old.version + 1, previousVersion: old.id,
        relatedType: old.relatedType, relatedIds: old.relatedIds.slice(),
        sensitivity: old.sensitivity, retention: old.retention
      }));
      if (!res.ok) return res;
      var nu = res.evidence;
      old.status = 'SUPERSEDED';
      old.notes = (old.notes ? old.notes + ' ' : '') + 'Superseded by ' + nu.id + '.';
      /* move the link on every record that used the old object */
      nu.relatedIds.forEach(function (rid) {
        var r = App.Records.byId(rid);
        if (r) { r.evidenceIds = r.evidenceIds.filter(function (x) { return x !== oldId; }); r.evidenceIds.push(nu.id); }
      });
      App.Audit.write({ action: 'evidence.supersede', objectType: 'evidence', objectId: old.id, previousStatus: 'ACTIVE', newStatus: 'SUPERSEDED', metadata: { replacedBy: nu.id, records: nu.relatedIds.length } });
      App.save();
      return { ok: true, evidence: nu, previous: old };
    },

    stats: function () {
      var all = App.State.evidence;
      return {
        total: all.length,
        active: all.filter(function (e) { return e.status === 'ACTIVE'; }).length,
        superseded: all.filter(function (e) { return e.status === 'SUPERSEDED'; }).length,
        pendingReview: all.filter(function (e) { return e.reviewStatus === 'Pending'; }).length,
        linked: all.filter(function (e) { return e.relatedIds.length; }).length,
        multiLinked: all.filter(function (e) { return e.relatedIds.length > 1; }).length,
        simulatedHashes: all.filter(function (e) { return E.classifyEvidenceHash(e).code === 'SIMULATED_PROTOTYPE_DIGEST'; }).length
      };
    }
  };

  /* ----------------------------------------------------------------------
     CR-10.1.1 · P0-03 — one classifier, used by every screen.
     v1.1 let each view decide for itself what a digest was; the repository
     labelled everything simulated while the record detail told the truth.
     Nothing may inspect e.hash directly any more.
     ---------------------------------------------------------------------- */
  var HEX64 = /^[0-9a-f]{64}$/i;

  E.classifyEvidenceHash = function (evidence) {
    var e = evidence || {};
    var h = e.hash == null ? '' : String(e.hash);
    var method = String(e.hashMethod || '');

    if (!h || e.hashStatus === 'PENDING' || /pending/i.test(method)) {
      return {
        code: 'HASH_PENDING', tone: 'warn',
        label: App.L('Hash pending', 'البصمة قيد الاحتساب'),
        detail: App.L('No digest has been computed for this object yet.', 'لم تُحتسب بصمة لهذا الكائن بعد.'),
        verified: false, simulated: false
      };
    }
    if (/^SIM-/.test(h) || /simulat/i.test(method)) {
      return {
        code: 'SIMULATED_PROTOTYPE_DIGEST', tone: 'gray',
        label: App.L('Simulated prototype digest', 'بصمة نموذج محاكاة'),
        detail: App.L('Simulated prototype digest — not a production file-integrity control.',
                      'بصمة نموذج محاكاة — ليست ضابط سلامة ملفات إنتاجيًا.'),
        verified: false, simulated: true
      };
    }
    if (method === 'SHA-256' && HEX64.test(h) && e.hashSource !== 'DECLARED') {
      return {
        code: 'VERIFIED_BROWSER_SHA256', tone: 'good',
        label: App.L('Browser-computed SHA-256', 'SHA-256 محسوبة في المتصفح'),
        detail: App.L('Computed from the selected file bytes with the Web Crypto API.',
                      'محسوبة من محتوى الملف المختار عبر Web Crypto API.'),
        verified: true, simulated: false
      };
    }
    return {
      code: 'HASH_INVALID', tone: 'bad',
      label: App.L('Invalid or incomplete digest', 'بصمة غير صالحة أو ناقصة'),
      detail: App.L('The digest does not match its declared method and cannot be relied on.',
                    'البصمة لا تطابق الطريقة المعلنة ولا يمكن الاعتماد عليها.'),
      verified: false, simulated: false
    };
  };

  /* the short chip every screen renders — identical markup everywhere */
  E.hashChip = function (evidence, opts) {
    opts = opts || {};
    var c = E.classifyEvidenceHash(evidence);
    var h = String((evidence || {}).hash || '');
    var shown = opts.full ? h : (h.length > 24 ? h.slice(0, 22) + '…' : h || '—');
    var chip = c.code === 'SIMULATED_PROTOTYPE_DIGEST'
      ? '<span class="sim-tag" title="' + App.esc(c.detail) + '">' + App.esc(c.label) + '</span>'
      : '<span class="pill ' + c.tone + '" title="' + App.esc(c.detail) + '">' + App.esc(c.label) + '</span>';
    return '<span class="mono" style="font-size:11px">' + App.esc(shown) + '</span> ' + chip;
  };

  /* counts for the contextual notice — no global "everything is simulated" claim */
  E.hashSummary = function () {
    var out = { total: 0, VERIFIED_BROWSER_SHA256: 0, SIMULATED_PROTOTYPE_DIGEST: 0, HASH_PENDING: 0, HASH_INVALID: 0 };
    App.State.evidence.forEach(function (e) { out.total++; out[E.classifyEvidenceHash(e).code]++; });
    return out;
  };

})(window.App)