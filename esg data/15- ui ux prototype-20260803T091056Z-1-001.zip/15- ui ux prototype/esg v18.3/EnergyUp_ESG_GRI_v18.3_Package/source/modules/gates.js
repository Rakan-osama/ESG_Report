/* CR-10 · modules/gates.js
   Fifteen publication gates, each with its own evaluator over real objects. A
   gate never reads screen completion, screen counts or the number of GRI
   requirements passed. There is no action anywhere in this build that sets a
   gate to PASS.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  var EV = {
    'PG-01': function () {
      var d = App.Data.demo;
      var ok = !!d.organization.id && d.legalEntities.length > 0 && d.sites.length > 0;
      return res(ok, ok ? [] : [f('Organization, legal entities and sites must all be configured.', 'يجب إعداد المنظمة والكيانات القانونية والمواقع.')],
        [{ en: 'Complete the organization profile and site register.', ar: 'أكمل ملف المنظمة وسجل المواقع.' }]);
    },
    'PG-02': function () {
      var b = App.Data.demo.boundaries, fails = [];
      if (!b.entities.approved) fails.push(f('The reporting entities boundary is not approved.', 'حدود كيانات التقرير غير معتمدة.'));
      if (!b.impact.approved) fails.push(f('The impact and value-chain boundary is not approved.', 'حدود التأثير وسلسلة القيمة غير معتمدة.'));
      if (!b.ghg.approved) fails.push(f('The GHG organizational boundary is not approved.', 'الحدود التنظيمية للانبعاثات غير معتمدة.'));
      if (b.entities.excludedSites.length && !App.Data.demo.sites.filter(function (s) { return b.entities.excludedSites.indexOf(s.id) > -1; }).every(function (s) { return !!s.exclusionRationale; }))
        fails.push(f('Every excluded site requires a recorded rationale.', 'كل موقع مستبعد يتطلب مبررًا مسجلًا.'));
      return res(fails.length === 0, fails, [{ en: 'Approve all three boundaries and record every exclusion rationale.', ar: 'اعتمد الحدود الثلاث وسجّل مبرر كل استبعاد.' }]);
    },
    'PG-03': function () {
      var c = App.Data.demo.cycle, fails = [];
      var g1 = App.GRI.applicableVersion('GRI 1', c.publicationTarget);
      if (!g1) fails.push(f('No applicable GRI 1 version resolves for the publication date.', 'لا يوجد إصدار منطبق من GRI 1 لتاريخ النشر.'));
      var future = App.GRI.transitionNotes().filter(function (t) { return !t.active; });
      return res(fails.length === 0, fails,
        future.length ? [{ en: future.length + ' standard(s) become effective after this publication date; the early-adoption decision must be recorded.', ar: future.length + ' معيارًا يسري بعد تاريخ النشر؛ يجب تسجيل قرار الاعتماد المبكر.' }] : []);
    },
    'PG-04': function () {
      var fails = [];
      if (!App.Materiality.isApproved()) fails.push(f('The material topic list has not been approved by governance.', 'قائمة الموضوعات الجوهرية لم تُعتمد من الحوكمة.'));
      var unassessed = App.State.impacts.filter(function (i) { return !i.scale || !i.scope; }).length;
      if (unassessed) fails.push(f(unassessed + ' impacts are not assessed.', unassessed + ' تأثيرًا غير مُقيَّم.'));
      return res(fails.length === 0, fails, [{ en: 'Assess every impact, then obtain governance approval of the topic list.', ar: 'قيّم كل تأثير ثم احصل على اعتماد الحوكمة لقائمة الموضوعات.' }]);
    },
    'PG-05': function () {
      var s = App.Records.stats(), fails = [];
      if (s.completeness < 95) fails.push(f('Data completeness is ' + s.completeness + '%; 95% is required.', 'اكتمال البيانات ' + s.completeness + '٪ والمطلوب 95٪.'));
      if (s.draft) fails.push(f(s.draft + ' records remain in draft.', s.draft + ' سجلًا ما زال مسودة.'));
      if (s.returned) fails.push(f(s.returned + ' records are returned for correction.', s.returned + ' سجلًا معادًا للتصحيح.'));
      return res(fails.length === 0, fails, [{ en: 'Submit or close every open record.', ar: 'أرسل أو أغلق كل سجل مفتوح.' }]);
    },
    'PG-06': function () {
      var s = App.Records.stats(), fails = [];
      if (s.evidenceCoverage < 90) fails.push(f('Evidence coverage is ' + s.evidenceCoverage + '%; 90% is required.', 'تغطية الأدلة ' + s.evidenceCoverage + '٪ والمطلوب 90٪.'));
      var superseded = App.State.records.filter(function (r) {
        return (r.evidenceIds || []).some(function (id) { var e = App.Evidence.byId(id); return e && e.status === 'SUPERSEDED'; });
      }).length;
      if (superseded) fails.push(f(superseded + ' records still link a superseded evidence object.', superseded + ' سجلًا ما زال مرتبطًا بدليل مُستبدل.'));
      return res(fails.length === 0, fails, [{ en: 'Attach the missing evidence and replace superseded links.', ar: 'أرفق الأدلة الناقصة واستبدل الروابط المستبدلة.' }]);
    },
    'PG-07': function () {
      var fails = [], unapproved = App.Data.factorSets.filter(function (x) { return x.approval !== 'APPROVED'; });
      if (unapproved.length) fails.push(f(unapproved.length + ' factor sets are not approved (' + unapproved.map(function (x) { return x.factorId; }).join(', ') + ').', unapproved.length + ' مجموعة عوامل غير معتمدة.'));
      var st = App.Calculations.selfTest(), bad = st.filter(function (t) { return !t.pass; });
      if (bad.length) fails.push(f(bad.length + ' calculation methods fail their worked example.', bad.length + ' طريقة حساب لا تطابق المثال المحسوب.'));
      return res(fails.length === 0, fails, [{ en: 'Obtain methodology-owner sign-off on every emission factor before a client cycle.', ar: 'احصل على اعتماد مالك المنهجية لكل عامل انبعاث قبل أي دورة عميل.' }]);
    },
    'PG-08': function () {
      var open = App.State.records.filter(function (r) { return !r.frozen && !App.Records.validate(r, 'submit').pass; });
      return res(open.length === 0, open.length ? [f(open.length + ' records carry open blocking validations.', open.length + ' سجلًا لديه قواعد تحقق حاجبة مفتوحة.')] : [],
        [{ en: 'Clear every blocker in the validation console.', ar: 'عالج كل قاعدة حاجبة في وحدة التحقق.' }]);
    },
    'PG-09': function () {
      var openF = App.State.findings.filter(function (x) { return x.status === 'OPEN' && x.source === 'Technical review'; });
      var s = App.Records.stats();
      var fails = [];
      if (openF.length) fails.push(f(openF.length + ' technical review findings are open.', openF.length + ' ملاحظة مراجعة فنية مفتوحة.'));
      if (s.submitted || s.review) fails.push(f((s.submitted + s.review) + ' records have not completed review.', (s.submitted + s.review) + ' سجلًا لم يكمل المراجعة.'));
      return res(fails.length === 0, fails, [{ en: 'Close every technical finding and approve the remaining records.', ar: 'أغلق كل ملاحظة فنية واعتمد السجلات المتبقية.' }]);
    },
    'PG-10': function () {
      var g = App.State.gri2 || [], gap = g.filter(function (d) { return d.status !== 'COMPLETE'; });
      var covered = gap.filter(function (d) { return App.State.omissions.some(function (o) { return o.disclosure === d.code && o.status === 'APPROVED'; }); });
      var open = gap.length - covered.length;
      return res(open === 0, open ? [f(open + ' GRI 2 disclosures are neither complete nor validly omitted.', open + ' إفصاحًا من GRI 2 غير مكتمل وغير محذوف بصورة صحيحة.')] : [],
        [{ en: 'Complete the disclosure or raise a permitted omission with its explanation.', ar: 'أكمل الإفصاح أو قدّم حذفًا مسموحًا مع تفسيره.' }]);
    },
    'PG-11': function () {
      var mt = App.Materiality.approved();
      if (!mt.length) return res(false, [f('No approved material topics; topic disclosures cannot be assessed.', 'لا توجد موضوعات جوهرية معتمدة.')], []);
      var missing = mt.filter(function (t) {
        return App.GRI.topicDisclosures(t.topic).some(function (code) {
          return !App.Records.approved().some(function (r) {
            var a = App.Records.activity(r.activityId); return a && String(a.gri_mapping || '').indexOf(code) > -1;
          });
        });
      });
      return res(missing.length === 0, missing.length ? [f(missing.length + ' material topics have unreported Topic Standard disclosures (' + missing.map(function (t) { return t.topic; }).join(', ') + ').', missing.length + ' موضوعًا لديه إفصاحات معايير موضوعات غير مبلَّغة.')] : [],
        [{ en: 'Collect the missing datapoints or record a permitted omission per disclosure.', ar: 'اجمع نقاط البيانات الناقصة أو سجّل حذفًا مسموحًا لكل إفصاح.' }]);
    },
    'PG-12': function () {
      /* CR-10.1.1 · P0-02 — a failing gate that says only "invalid" is not an
         actionable control. Each omission is classified by its own defect and
         carries its own remediation, affected objects and responsible role. */
      var fails = [], remedies = [], affected = [], seen = {};
      function add(code, en, ar, remEn, remAr, role, o) {
        var key = code + '|' + o.id;
        if (seen[key]) return; seen[key] = 1;
        fails.push({ code: code, en: en, ar: ar, omissionId: o.id, disclosure: o.disclosure, reason: o.reason });
        affected.push({ omissionId: o.id, disclosure: o.disclosure, reason: o.reason, defect: code });
        var rk = code + '|' + role;
        if (!seen['R' + rk]) { seen['R' + rk] = 1; remedies.push({ code: code, en: remEn, ar: remAr, responsibleRole: role }); }
      }

      App.State.omissions.forEach(function (o) {
        var d = o.disclosure, det = o.detail || {};

        /* a. an omission on a disclosure that may never carry one */
        if (App.Data.omissionBlocked.indexOf(d) > -1) {
          add('OMISSION_ON_PROHIBITED_DISCLOSURE',
            'GRI ' + d + ' may never carry a reason for omission, yet omission ' + o.id + ' exists against it.',
            'لا يجوز وضع سبب حذف للإفصاح ' + d + '، ومع ذلك يوجد الحذف ' + o.id + ' مقابله.',
            'Remove omission ' + o.id + ' and complete GRI ' + d + ' in full, because reasons for omission are not permitted for this disclosure.',
            'احذف ' + o.id + ' وأكمل الإفصاح ' + d + ' بالكامل، لأن أسباب الحذف غير مسموحة له.',
            'ESG_TECH_REVIEWER', o);
          return;
        }

        /* b. the mandatory explanation is missing */
        if (!o.explanation || !String(o.explanation).trim()) {
          add('OMISSION_EXPLANATION_MISSING',
            'Omission ' + o.id + ' on GRI ' + d + ' carries no explanation.',
            'الحذف ' + o.id + ' للإفصاح ' + d + ' بلا تفسير.',
            'Complete the mandatory explanation required for the selected reason for omission on GRI ' + d + '.',
            'أكمل التفسير الإلزامي المطلوب لسبب الحذف المختار للإفصاح ' + d + '.',
            'DATA_OWNER', o);
        }

        /* c. the reason-specific fields GRI 1 requires */
        var required = App.GRI.omissionFields(o.reason).filter(function (fd) { return fd.required && !det[fd.key]; });
        if (required.length) {
          var names = required.map(function (fd) { return fd.en; }).join(', ');
          var namesAr = required.map(function (fd) { return fd.ar; }).join('، ');
          var byReason = {
            UNAVAILABLE: {
              en: 'Specify the missing information, the affected entities or sites, the cause of unavailability, the corrective steps and the expected completion date for GRI ' + d + '.',
              ar: 'حدّد المعلومة الناقصة والكيانات أو المواقع المتأثرة وسبب عدم التوفر والخطوات التصحيحية وتاريخ الإنجاز المتوقع للإفصاح ' + d + '.',
              role: 'DATA_OWNER'
            },
            LEGAL: {
              en: 'Identify the exact legal prohibition preventing disclosure of GRI ' + d + ', and attach the supporting evidence.',
              ar: 'حدّد النص القانوني المانع بدقة للإفصاح ' + d + ' وأرفق الدليل المؤيد.',
              role: 'ESG_PROGRAMME_MANAGER'
            },
            CONFIDENTIALITY: {
              en: 'Describe the specific confidentiality constraint over GRI ' + d + ' and the basis on which it was approved.',
              ar: 'صف قيد السرية تحديدًا على الإفصاح ' + d + ' والأساس الذي اعتُمد عليه.',
              role: 'ESG_PROGRAMME_MANAGER'
            },
            NOT_APPLICABLE: {
              en: 'Explain why GRI ' + d + ' is not applicable to the organization. A policy or process that does not exist must be disclosed as absent, not declared not applicable.',
              ar: 'اشرح سبب عدم انطباق الإفصاح ' + d + '. والسياسة أو العملية غير الموجودة يجب الإفصاح عن غيابها لا اعتبارها غير منطبقة.',
              role: 'ESG_TECH_REVIEWER'
            }
          }[o.reason] || { en: 'Provide the fields this reason requires: ' + names + '.', ar: 'قدّم الحقول التي يتطلبها هذا السبب: ' + namesAr + '.', role: 'DATA_OWNER' };

          add('OMISSION_DETAIL_INCOMPLETE',
            'Omission ' + o.id + ' on GRI ' + d + ' (' + o.reason + ') is missing: ' + names + '.',
            'الحذف ' + o.id + ' للإفصاح ' + d + ' ينقصه: ' + namesAr + '.',
            byReason.en, byReason.ar, byReason.role, o);
        }

        /* d. an unapproved omission */
        if (o.status !== 'APPROVED') {
          add('OMISSION_NOT_APPROVED',
            'Omission ' + o.id + ' on GRI ' + d + ' is ' + o.status + ' and has not been approved.',
            'الحذف ' + o.id + ' للإفصاح ' + d + ' في حالة ' + o.status + ' ولم يُعتمد.',
            'Submit omission ' + o.id + ' for authorized review and approval before publication.',
            'قدّم الحذف ' + o.id + ' للمراجعة والاعتماد المصرّح بهما قبل النشر.',
            'ESG_TECH_REVIEWER', o);
        }

        /* e. an unpermitted reason code */
        if (!App.Data.omissionReasons.some(function (r) { return r.code === o.reason; })) {
          add('OMISSION_REASON_NOT_PERMITTED',
            'Omission ' + o.id + ' uses reason "' + o.reason + '", which is outside the four permitted reasons.',
            'الحذف ' + o.id + ' يستخدم السبب "' + o.reason + '" وهو خارج الأسباب الأربعة المسموحة.',
            'Replace the reason on ' + o.id + ' with one of: not applicable, legal prohibitions, confidentiality constraints, information unavailable or incomplete.',
            'استبدل سبب ' + o.id + ' بأحد الأسباب الأربعة المسموحة.',
            'ESG_TECH_REVIEWER', o);
        }
      });

      var pass = fails.length === 0;
      var out = res(pass, fails.map(function (x) { return { en: x.en, ar: x.ar, code: x.code, omissionId: x.omissionId, disclosure: x.disclosure }; }), remedies);
      out.affectedObjects = affected;
      out.affectedOmissionIds = affected.map(function (x) { return x.omissionId; });
      out.affectedDisclosures = affected.map(function (x) { return x.disclosure; }).filter(function (v, i, a) { return a.indexOf(v) === i; });
      out.responsibleRole = remedies.length ? remedies[0].responsibleRole : null;
      out.responsibleRoles = remedies.map(function (r) { return r.responsibleRole; }).filter(function (v, i, a) { return a.indexOf(v) === i; });
      out.reEvaluationCondition = 'Re-evaluated automatically whenever an omission is created, amended, approved or removed.';
      return out;
    },
    'PG-13': function () {
      var ci = App.GRI.contentIndex();
      return res(ci.complete, ci.complete ? [] : [f(ci.missingLocation + ' content index rows have no report location or source record.', ci.missingLocation + ' صفًا في الفهرس بلا موقع أو سجل مصدر.')],
        [{ en: 'Bind every index row to an approved record or a permitted omission.', ar: 'اربط كل صف بفهرس بسجل معتمد أو حذف مسموح.' }]);
    },
    'PG-14': function () {
      var a = App.State.notes.reportApproval;
      return res(!!a, a ? [] : [f('The report has not received governance approval.', 'التقرير لم يحصل على اعتماد الحوكمة.')],
        [{ en: 'Route the locked report to the governance approver.', ar: 'أرسل التقرير المقفول إلى معتمد الحوكمة.' }]);
    },
    'PG-15': function () {
      var claim = App.State.claim, fails = [];
      if (!claim || claim.result === 'NOT_ELIGIBLE' || claim.result === 'BLOCKED') fails.push(f('The computed claim is not eligible for publication.', 'الادعاء المحسوب غير مؤهل للنشر.'));
      /* Evaluate the other gates directly. Going through results() would
         re-enter PG-15 and recurse without terminating. */
      var others = App.Data.gates
        .filter(function (g) { return g.id !== 'PG-15'; })
        .map(function (g) { return App.Gates.evaluate(g.id); })
        .filter(function (g) { return g && !g.pass; });
      if (others.length) fails.push(f(others.length + ' earlier gates have not passed (' + others.map(function (g) { return g.id; }).join(', ') + ').', others.length + ' بوابة سابقة لم تُجتَز.'));
      var openA = App.State.findings.filter(function (x) { return x.status === 'OPEN' && x.source === 'Assurance'; });
      if (openA.length) fails.push(f(openA.length + ' assurance findings are open.', openA.length + ' ملاحظة تأكيد مفتوحة.'));
      return res(fails.length === 0, fails, [{ en: 'Close every earlier gate, resolve assurance findings, then re-evaluate.', ar: 'أغلق كل بوابة سابقة وعالج ملاحظات التأكيد ثم أعد التقييم.' }]);
    }
  };

  function f(en, ar) { return { en: en, ar: ar }; }
  function res(pass, failures, remediation) { return { pass: pass, failures: failures || [], remediation: remediation || [] }; }

  var Gates = App.Gates = {
    definition: function (id) { return App.Data.gates.filter(function (g) { return g.id === id; })[0]; },

    evaluate: function (id) {
      var def = Gates.definition(id); if (!def) return null;
      var r = EV[id] ? EV[id]() : res(false, [f('No evaluator registered.', 'لا يوجد مُقيِّم مسجل.')], []);
      var out = {
        id: id, name: def.name, nameAr: def.ar, blocking: def.blocking, inputs: def.inputs,
        requires: def.requires, pass: r.pass, failures: r.failures, remediation: r.remediation,
        evaluatedAt: App.now(), evaluatedVersion: 'CYC-2025.v' + (App.State.records.length),
        passedDate: r.pass ? App.now() : null,
        /* CR-10.1.1 — a failing gate always names what it affects and who acts */
        affectedObjects: r.affectedObjects || [],
        affectedOmissionIds: r.affectedOmissionIds || [],
        affectedDisclosures: r.affectedDisclosures || [],
        responsibleRole: r.responsibleRole || (def.requires && def.requires.approvals && def.requires.approvals[0]) || 'ESG_PROGRAMME_MANAGER',
        responsibleRoles: r.responsibleRoles || null,
        reEvaluationCondition: r.reEvaluationCondition || 'Re-evaluated on every state change affecting its inputs.',
        evaluationVersion: 'GATE-ENGINE-1.1.1'
      };
      /* invariant: a failure must be actionable */
      if (!out.pass && out.failures.length && !out.remediation.length)
        out.remediation = [{ en: 'Resolve the stated failures for ' + id + '.', ar: 'عالج أسباب فشل ' + id + '.', responsibleRole: out.responsibleRole }];
      return out;
    },

    results: function () {
      if (Gates._cache && Gates._cacheAt === App.State.records.length + '|' + App.State.materialTopics.length + '|' + App.State.omissions.length + '|' + App.State.findings.filter(function (x) { return x.status === 'OPEN'; }).length)
        return Gates._cache;
      var out = App.Data.gates.map(function (g) { return Gates.evaluate(g.id); });
      Gates._cache = out;
      Gates._cacheAt = App.State.records.length + '|' + App.State.materialTopics.length + '|' + App.State.omissions.length + '|' + App.State.findings.filter(function (x) { return x.status === 'OPEN'; }).length;
      return out;
    },

    reEvaluate: function () {
      Gates._cache = null;
      if (!App.Permissions.guard('gate.evaluate', null)) return null;
      var out = Gates.results();
      App.State.gateResults = out;
      App.Audit.write({ action: 'gate.evaluate', objectType: 'publication-gate', objectId: 'ALL', metadata: { passed: out.filter(function (g) { return g.pass; }).length, of: out.length } });
      App.save();
      return out;
    },

    summary: function () {
      var r = Gates.results();
      return { passed: r.filter(function (g) { return g.pass; }).length, total: r.length, blockers: r.filter(function (g) { return !g.pass && g.blocking === 'HARD'; }).length };
    }
  };
})(window.App)