/* CR-10 · modules/gri.js
   The claim engine. The nine requirements of GRI 1: Foundation 2021 are modelled
   as compliance objects, each with its own evaluator. The claim is the output of
   those evaluators — it is never derived from screen completion and no user,
   API call or import may write it.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  var G = App.GRI = {

    /* ---------- standards resolution by publication date, not period year ---------- */
    applicableVersion: function (code, publicationDate, earlyAdopt) {
      var cands = App.Data.standards.filter(function (s) { return s.code === code; });
      if (!cands.length) return null;
      var d = publicationDate || App.Data.demo.cycle.publicationTarget;
      var live = cands.filter(function (s) { return s.effectiveFrom <= d || (earlyAdopt && s.earlyAdoption); });
      return live.sort(function (a, b) { return b.effectiveFrom.localeCompare(a.effectiveFrom); })[0] || null;
    },
    transitionNotes: function () {
      var d = App.Data.demo.cycle.publicationTarget;
      return App.Data.standards.filter(function (s) { return s.status === 'FUTURE' || String(s.status).indexOf('UNTIL') > -1; })
        .map(function (s) {
          return {
            code: s.code, title: s.title, version: s.version, effectiveFrom: s.effectiveFrom, status: s.status,
            note: s.status === 'FUTURE'
              ? App.L(s.code + ':' + s.version + ' is effective from ' + s.effectiveFrom + '. Early adoption is permitted and must be declared.', s.code + ':' + s.version + ' يسري من ' + s.effectiveFrom + '. الاعتماد المبكر مسموح ويجب الإفصاح عنه.')
              : App.L(s.code + ':' + s.version + ' remains usable until ' + String(s.status).split('_').pop() + '; both versions must run in parallel until then.', s.code + ':' + s.version + ' يظل صالحًا حتى ' + String(s.status).split('_').pop() + '؛ يجب تشغيل الإصدارين بالتوازي حتى ذلك الحين.'),
            active: s.effectiveFrom <= d
          };
        });
    },

    /* ---------- omissions ---------- */
    omissionAllowed: function (code) { return App.Data.omissionBlocked.indexOf(code) === -1; },

    requestOmission: function (code, reasonCode, explanation, detail) {
      detail = detail || {};
      if (!G.omissionAllowed(code))
        return { ok: false, code: 'OMISSION_BLOCKED', message: App.L('GRI ' + code + ' may never carry a reason for omission.', 'لا يجوز إطلاقًا وضع سبب حذف للإفصاح ' + code + '.') };
      var reason = App.Data.omissionReasons.filter(function (r) { return r.code === reasonCode; })[0];
      if (!reason) return { ok: false, code: 'REASON_NOT_PERMITTED', message: App.L('Only the four permitted reasons may be used.', 'يُسمح فقط بالأسباب الأربعة المصرح بها.') };
      if (reason.explanationRequired && !explanation)
        return { ok: false, code: 'EXPLANATION_REQUIRED', message: App.L('The required explanation is missing.', 'التفسير المطلوب غير موجود.') };

      /* CR-10.1: each permitted reason demands its own specific fields.
         A generic sentence is not a reason for omission. */
      var need = G.omissionFields(reasonCode).filter(function (f) { return f.required && !detail[f.key]; });
      if (need.length)
        return { ok: false, code: 'OMISSION_DETAIL_REQUIRED',
          message: App.L('This reason requires: ' + need.map(function (f) { return f.en; }).join(', ') + '.',
                         'هذا السبب يتطلب: ' + need.map(function (f) { return f.ar; }).join('، ') + '.'), fields: need };

      if (!App.Permissions.guard('omission.request', null)) return { ok: false, code: 'DENIED' };
      var o = {
        id: 'OMI-' + (App.State.omissions.length + 101), disclosure: code, reason: reasonCode,
        explanation: explanation, detail: detail, status: 'REQUESTED',
        requestedBy: App.State.user.id, requestedOn: App.now()
      };
      App.State.omissions.push(o);
      App.Audit.write({ action: 'omission.request', objectType: 'omission', objectId: o.id, newStatus: 'REQUESTED', metadata: { disclosure: code, reason: reasonCode } });
      App.save();
      return { ok: true, omission: o };
    },

    /* the specific fields GRI 1 requires for each permitted reason */
    omissionFields: function (reasonCode) {
      var F = {
        NOT_APPLICABLE: [
          { key: 'whyNotApplicable', en: 'why the disclosure is not applicable', ar: 'سبب عدم انطباق الإفصاح', required: true, type: 'text' }
        ],
        LEGAL: [
          { key: 'instrument', en: 'the specific legal prohibition', ar: 'النص القانوني المانع تحديدًا', required: true, type: 'text' }
        ],
        CONFIDENTIALITY: [
          { key: 'constraint', en: 'the specific confidentiality constraint', ar: 'قيد السرية تحديدًا', required: true, type: 'text' }
        ],
        UNAVAILABLE: [
          { key: 'missingInformation', en: 'the specific information that is missing', ar: 'المعلومة الناقصة تحديدًا', required: true, type: 'text' },
          { key: 'affectedScope', en: 'the affected entities, sites or geographies', ar: 'الكيانات أو المواقع أو المناطق المتأثرة', required: true, type: 'text' },
          { key: 'whyUnavailable', en: 'why the information is unavailable', ar: 'سبب عدم توفر المعلومة', required: true, type: 'text' },
          { key: 'steps', en: 'the steps being taken to obtain it', ar: 'الخطوات المتخذة للحصول عليها', required: true, type: 'text' },
          { key: 'expectedDate', en: 'the expected time frame', ar: 'الإطار الزمني المتوقع', required: true, type: 'date' }
        ]
      };
      return F[reasonCode] || [];
    },

    approveOmission: function (id) {
      if (!App.Permissions.guard('omission.approve', null)) return { ok: false, code: 'DENIED' };
      var o = App.State.omissions.filter(function (x) { return x.id === id; })[0];
      if (!o) return { ok: false, code: 'NOT_FOUND' };
      o.status = 'APPROVED'; o.approvedBy = App.State.user.id; o.approvedOn = App.now();
      App.Audit.write({ action: 'omission.approve', objectType: 'omission', objectId: id, previousStatus: 'REQUESTED', newStatus: 'APPROVED' });
      App.save();
      return { ok: true, omission: o };
    },

    /* ---------- the nine requirements ---------- */
    requirements: function () {
      var S = App.State, rs = App.Records.stats(), mt = App.Materiality.approved();
      var gri2 = S.gri2 || [];
      var reqs = [];

      function req(n, title, titleAr, evaluator) {
        var r = evaluator();
        reqs.push({ n: n, title: title, titleAr: titleAr, pass: r.pass, detail: r.detail, detailAr: r.detailAr, evidence: r.evidence || [] });
      }

      req(1, 'Apply the reporting principles', 'تطبيق مبادئ الإبلاغ', function () {
        /* CR-10.1: evaluated from the Reporting Principles Control Register.
           A principle passes only when every mandatory control passes; no
           principle passes by default and none is derived from a percentage. */
        var res = App.Principles.results();
        var passed = res.filter(function (x) { return x.pass; });
        var sum = App.Principles.summary();
        return {
          pass: passed.length === res.length,
          detail: passed.length + ' of ' + res.length + ' principles pass all mandatory controls (' + sum.controlsPassed + ' of ' + sum.controls + ' controls passed).',
          detailAr: 'اجتاز ' + passed.length + ' من ' + res.length + ' مبدأ كل ضوابطه الإلزامية (' + sum.controlsPassed + ' من ' + sum.controls + ' ضابطًا).',
          evidence: res.map(function (x) { return { principle: x.principle, satisfied: x.pass }; })
        };
      });

      req(2, 'Report all applicable GRI 2 disclosures', 'الإبلاغ عن كل إفصاحات GRI 2 المنطبقة', function () {
        var complete = gri2.filter(function (d) { return d.status === 'COMPLETE'; }).length;
        var omitted = S.omissions.filter(function (o) { return o.status === 'APPROVED' && String(o.disclosure).indexOf('2-') === 0; }).length;
        var invalid = S.omissions.filter(function (o) { return App.Data.omissionBlocked.indexOf(o.disclosure) > -1; }).length;
        return {
          pass: (complete + omitted) >= gri2.length && invalid === 0,
          detail: complete + ' of ' + gri2.length + ' GRI 2 disclosures complete; ' + omitted + ' validly omitted; ' + invalid + ' invalid omissions.',
          detailAr: complete + ' من ' + gri2.length + ' إفصاحًا مكتملًا؛ ' + omitted + ' حذفًا صحيحًا؛ ' + invalid + ' حذفًا غير صحيح.'
        };
      });

      req(3, 'Determine material topics using the impact-based process', 'تحديد الموضوعات الجوهرية بمنهج التأثيرات', function () {
        var assessed = S.impacts.filter(function (i) { return i.scale && i.scope; }).length;
        var sector = App.Materiality.sectorReconciliation();
        return {
          pass: App.Materiality.isApproved() && assessed === S.impacts.length,
          detail: assessed + ' of ' + S.impacts.length + ' impacts assessed; material topic list ' + (App.Materiality.isApproved() ? 'approved by governance' : 'NOT approved') + '; sector reconciliation ' + sector.status + '.',
          detailAr: assessed + ' من ' + S.impacts.length + ' تأثيرًا مُقيَّمًا؛ قائمة الموضوعات ' + (App.Materiality.isApproved() ? 'معتمدة من الحوكمة' : 'غير معتمدة') + '؛ مواءمة القطاع ' + sector.status + '.'
        };
      });

      req(4, 'Report the GRI 3-1, 3-2 and 3-3 disclosures', 'الإبلاغ عن الإفصاحات 3-1 و3-2 و3-3', function () {
        var withMgmt = mt.filter(function (t) { return t.management && t.management.policies && t.management.actions; }).length;
        return {
          pass: App.Materiality.isApproved() && withMgmt === mt.length && mt.length > 0,
          detail: '3-1 process documented; 3-2 list ' + (App.Materiality.isApproved() ? 'approved' : 'not approved') + '; 3-3 complete for ' + withMgmt + ' of ' + mt.length + ' topics.',
          detailAr: '3-1 موثق؛ 3-2 ' + (App.Materiality.isApproved() ? 'معتمدة' : 'غير معتمدة') + '؛ 3-3 مكتمل لـ ' + withMgmt + ' من ' + mt.length + ' موضوعًا.'
        };
      });

      req(5, 'Report Topic Standard disclosures for each material topic', 'الإبلاغ عن إفصاحات معايير الموضوعات', function () {
        var covered = mt.filter(function (t) { return G.topicDisclosures(t.topic).length > 0; }).length;
        return {
          pass: mt.length > 0 && covered === mt.length,
          detail: covered + ' of ' + mt.length + ' material topics carry mapped Topic Standard disclosures.',
          detailAr: covered + ' من ' + mt.length + ' موضوعًا لديه إفصاحات معايير موضوعات مرتبطة.'
        };
      });

      req(6, 'Apply reasons for omission correctly', 'التطبيق الصحيح لأسباب الحذف', function () {
        var bad = S.omissions.filter(function (o) { return App.Data.omissionBlocked.indexOf(o.disclosure) > -1 || !o.explanation; });
        return {
          pass: bad.length === 0,
          detail: S.omissions.length + ' omissions recorded; ' + bad.length + ' invalid. Seven disclosures are hard-blocked from omission.',
          detailAr: S.omissions.length + ' حذفًا مسجلًا؛ ' + bad.length + ' غير صحيح. سبعة إفصاحات محظور حذفها.'
        };
      });

      req(7, 'Publish a GRI content index', 'نشر فهرس محتوى GRI', function () {
        var ci = G.contentIndex();
        return { pass: ci.rows.length > 0 && ci.complete, detail: ci.rows.length + ' rows generated from source records; ' + ci.missingLocation + ' rows without a report location.', detailAr: ci.rows.length + ' صفًا مولدًا من السجلات؛ ' + ci.missingLocation + ' صفًا بلا موقع في التقرير.' };
      });

      req(8, 'Provide a statement of use', 'تقديم عبارة الاستخدام', function () {
        /* CR-10.1: deliberately deferred. The claim sequence generates the
           provisional statement first and then validates it, which is what
           breaks the v1.0 circular dependency. */
        return { pass: false, detail: 'Evaluated by the claim sequence after provisional eligibility is computed.', detailAr: 'يُقيَّم ضمن تسلسل الادعاء بعد احتساب الأهلية المبدئية.' };
      });

      req(9, 'Notify GRI', 'إخطار GRI', function () {
        var n = G.notification();
        return {
          pass: !!(n && n.status === 'RECORDED'),
          detail: n ? 'Notification recorded on ' + n.date + ' by ' + n.contactName + ' (' + n.contactEmail + ').'
            : 'No notification record. Required for both an in-accordance claim and a with-reference claim.',
          detailAr: n ? 'الإخطار مسجل بتاريخ ' + n.date + '.' : 'لا يوجد سجل إخطار، وهو مطلوب للادعاءين معًا.'
        };
      });

      return reqs;
    },

    /* ---------- the computed claim ----------
       CR-10.1 removes the circular dependency of v1.0, where requirement 8
       needed a valid statement of use and the statement needed an eligible
       claim. The sequence is now explicit:
         1 evaluate the substantive requirements (1-7)
         2 compute provisional eligibility
         3 generate a provisional statement of use from that eligibility
         4 validate the statement fields
         5 validate the notification record
         6 compute the final claim
         7 lock the statement                                                 */
    evaluateClaim: function () {
      var reqs = G.requirements();

      /* 1-2 · substantive requirements and provisional eligibility */
      var substantive = reqs.slice(0, 7);                       /* requirements 1-7 */
      var substantivePassed = substantive.filter(function (r) { return r.pass; }).length;
      var blockers = App.State.omissions.filter(function (o) { return App.Data.omissionBlocked.indexOf(o.disclosure) > -1; }).length;
      var indexOk = reqs[6].pass;                               /* requirement 7 — content index */

      var provisional = blockers ? 'BLOCKED'
        : substantivePassed === 7 ? 'IN_ACCORDANCE'
          : indexOk ? 'WITH_REFERENCE' : 'NOT_ELIGIBLE';

      /* 3-4 · provisional statement, then validate its fields */
      var statement = G.statementOfUse(provisional);
      reqs[7].pass = !!statement.valid;
      reqs[7].detail = statement.valid ? statement.text : statement.text;
      reqs[7].detailAr = statement.textAr;

      /* 5 · notification record */
      var n = G.notification();
      reqs[8].pass = !!(n && n.status === 'RECORDED');

      /* 6 · final claim.
         In accordance: all nine.
         With reference: content index + statement of use + notification, all three. */
      var passed = reqs.filter(function (r) { return r.pass; }).length;
      var result;
      if (blockers) result = 'BLOCKED';
      else if (passed === 9) result = 'IN_ACCORDANCE';
      else if (reqs[6].pass && reqs[7].pass && reqs[8].pass) result = 'WITH_REFERENCE';
      else result = 'NOT_ELIGIBLE';

      /* 7 · lock the statement to the final result */
      var finalStatement = G.statementOfUse(result);

      var claim = {
        result: result, provisional: provisional, passed: passed, of: 9,
        substantivePassed: substantivePassed, computedAt: App.now(),
        requirements: reqs, statement: finalStatement, notification: n,
        writable: false, evaluationVersion: 'CLAIM-ENGINE-1.1',
        withReference: { contentIndex: reqs[6].pass, statementOfUse: reqs[7].pass, notification: reqs[8].pass },
        label: result === 'IN_ACCORDANCE' ? App.t('claimInAcc') : result === 'WITH_REFERENCE' ? App.t('claimRef') : result === 'BLOCKED' ? App.t('claimBlocked') : App.t('claimNot')
      };
      App.State.claim = claim;
      if (!App.Audit.suspended())
        App.Audit.write({ action: 'claim.evaluate', objectType: 'reporting-claim', objectId: 'CLAIM-2025', newStatus: result, metadata: { passed: passed, provisional: provisional } });
      App.save();
      return claim;
    },

    /* the GRI notification record — a real object, not a flag */
    notification: function () { return App.State.notes.griNotification || null; },

    recordNotification: function (o) {
      o = o || {};
      if (!App.Permissions.guard('report.approve', null)) return { ok: false, code: 'DENIED' };
      var missing = ['legalName', 'contactName', 'contactEmail', 'date'].filter(function (k) { return !o[k]; });
      if (missing.length) return { ok: false, code: 'NOTIFICATION_INCOMPLETE',
        message: App.L('The notification record is missing: ' + missing.join(', ') + '.', 'سجل الإخطار ينقصه: ' + missing.join('، ') + '.') };
      App.State.notes.griNotification = {
        legalName: o.legalName, contactName: o.contactName, contactEmail: o.contactEmail,
        date: o.date, reportUrl: o.reportUrl || '', contentIndexUrl: o.contentIndexUrl || '',
        statementOfUse: (App.State.claim && App.State.claim.statement && App.State.claim.statement.text) || '',
        status: 'RECORDED', recordedBy: App.State.user.id, recordedAt: App.now()
      };
      App.Audit.write({ action: 'report.approve', objectType: 'gri-notification', objectId: 'NOTIF-2025', newStatus: 'RECORDED' });
      App.save();
      return { ok: true, notification: App.State.notes.griNotification };
    },

    /* any attempt to write the claim is refused, by design */
    setClaim: function () {
      App.Audit.write({ action: 'permission.denied', objectType: 'reporting-claim', objectId: 'CLAIM-2025', reason: 'CLAIM_MANUAL_SET_BLOCKED' });
      return { ok: false, code: 'CLAIM_MANUAL_SET_BLOCKED', message: App.L('The reporting claim is computed from the nine requirements and cannot be set.', 'ادعاء التقرير محسوب من المتطلبات التسعة ولا يمكن تعيينه.') };
    },

    statementOfUse: function (eligibility) {
      var c = App.Data.demo.cycle, o = App.Data.demo.organization;
      /* CR-10.1: the eligibility is passed in by the claim sequence. It is never
         read back from a claim that has not been computed yet. */
      var claim = eligibility || (App.State.claim && App.State.claim.provisional) || 'NOT_ELIGIBLE';
      var valid = claim === 'IN_ACCORDANCE' || claim === 'WITH_REFERENCE';
      var text = claim === 'IN_ACCORDANCE'
        ? o.name_en + ' has reported in accordance with the GRI Standards for the period ' + c.periodStart + ' to ' + c.periodEnd + '.'
        : claim === 'WITH_REFERENCE'
          ? o.name_en + ' has reported the information cited in this GRI content index for the period ' + c.periodStart + ' to ' + c.periodEnd + ' with reference to the GRI Standards.'
          : 'A statement of use cannot be issued: the substantive reporting requirements are not yet satisfied.';
      var textAr = claim === 'IN_ACCORDANCE'
        ? 'أعدّت ' + o.name_ar + ' تقريرها وفقًا لمعايير GRI للفترة من ' + c.periodStart + ' إلى ' + c.periodEnd + '.'
        : claim === 'WITH_REFERENCE'
          ? 'أفصحت ' + o.name_ar + ' عن المعلومات الواردة في فهرس محتوى GRI للفترة من ' + c.periodStart + ' إلى ' + c.periodEnd + ' بالرجوع إلى معايير GRI.'
          : 'لا يمكن إصدار عبارة الاستخدام: المتطلبات الموضوعية غير مستوفاة بعد.';
      return {
        valid: valid, eligibility: claim, text: text, textAr: textAr, gri1: c.gri1Version,
        fields: { legalName: o.name_en, periodStart: c.periodStart, periodEnd: c.periodEnd, gri1Version: c.gri1Version },
        locked: claim === 'IN_ACCORDANCE' || claim === 'WITH_REFERENCE'
      };
    },

    /* ---------- topic disclosure mapping (from the activity dictionary) ---------- */
    topicMap: {
      'Climate change': ['305-1', '305-2', '305-4', '305-5'],
      'Energy': ['302-1', '302-3', '302-4'],
      'Water': ['303-1', '303-3', '303-5'],
      'Water and effluents': ['303-1', '303-3', '303-5'],
      'Waste': ['306-1', '306-2', '306-3', '306-4', '306-5'],
      'Occupational health and safety': ['403-1', '403-2', '403-5', '403-9'],
      'Employment': ['401-1', '401-2', '401-3'],
      'Training and education': ['404-1', '404-2', '404-3'],
      'Diversity and equal opportunity': ['405-1', '405-2'],
      'Anti-corruption': ['205-1', '205-2', '205-3'],
      'Economic performance': ['201-1', '201-2'],
      'Supplier social assessment': ['414-1', '414-2'],
      'Local communities': ['413-1', '413-2'],
      'Air quality': ['305-7'],
      'Biodiversity': ['101-1', '101-2', '101-5'],
      'Human rights': ['406-1', '407-1', '408-1', '409-1']
    },
    topicDisclosures: function (topic) { return G.topicMap[topic] || []; },
    disclosureTitle: function (code) {
      var titles = {
        '302-1': 'Energy consumption within the organization', '302-3': 'Energy intensity', '302-4': 'Reduction of energy consumption',
        '303-1': 'Interactions with water as a shared resource', '303-3': 'Water withdrawal', '303-5': 'Water consumption',
        '305-1': 'Direct (Scope 1) GHG emissions', '305-2': 'Energy indirect (Scope 2) GHG emissions', '305-4': 'GHG emissions intensity',
        '305-5': 'Reduction of GHG emissions', '305-7': 'Nitrogen oxides, sulfur oxides and other significant air emissions',
        '306-1': 'Waste generation and significant waste-related impacts', '306-2': 'Management of significant waste-related impacts',
        '306-3': 'Waste generated', '306-4': 'Waste diverted from disposal', '306-5': 'Waste directed to disposal',
        '401-1': 'New employee hires and employee turnover', '401-2': 'Benefits provided to full-time employees', '401-3': 'Parental leave',
        '403-1': 'Occupational health and safety management system', '403-2': 'Hazard identification and risk assessment',
        '403-5': 'Worker training on occupational health and safety', '403-9': 'Work-related injuries',
        '404-1': 'Average hours of training per year per employee', '404-2': 'Programs for upgrading employee skills', '404-3': 'Percentage of employees receiving regular performance reviews',
        '405-1': 'Diversity of governance bodies and employees', '405-2': 'Ratio of basic salary and remuneration of women to men',
        '205-1': 'Operations assessed for risks related to corruption', '205-2': 'Communication and training about anti-corruption policies',
        '205-3': 'Confirmed incidents of corruption and actions taken',
        '201-1': 'Direct economic value generated and distributed', '201-2': 'Financial implications and other risks and opportunities due to climate change',
        '414-1': 'New suppliers screened using social criteria', '414-2': 'Negative social impacts in the supply chain',
        '413-1': 'Operations with local community engagement', '413-2': 'Operations with significant negative impacts on local communities',
        '101-1': 'Policies to halt and reverse biodiversity loss', '101-2': 'Management of biodiversity impacts', '101-5': 'Impacts on biodiversity',
        '406-1': 'Incidents of discrimination', '407-1': 'Operations at risk for freedom of association', '408-1': 'Operations at significant risk for child labor', '409-1': 'Operations at significant risk for forced labor'
      };
      return titles[code] || code;
    },

    /* ---------- content index generated from source records ----------
       CR-10.1: no hard-coded page numbers, no "data table" placeholder. A row
       carries a location only when a report section is bound to it, and the
       section is derived from the disclosure's own material topic.            */
    reportLocation: function (kind, key) {
      var map = App.State.notes.reportLocations || {};
      var hit = map[key];
      if (hit) return hit;
      var sections = {
        'gri2': { section: '2. General disclosures', anchor: '#general-disclosures' },
        'materiality': { section: '3. Material topics', anchor: '#materiality' }
      };
      if (kind === 'topic') return { section: '4. Performance — ' + key, anchor: '#topic-' + String(key).toLowerCase().replace(/[^a-z0-9]+/g, '-') };
      return sections[kind] || null;
    },

    contentIndex: function (opts) {
      opts = opts || {};
      var rows = [], S = App.State, missing = 0;
      var c = App.Data.demo.cycle;

      function omissionFor(code) {
        return S.omissions.filter(function (o) { return o.disclosure === code && o.status === 'APPROVED'; })[0] || null;
      }
      function row(o) {
        if (!o.location && !o.omission) missing++;
        rows.push(o);
      }

      /* GRI 2 */
      (S.gri2 || []).forEach(function (d) {
        var om = omissionFor(d.code);
        var loc = d.status === 'COMPLETE' ? G.reportLocation('gri2', 'gri2') : null;
        row({
          standard: 'GRI 2: General Disclosures 2021', standardVersion: '2021', code: d.code,
          title: d.title, titleAr: d.title_ar, sectorRef: '',
          location: loc ? loc.section : '', anchor: loc ? loc.anchor : '', page: '',
          omission: om ? om.reason : '', omissionExplanation: om ? om.explanation : '',
          omissionDetail: om ? om.detail : null,
          assurance: 'In scope — limited', evidence: d.evidence, owner: d.owner, status: d.status
        });
      });

      /* GRI 3-1 and 3-2 — status computed, never assumed */
      var mtApproved = App.Materiality.isApproved();
      var mLoc = G.reportLocation('materiality', 'materiality');
      var methodOk = !!(App.Materiality.model() && App.Materiality.model().approvedOn);
      row({
        standard: 'GRI 3: Material Topics 2021', standardVersion: '2021', code: '3-1',
        title: 'Process to determine material topics', titleAr: 'عملية تحديد الموضوعات الجوهرية',
        location: methodOk ? mLoc.section : '', anchor: mLoc.anchor, page: '',
        omission: '', assurance: 'In scope — limited',
        status: methodOk ? 'COMPLETE' : 'GAP', owner: 'ESG Programme Manager'
      });
      row({
        standard: 'GRI 3: Material Topics 2021', standardVersion: '2021', code: '3-2',
        title: 'List of material topics', titleAr: 'قائمة الموضوعات الجوهرية',
        location: mtApproved ? mLoc.section : '', anchor: mLoc.anchor, page: '',
        omission: '', assurance: 'In scope — limited',
        status: mtApproved ? 'COMPLETE' : 'GAP', owner: 'Governance Approver'
      });

      /* per material topic: 3-3 and the mapped Topic Standard disclosures */
      App.Materiality.approved().forEach(function (t) {
        var tLoc = G.reportLocation('topic', t.topic);
        var mgmt = t.management && t.management.policies;
        row({
          standard: 'GRI 3: Material Topics 2021', standardVersion: '2021', code: '3-3',
          title: 'Management of material topics — ' + t.topic, titleAr: 'إدارة الموضوعات الجوهرية — ' + t.topic,
          location: mgmt ? tLoc.section : '', anchor: tLoc.anchor, page: '',
          omission: '', assurance: 'In scope — limited',
          status: mgmt ? 'COMPLETE' : 'GAP', owner: 'Data Owner', topic: t.topic
        });
        G.topicDisclosures(t.topic).forEach(function (code) {
          var series = code.split('-')[0];
          var std = App.Data.standards.filter(function (s) { return s.code === 'GRI ' + series; })[0];
          var recs = App.Records.approved().filter(function (r) {
            var a = App.Records.activity(r.activityId);
            return a && String(a.gri_mapping || '').indexOf(code) > -1;
          });
          var om = omissionFor(code);
          row({
            standard: std ? 'GRI ' + series + ': ' + std.title + ' ' + std.version : 'GRI ' + series,
            standardVersion: std ? std.version : '', code: code, title: G.disclosureTitle(code), titleAr: '',
            sectorRef: '', location: recs.length ? tLoc.section : '', anchor: tLoc.anchor, page: '',
            omission: om ? om.reason : '', omissionExplanation: om ? om.explanation : '',
            omissionDetail: om ? om.detail : null,
            assurance: 'In scope — limited',
            evidence: recs.reduce(function (n, r) { return n + (r.evidenceIds || []).length; }, 0),
            owner: 'Data Owner', status: recs.length ? 'COMPLETE' : 'GAP',
            sourceRecords: recs.length, sourceRecordIds: recs.map(function (r) { return r.id; }), topic: t.topic
          });
        });
      });

      /* sector topics determined not material — generated, each with its rationale */
      var sectorNotMaterial = App.Materiality.sectorNotMaterial();

      return {
        title: 'GRI content index',
        statementOfUse: G.statementOfUse(opts.eligibility),
        gri1: c.gri1Version,
        sectorStandards: c.sectorStandards,
        materialTopics: App.Materiality.approved().map(function (t) { return t.topic; }),
        sectorNotMaterial: sectorNotMaterial,
        rows: rows,
        total: rows.length,
        missingLocation: missing,
        complete: missing === 0 && rows.length > 0
      };
    },

    /* paged access for the report preview — the index is never truncated silently */
    contentIndexPage: function (page, size) {
      var ci = G.contentIndex();
      size = size || 25; page = page || 1;
      var pages = Math.max(1, Math.ceil(ci.rows.length / size));
      page = Math.min(Math.max(1, page), pages);
      return { rows: ci.rows.slice((page - 1) * size, page * size), page: page, pages: pages, total: ci.rows.length, index: ci };
    }
  };
})(window.App)