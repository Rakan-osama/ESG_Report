/* CR-10.1.2 · modules/journey.js
   The answer to four questions the product was failing to answer:
     Where do I enter?   → J.current()
     What is finished?   → J.status(stepId)
     What is left?       → J.remaining()
     How do I move on?   → J.nextAction()

   Every status is computed from real engine state. Nothing is a stored flag,
   and a step whose capability is not built in this release says so plainly
   rather than showing a green tick.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  var DONE = 'DONE', ACTIVE = 'IN_PROGRESS', BLOCKED = 'BLOCKED',
      TODO = 'NOT_STARTED', SPEC = 'SPECIFIED_NOT_BUILT';

  function ok(v) { return v ? DONE : TODO; }

  /* ---------------------------------------------------------------- checks --
     Each entry answers: is this step's own gate satisfied, and where does the
     user go to work on it. A step with no `check` is declared SPECIFIED_NOT_BUILT
     — that is the honest state, not a gap to be hidden. */
  var CHECK = {
    /* ---- Phase B · organization, cycle and applicability ---- */
    'B-01': { go: { view: 'admin', tab: 'org' }, check: function () { var o = App.Data.demo.organization; return ok(!!(o && o.id && o.sector)); } },
    'B-02': { go: { view: 'admin', tab: 'org' }, check: function () { return ok(App.Data.demo.legalEntities.length > 0); } },
    'B-03': { go: { view: 'admin', tab: 'org' }, check: function () {
        var s = App.Data.demo.sites;
        return ok(s.length > 0 && s.every(function (x) { return x.inBoundary || x.exclusionRationale; })); } },
    'B-04': { go: { view: 'requests' }, check: function () { return ok(App.Data.registry.activities.length > 0); } },
    'B-05': { go: { view: 'admin', tab: 'org' }, check: function () { var c = App.Data.demo.cycle; return ok(!!(c && c.periodStart && c.periodEnd)); } },
    'B-06': { go: { view: 'admin', tab: 'org' }, check: function () { var c = App.Data.demo.cycle; return ok(!!(c && c.gri1Version)); } },
    'B-07': { go: { view: 'admin', tab: 'org' }, check: function () { return App.Gates.evaluate('PG-02').pass ? DONE : BLOCKED; } },
    'B-08': { go: { view: 'admin', tab: 'org' }, check: function () { return ok(!!App.Data.demo.organization.sector); } },
    'B-09': { go: { view: 'compliance', tab: 'standards' }, check: function () { return App.Gates.evaluate('PG-03').pass ? DONE : BLOCKED; } },
    'B-10': { go: { view: 'compliance', tab: 'gri2' }, check: function () {
        var g = App.State.gri2 || []; return ok(g.length > 0 && g.every(function (d) { return !!d.status; })); } },
    'B-11': { go: { view: 'compliance', tab: 'gri2' }, check: function () {
        var g = App.State.gri2 || [], done = g.filter(function (d) { return d.status === 'COMPLETE'; });
        return g.length === 0 ? TODO : done.length === g.length ? DONE : ACTIVE; } },
    'B-12': { go: { view: 'reviews', tab: 'findings' }, check: function () {
        var open = App.State.findings.filter(function (f) { return f.status === 'OPEN'; });
        return open.length ? ACTIVE : DONE; } },
    'B-13': { go: { view: 'compliance', tab: 'omissions' }, check: function () {
        return App.State.omissions.length ? ACTIVE : TODO; } },
    'B-14': { go: { view: 'home' }, check: function () {
        var g = ['PG-01', 'PG-02', 'PG-03'].map(function (x) { return App.Gates.evaluate(x); });
        return g.every(function (x) { return x.pass; }) ? DONE : BLOCKED; } },

    /* ---- Phase C · materiality ---- */
    'C-01': { go: { view: 'materiality', tab: 'model' }, check: function () {
        var m = App.Materiality.model(); return ok(!!(m && m.approvedOn && m.humanRightsOverride)); } },
    'C-02': { go: { view: 'materiality', tab: 'impacts' }, check: function () { return ok(App.State.impacts.length > 0); } },
    'C-03': { go: { view: 'materiality', tab: 'stakeholders' }, check: function () { return ok(App.Data.registry.stakeholders.length > 0); } },
    'C-04': { go: { view: 'materiality', tab: 'stakeholders' }, check: function () { return ok(App.Data.demo.engagements.length > 0); } },
    'C-05': { go: { view: 'materiality', tab: 'stakeholders' }, check: function () { return ok(App.Data.demo.engagements.length > 0); } },
    'C-06': { go: { view: 'materiality', tab: 'impacts' }, check: function () { return ok(App.State.impacts.length >= 15); } },
    'C-07': { go: { view: 'materiality', tab: 'impacts' }, check: function () {
        var i = App.State.impacts;
        return ok(i.length > 0 && i.every(function (x) { return x.scale && x.scope; })); } },
    'C-08': { go: { view: 'materiality', tab: 'matrix' }, check: function () { return DONE; } },
    'C-09': { go: { view: 'materiality', tab: 'topics' }, check: function () {
        return ok(App.Materiality.proposedTopics().length > 0); } },
    'C-10': { go: { view: 'materiality', tab: 'topics' }, check: function () {
        var r = App.Materiality.sectorReconciliation();
        return r.status === 'NOT_APPLICABLE' ? DONE : ACTIVE; } },
    'C-11': { go: { view: 'materiality', tab: 'matrix' }, check: function () {
        var r = App.Materiality.ranked(); return ok(r.negative.length > 0 && r.positive.length > 0); } },
    'C-12': { go: { view: 'materiality', tab: 'topics' }, check: function () {
        return App.Materiality.isApproved() ? DONE : BLOCKED; } },

    /* ---- Phase D · data and calculation ---- */
    'D-01': { go: { view: 'requests' }, check: function () { return ok(App.Data.registry.activities.length > 0); } },
    'D-02': { go: { view: 'mywork' }, check: function () {
        var w = App.Records.myWork(); return w.length ? ACTIVE : DONE; } },
    'D-03': { go: { view: 'collection' }, check: function () {
        var r = App.State.records.filter(function (x) { return !x.frozen; });
        var draft = r.filter(function (x) { return ['DRAFT', 'RETURNED'].indexOf(x.status) > -1; });
        return r.length === 0 ? TODO : draft.length ? ACTIVE : DONE; } },
    'D-04': { go: { view: 'collection' } },                      /* bulk import — not built */
    'D-05': { go: { view: 'evidence' }, check: function () {
        var s = App.Records.stats(); return s.evidenceCoverage >= 100 ? DONE : s.evidenceCoverage > 0 ? ACTIVE : TODO; } },
    'D-06': { go: { view: 'collection' }, check: function () {
        var s = App.Records.stats(); return s.validationPass >= 100 ? DONE : ACTIVE; } },
    'D-07': { go: { view: 'collection' }, check: function () {
        return App.State.calcRuns.length ? DONE : BLOCKED; } },
    'D-08': { go: { view: 'collection' }, check: function () {
        var r = App.State.calcRuns; return r.length === 0 ? TODO : r.every(function (x) { return x.trace && x.trace.length; }) ? DONE : ACTIVE; } },
    'D-09': { go: { view: 'admin', tab: 'methodology' }, check: function () {
        var f = App.Data.factorSets, appr = f.filter(function (x) { return x.approval === 'APPROVED'; });
        return appr.length === f.length ? DONE : BLOCKED; } },
    'D-10': { go: { view: 'admin', tab: 'quality' }, check: function () {
        var s = App.Records.stats(); return s.completeness >= 100 ? DONE : ACTIVE; } },
    'D-11': { go: { view: 'admin', tab: 'quality' } },           /* comparative analysis — not built */
    'D-12': { go: { view: 'admin', tab: 'audit' } },             /* restatement workflow — not built */

    /* ---- Phase E · review, compliance and content index ---- */
    'E-01': { go: { view: 'reviews', tab: 'queue' }, check: function () {
        var q = App.State.records.filter(function (r) { return r.status === 'SUBMITTED'; });
        return q.length ? ACTIVE : DONE; } },
    'E-02': { go: { view: 'reviews', tab: 'queue' }, check: function () {
        var q = App.State.records.filter(function (r) { return r.status === 'UNDER_REVIEW'; });
        return q.length ? ACTIVE : DONE; } },
    'E-03': { go: { view: 'collection' }, check: function () {
        var s = App.Records.stats(); return s.validationPass >= 100 ? DONE : ACTIVE; } },
    'E-04': { go: { view: 'reviews', tab: 'findings' }, check: function () {
        var open = App.State.findings.filter(function (f) { return f.status === 'OPEN'; });
        return open.length ? ACTIVE : DONE; } },
    'E-05': { go: { view: 'reviews', tab: 'findings' }, check: function () {
        var open = App.State.findings.filter(function (f) { return f.status === 'OPEN'; });
        return open.length ? BLOCKED : DONE; } },
    'E-06': { go: { view: 'compliance', tab: 'omissions' }, check: function () {
        return App.Gates.evaluate('PG-12').pass ? DONE : BLOCKED; } },
    'E-07': { go: { view: 'compliance', tab: 'claim' }, check: function () {
        var c = App.State.claim || App.GRI.evaluateClaim();
        return c.result === 'IN_ACCORDANCE' ? DONE : c.passed > 0 ? ACTIVE : BLOCKED; } },
    'E-08': { go: { view: 'compliance', tab: 'principles' }, check: function () {
        var s = App.Principles.summary(); return s.passed === s.total ? DONE : ACTIVE; } },
    'E-09': { go: { view: 'compliance', tab: 'index' }, check: function () {
        var ci = App.GRI.contentIndex(); return ci.complete ? DONE : ci.rows.length ? ACTIVE : TODO; } },
    'E-10': { go: { view: 'compliance', tab: 'index' }, check: function () {
        var ci = App.GRI.contentIndex(); return ci.rows.length ? DONE : TODO; } },
    'E-11': { go: { view: 'compliance', tab: 'claim' }, check: function () {
        var c = App.State.claim || App.GRI.evaluateClaim();
        if (c.statement && c.statement.valid) return DONE;
        return App.GRI.contentIndex().rows.length ? BLOCKED : TODO; } },
    'E-12': { go: { view: 'compliance', tab: 'notify' }, check: function () {
        return App.Gates.evaluate('PG-15').pass ? DONE : BLOCKED; } },

    /* ---- Phase F · report, digital tagging and assurance ---- */
    'F-01': { go: { view: 'reporting' }, check: function () { return ok(!!App.Data.demo.cycle); } },
    'F-02': { go: { view: 'reporting' }, check: function () { return App.Materiality.isApproved() ? DONE : BLOCKED; } },
    'F-03': { go: { view: 'reporting' } },                       /* narrative editor — not built */
    'F-04': { go: { view: 'reporting' } },                       /* tables and charts — not built */
    'F-05': { go: { view: 'reporting' }, check: function () {
        return App.State.calcRuns.length ? ACTIVE : BLOCKED; } },
    'F-06': { go: { view: 'admin', tab: 'parity' }, check: function () {
        return App.parity().pct >= 100 ? DONE : ACTIVE; } },
    'F-07': { go: { view: 'reporting' }, check: function () { return DONE; } },
    'F-08': { go: { view: 'reporting' } },                        /* export artefacts — backend */
    'F-09': { go: { view: 'admin', tab: 'buildspec' } },          /* taxonomy binding — not built */
    'F-10': { go: { view: 'admin', tab: 'buildspec' } },          /* XBRL contexts — not built */
    'F-11': { go: { view: 'admin', tab: 'buildspec' } },          /* XBRL validation — not built */
    'F-12': { go: { view: 'assurance' }, check: function () { return ok(App.State.findings.length > 0); } },
    'F-13': { go: { view: 'assurance' }, check: function () { return DONE; } },
    'F-14': { go: { view: 'assurance' }, check: function () {
        var open = App.State.findings.filter(function (f) { return f.status === 'OPEN' && f.source === 'Assurance'; });
        return open.length ? ACTIVE : DONE; } },
    'F-15': { go: { view: 'assurance' }, check: function () {
        return App.Gates.evaluate('PG-15').pass ? DONE : ACTIVE; } },
    'F-16': { go: { view: 'reporting' }, check: function () {
        return App.Gates.evaluate('PG-15').pass ? DONE : BLOCKED; } }
  };

  var J = App.Journey = {
    STATUS: { DONE: DONE, ACTIVE: ACTIVE, BLOCKED: BLOCKED, TODO: TODO, SPEC: SPEC },

    phases: function () { return App.Data.phases; },
    steps: function (phase) {
      return App.Data.journeySteps.filter(function (s) { return !phase || s.phase === phase; });
    },
    step: function (id) {
      return App.Data.journeySteps.filter(function (s) { return s.id === id; })[0] || null;
    },

    /* the honest status of one step */
    status: function (id) {
      var c = CHECK[id];
      if (!c || !c.check) return SPEC;
      try { return c.check(); } catch (e) { return TODO; }
    },

    target: function (id) { return (CHECK[id] || {}).go || { view: 'home' }; },

    /* every step, decorated with its status and destination */
    all: function () {
      return App.Data.journeySteps.map(function (s) {
        return Object.assign({}, s, { status: J.status(s.id), go: J.target(s.id) });
      });
    },

    /* progress of one phase, counting only steps this build can evaluate */
    phaseProgress: function (code) {
      var steps = J.all().filter(function (s) { return s.phase === code; });
      var evaluable = steps.filter(function (s) { return s.status !== SPEC; });
      var done = evaluable.filter(function (s) { return s.status === DONE; });
      var blocked = steps.filter(function (s) { return s.status === BLOCKED; });
      var active = steps.filter(function (s) { return s.status === ACTIVE; });
      return {
        code: code, total: steps.length, evaluable: evaluable.length,
        done: done.length, blocked: blocked.length, active: active.length,
        notBuilt: steps.length - evaluable.length,
        pct: evaluable.length ? Math.round(done.length / evaluable.length * 100) : 0,
        state: blocked.length ? BLOCKED : done.length === evaluable.length && evaluable.length ? DONE
             : (done.length || active.length) ? ACTIVE : TODO,
        steps: steps
      };
    },

    progress: function () { return App.Data.phases.map(function (p) { return J.phaseProgress(p.code); }); },

    /* the one step the user should be working on now: the first that is not
       finished and is not out of scope for this build */
    current: function () {
      var all = J.all();
      var blocked = all.filter(function (s) { return s.status === BLOCKED; })[0];
      if (blocked) return blocked;
      var active = all.filter(function (s) { return s.status === ACTIVE; })[0];
      if (active) return active;
      return all.filter(function (s) { return s.status === TODO; })[0] ||
             all.filter(function (s) { return s.status === SPEC; })[0] || all[0];
    },

    remaining: function () {
      return J.all().filter(function (s) { return s.status !== DONE && s.status !== SPEC; });
    },

    completed: function () {
      return J.all().filter(function (s) { return s.status === DONE; });
    },

    /* one sentence telling the user exactly what to do, and where */
    nextAction: function () {
      var s = J.current();
      var phase = App.Data.phases.filter(function (p) { return p.code === s.phase; })[0];
      var why = '';
      if (s.status === BLOCKED) {
        var gate = J.blockingGate(s.id);
        why = gate ? gate.failures.map(function (f) { return App.L(f.en, f.ar); }).join(' ') : App.L('The exit gate for this step is not satisfied.', 'بوابة الخروج لهذه الخطوة غير مستوفاة.');
      }
      return {
        step: s, phase: phase, status: s.status, go: s.go, why: why,
        label: App.L(s.title, s.title_ar),
        gate: s.gate,
        owner: s.role
      };
    },

    /* which publication gate, if any, is holding a step back */
    blockingGate: function (id) {
      /* each step is mapped to the gate that actually governs it, read from the
         gate register by name rather than by position */
      var map = {
        'B-07': 'PG-02',   /* reporting boundary          */
        'B-09': 'PG-03',   /* applicable standards        */
        'B-11': 'PG-10',   /* GRI 2 completion            */
        'B-14': 'PG-01',   /* organization configuration  */
        'C-12': 'PG-04',   /* materiality approval        */
        'D-05': 'PG-06',   /* evidence completeness       */
        'D-06': 'PG-08',   /* validation completion       */
        'D-07': 'PG-07',   /* calculation readiness       */
        'D-09': 'PG-07',   /* calculation readiness — factors */
        'D-10': 'PG-05',   /* data completeness           */
        'E-02': 'PG-09',   /* technical review            */
        'E-05': 'PG-09',   /* technical review findings   */
        'E-06': 'PG-12',   /* reasons for omission        */
        'E-07': 'PG-11',   /* topic disclosures           */
        'E-09': 'PG-13',   /* content index               */
        'E-11': 'PG-13',   /* statement rides on the index */
        'E-12': 'PG-15',   /* publication readiness       */
        'F-02': 'PG-04',   /* structure needs approved topics */
        'F-16': 'PG-15'    /* final release               */
      };
      return map[id] ? App.Gates.evaluate(map[id]) : null;
    },

    /* everything standing between the user and publication, in order */
    blockers: function () {
      return J.all().filter(function (s) { return s.status === BLOCKED; }).map(function (s) {
        var g = J.blockingGate(s.id);
        return {
          step: s.id, title: App.L(s.title, s.title_ar), phase: s.phase, owner: s.role,
          gate: g ? g.id : null,
          reasons: g ? g.failures.map(function (f) { return App.L(f.en, f.ar); }) : [App.L(s.gate, s.gate)],
          remediation: g ? g.remediation.map(function (r) { return App.L(r.en, r.ar); }) : [],
          go: s.go
        };
      });
    },

    summary: function () {
      var all = J.all();
      return {
        total: all.length,
        done: all.filter(function (s) { return s.status === DONE; }).length,
        active: all.filter(function (s) { return s.status === ACTIVE; }).length,
        blocked: all.filter(function (s) { return s.status === BLOCKED; }).length,
        todo: all.filter(function (s) { return s.status === TODO; }).length,
        notBuilt: all.filter(function (s) { return s.status === SPEC; }).length
      };
    }
  };
})(window.App)