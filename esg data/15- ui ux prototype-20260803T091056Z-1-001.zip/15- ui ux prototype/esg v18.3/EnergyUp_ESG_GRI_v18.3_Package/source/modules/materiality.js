/* CR-10 · modules/materiality.js
   Impact-based materiality. The unit of assessment is the impact, not the topic.
   Positive and negative impacts are never netted. Stakeholder scores are held in
   a separate field and are never read by the significance calculation. The
   scoring output is decision support: the material topic list only becomes real
   after ranking, sector reconciliation, review and governance approval.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  var M = App.Materiality = {

    model: function () { return App.Data.thresholdModels[0]; },

    /* significance is computed differently for each impact class */
    score: function (i) {
      var severity = (Number(i.scale) || 0) + (Number(i.scope) || 0) + (Number(i.irremediability) || 0);
      var likely = Number(i.likelihood) || 0;
      var neg = i.polarity === 'Negative';
      var actual = i.actuality === 'Actual';
      var out = { severity: severity, likelihood: likely, basis: '', significance: 0, override: false, class: '' };

      if (neg && actual) {
        out.class = 'ACTUAL_NEGATIVE';
        out.significance = severity;                       /* likelihood is irrelevant: it happened */
        out.basis = 'scale + scope + irremediability (likelihood not applied to an actual impact)';
      } else if (neg && !actual) {
        out.class = 'POTENTIAL_NEGATIVE';
        out.significance = severity * (likely / 5);
        out.basis = 'severity × likelihood';
        /* CR-10.1 · P0-15 — the override reads the approved threshold model.
           There is no second number anywhere in the product. */
        var hr = (M.model() || {}).humanRightsOverride || { enabled: true, severityFloor: 4 };
        if (i.humanRights && hr.enabled && severity >= hr.severityFloor) {
          out.significance = Math.max(out.significance, severity);
          out.override = true;
          out.overrideRule = 'severity >= ' + hr.severityFloor;
          out.basis = 'human-rights override (severity ≥ ' + hr.severityFloor + '): severity takes precedence over likelihood';
        }
      } else if (!neg && actual) {
        out.class = 'ACTUAL_POSITIVE';
        out.significance = (Number(i.scale) || 0) + (Number(i.scope) || 0);
        out.basis = 'scale + scope (irremediability does not apply to a positive impact)';
      } else {
        out.class = 'POTENTIAL_POSITIVE';
        out.significance = ((Number(i.scale) || 0) + (Number(i.scope) || 0)) * (likely / 5);
        out.basis = 'benefit × likelihood';
      }
      out.significance = Math.round(out.significance * 100) / 100;
      return out;
    },

    /* impacts are ranked in two separate lists — never netted into one number */
    ranked: function () {
      var m = M.model();
      var scored = App.State.impacts.map(function (i) {
        var s = M.score(i);
        return Object.assign({}, i, { _score: s, _material: s.significance >= (i.polarity === 'Negative' ? m.negativeThreshold : m.positiveThreshold) });
      });
      return {
        negative: scored.filter(function (x) { return x.polarity === 'Negative'; }).sort(function (a, b) { return b._score.significance - a._score.significance; }),
        positive: scored.filter(function (x) { return x.polarity !== 'Negative'; }).sort(function (a, b) { return b._score.significance - a._score.significance; }),
        all: scored
      };
    },

    /* proposed topics = decision support only */
    proposedTopics: function () {
      var r = M.ranked(), map = {};
      r.all.forEach(function (i) {
        if (!i._material) return;
        map[i.topic] = map[i.topic] || { topic: i.topic, category: i.category, impacts: [], maxSignificance: 0, humanRights: false, override: false };
        map[i.topic].impacts.push(i.id);
        map[i.topic].maxSignificance = Math.max(map[i.topic].maxSignificance, i._score.significance);
        if (i.humanRights) map[i.topic].humanRights = true;
        if (i._score.override) map[i.topic].override = true;
      });
      return Object.keys(map).map(function (k) { return map[k]; }).sort(function (a, b) { return b.maxSignificance - a.maxSignificance; });
    },

    excludedTopics: function () {
      var r = M.ranked(), inList = {};
      M.proposedTopics().forEach(function (t) { inList[t.topic] = true; });
      var map = {};
      r.all.forEach(function (i) {
        if (inList[i.topic]) return;
        map[i.topic] = map[i.topic] || { topic: i.topic, maxSignificance: 0, rationale: '' };
        map[i.topic].maxSignificance = Math.max(map[i.topic].maxSignificance, i._score.significance);
      });
      return Object.keys(map).map(function (k) {
        var t = map[k];
        t.rationale = App.L('Highest assessed significance ' + t.maxSignificance + ' sits below the approved threshold; retained on the watchlist.',
          'أعلى أهمية مُقيّمة ' + t.maxSignificance + ' أقل من العتبة المعتمدة؛ يبقى على قائمة المراقبة.');
        return t;
      });
    },

    /* governance approval — the only way a topic becomes material */
    approveTopics: function (topics, note) {
      if (!App.Permissions.guard('materiality.approve', null)) return { ok: false, code: 'DENIED' };
      var m = M.model();
      App.State.materialTopics = topics.map(function (t) {
        return {
          topic: t.topic, category: t.category, impacts: t.impacts, humanRights: t.humanRights,
          approvedBy: App.State.user.id, approvedOn: App.now(),
          thresholdModel: m.id + ' v' + m.version, status: 'APPROVED',
          management: { impacts: '', policies: '', actions: '', targets: '', effectiveness: '', engagement: '' }
        };
      });
      App.Audit.write({ action: 'materiality.approve', objectType: 'material-topic-list', objectId: 'MTL-2025', newStatus: 'APPROVED', reason: note || null, metadata: { count: topics.length, thresholdModel: m.id + ' v' + m.version } });
      App.save();
      return { ok: true, topics: App.State.materialTopics };
    },

    approved: function () { return App.State.materialTopics || []; },
    isApproved: function () { return (App.State.materialTopics || []).length > 0; },

    /* the sector reconciliation step — registered but unpopulated, declared openly */
    sectorReconciliation: function () {
      var c = App.Data.demo.cycle;
      return {
        applicable: c.sectorStandards.length ? c.sectorStandards : [],
        status: c.sectorStandards.length ? 'PENDING' : 'NOT_APPLICABLE',
        note: App.L('No GRI Sector Standard applies to industrial manufacturing at this date. GRI 11–14 topic sets are registered but not populated in this build (GAP-05).',
          'لا ينطبق أي معيار قطاعي من GRI على التصنيع الصناعي في هذا التاريخ. مجموعات موضوعات GRI 11–14 مسجلة لكنها غير مملوءة في هذا الإصدار (GAP-05).')
      };
    },

    /* sector topics determined not material — generated with a rationale each,
       never an empty array presented as "none apply" */
    sectorNotMaterial: function () {
      var c = App.Data.demo.cycle;
      if (!c.sectorStandards || !c.sectorStandards.length) return [];
      var approved = M.approved().map(function (t) { return t.topic; });
      var sectorTopics = App.Data.sectorTopics || {};
      var out = [];
      c.sectorStandards.forEach(function (code) {
        (sectorTopics[code] || []).forEach(function (st) {
          if (approved.indexOf(st.topic) > -1) return;
          out.push({
            standard: code, ref: st.ref, topic: st.topic,
            rationale: st.rationale || 'Assessed against the impact register for this cycle; no impact reached the approved threshold. Rationale required before publication.',
            status: st.rationale ? 'EXPLAINED' : 'RATIONALE_REQUIRED'
          });
        });
      });
      return out;
    },

    stakeholderInput: function () {
      /* held separately, presented as input, never summed into significance */
      return App.Data.demo.engagements;
    }
  };
})(window.App)