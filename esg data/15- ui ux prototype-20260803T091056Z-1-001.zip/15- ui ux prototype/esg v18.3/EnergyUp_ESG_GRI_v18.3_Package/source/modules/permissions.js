/* CR-10 · modules/permissions.js
   One decision function for the whole product. The UI asks this function what
   to render; every action handler asks it again before mutating state. Hiding a
   button is a convenience, never the control.

   canPerformAction({user, role, permission, objectType, object, cycle, tenant})
     → { allowed:boolean, code:string, reason:{en,ar} }
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  function deny(code, en, ar) { return { allowed: false, code: code, reason: { en: en, ar: ar } }; }
  function allow() { return { allowed: true, code: 'OK', reason: { en: '', ar: '' } }; }

  var P = App.Permissions = {

    hasPermission: function (role, permission) {
      var list = App.Data.permissions[permission];
      return !!(list && list.indexOf(role) > -1);
    },

    canPerformAction: function (ctx) {
      ctx = ctx || {};
      var role = ctx.role || App.State.role;
      var user = ctx.user || App.State.user;
      var perm = ctx.permission;
      var obj = ctx.object || null;
      var tenant = ctx.tenant || App.State.tenantNamespace || 'TEN-EEG';
      var cycle = ctx.cycle || (App.Data.demo.cycle);

      /* SOD-06 tenant isolation — refused before anything else */
      if (obj && obj.tenantId && obj.tenantId !== tenant)
        return deny('TENANT_ISOLATION', 'Cross-tenant access is refused.', 'الوصول عبر المستأجرين مرفوض.');

      /* organization / cycle scope */
      if (obj && obj.cycleId && cycle && obj.cycleId !== cycle.id)
        return deny('CYCLE_SCOPE', 'The object belongs to another reporting cycle.', 'الكائن يخص دورة تقرير أخرى.');

      /* SOD-05 viewer roles hold no write permission */
      if ((role === 'VIEWER' || role === 'EXECUTIVE_VIEWER') && perm !== 'view')
        return deny('READ_ONLY_ROLE', 'This role is read-only.', 'هذا الدور للاطلاع فقط.');

      /* SOD-04 assurance impartiality — evaluated before the grant lookup so the
         refusal states the impartiality control, not a missing permission */
      if (perm.indexOf('assurance.') === 0 && role === 'ASSURANCE_REVIEWER' && P.hasPreparationHistory(user.id))
        return deny('SOD-04', 'Assurance personnel may not have contributed to preparation in this engagement.', 'لا يجوز لفريق التأكيد أن يكون قد شارك في الإعداد لنفس المهمة.');
      if (perm.indexOf('record.') === 0 && role === 'ASSURANCE_REVIEWER')
        return deny('SOD-04', 'The assurance role never mutates client data.', 'دور التأكيد لا يعدّل بيانات العميل إطلاقًا.');

      /* role → permission grant */
      if (!P.hasPermission(role, perm))
        return deny('NO_GRANT', 'The role does not carry this permission.', 'الدور لا يحمل هذه الصلاحية.');

      /* SOD-07 the claim is computed */
      if (perm === 'claim.write')
        return deny('CLAIM_MANUAL_SET_BLOCKED', 'The reporting claim is computed and cannot be written.', 'ادعاء التقرير محسوب ولا يمكن كتابته.');

      /* object-status rules */
      if (obj && obj.status) {
        var st = obj.status;
        if (perm === 'record.edit' && ['SUBMITTED', 'UNDER_REVIEW', 'APPROVED'].indexOf(st) > -1)
          return deny('STATUS_LOCKED', 'A record in ' + st + ' cannot be edited. Return or reopen it first.', 'لا يمكن تعديل سجل في حالة ' + st + '؛ أعده أو أعد فتحه أولًا.');
        if (perm === 'record.submit' && ['VALIDATED', 'DRAFT', 'RETURNED'].indexOf(st) === -1)
          return deny('STATUS_INVALID', 'Only a draft, returned or validated record can be submitted.', 'يمكن إرسال المسودة أو المعاد أو المتحقق منه فقط.');
        if (perm === 'record.review' && st !== 'SUBMITTED')
          return deny('STATUS_INVALID', 'Only a submitted record can enter review.', 'المراجعة تبدأ من السجل المرسل فقط.');
        if (perm === 'record.approve' && st !== 'UNDER_REVIEW')
          return deny('STATUS_INVALID', 'Only a record under review can be approved.', 'يُعتمد السجل قيد المراجعة فقط.');
        if (perm === 'record.return' && ['SUBMITTED', 'UNDER_REVIEW'].indexOf(st) === -1)
          return deny('STATUS_INVALID', 'Only a submitted or in-review record can be returned.', 'يُعاد السجل المرسل أو قيد المراجعة فقط.');
        if (perm === 'record.reopen' && st !== 'APPROVED')
          return deny('STATUS_INVALID', 'Only an approved record can be reopened.', 'يُعاد فتح السجل المعتمد فقط.');
      }

      /* SOD-01 self-approval */
      if (perm === 'record.approve' && obj) {
        if (obj.createdBy && obj.createdBy === user.id)
          return deny('SOD-01', 'A contributor may not approve a record they created.', 'لا يجوز اعتماد سجل أنشأه نفس المستخدم.');
        if (obj.lastEditedBy && obj.lastEditedBy === user.id)
          return deny('SOD-01', 'The last editor of a record may not approve it.', 'لا يجوز لآخر من عدّل السجل أن يعتمده.');
      }

      /* SOD-02 reviewer independence */
      if ((perm === 'record.approve' || perm === 'record.review') && obj && obj.editedByReviewer)
        return deny('SOD-02', 'Reviewer independence is lost on this record; reassign the review.', 'استقلالية المراجع مفقودة لهذا السجل؛ أعد إسناد المراجعة.');

      /* SOD-03 governance independence */
      if (perm === 'report.approve' && obj && obj.preparedBy === user.id)
        return deny('SOD-03', 'The preparer of the report may not give governance approval.', 'مُعِدّ التقرير لا يمنح اعتماد الحوكمة.');

      /* period lock */
      if (cycle && cycle.status === 'LOCKED' && ['record.edit', 'record.submit', 'record.approve'].indexOf(perm) > -1)
        return deny('PERIOD_LOCKED', 'The period is locked. Raise a restatement instead.', 'الفترة مقفلة. استخدم إعادة عرض بدلًا من التعديل.');

      return allow();
    },

    /* prototype stand-in for the engagement history check (SOD-04) */
    hasPreparationHistory: function (userId) {
      return App.State.audit.some(function (e) {
        return e.user === userId && ['create', 'edit', 'submit'].indexOf(e.action) > -1;
      });
    },

    /* helper used by every action handler */
    guard: function (permission, object, opts) {
      var r = P.canPerformAction(Object.assign({ permission: permission, object: object }, opts || {}));
      if (!r.allowed) {
        App.Audit.write({
          action: 'permission.denied', objectType: object ? (object.activityId ? 'record' : 'object') : null,
          objectId: object ? object.id : null, reason: r.code,
          metadata: { permission: permission, role: App.State.role }
        });
        App.toast(App.L(r.reason.en, r.reason.ar), 'bad');
      }
      return r.allowed;
    },

    /* read-model for the permission matrix screen */
    matrix: function () {
      var perms = Object.keys(App.Data.permissions);
      return App.Data.roles.map(function (r) {
        var row = { role: r.code, label: r.en, cells: {} };
        perms.forEach(function (p) { row.cells[p] = P.hasPermission(r.code, p); });
        return row;
      });
    }
  };
})(window.App)