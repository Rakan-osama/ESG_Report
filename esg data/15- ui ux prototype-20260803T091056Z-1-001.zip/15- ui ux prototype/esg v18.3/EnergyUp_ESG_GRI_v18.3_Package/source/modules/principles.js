/* CR-10.1 · modules/principles.js
   Reporting Principles Control Register.

   Requirement 1 of GRI 1: Foundation 2021 is "apply the reporting principles".
   v1.0 answered it with three percentages and passed four principles silently.
   That is not evidence. Each of the eight principles now carries named controls;
   a principle passes only when every mandatory control passes, and every control
   states what it tested, against what, and what it found.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  function ctl(id, question, questionAr, mandatory, evidenceType, test) {
    return { id: id, question: question, questionAr: questionAr, mandatory: mandatory, evidenceType: evidenceType, test: test };
  }
  function r(pass, found, foundAr) { return { pass: !!pass, found: found, foundAr: foundAr }; }

  var REGISTER = [
    {
      id: 'RP-01', principle: 'Accuracy', principleAr: 'الدقة',
      requirement: 'Report information that is correct and sufficiently detailed to assess impacts.',
      owner: 'ESG Technical Reviewer', reviewer: 'Methodology Owner',
      controls: [
        ctl('RP-01-C1', 'Is every value identified as measured or estimated?', 'هل كل قيمة محددة كمقيسة أو مقدّرة؟', true, 'Record field', function () {
          var recs = App.Records.approved();
          var missing = recs.filter(function (x) { return x.estimated === undefined || x.estimated === null; });
          return r(recs.length > 0 && missing.length === 0, missing.length + ' of ' + recs.length + ' approved records do not declare measured or estimated.', missing.length + ' من ' + recs.length + ' سجلًا معتمدًا لا يعلن مقيس أو مقدّر.');
        }),
        ctl('RP-01-C2', 'Does every estimated value carry a documented estimation basis?', 'هل كل قيمة مقدّرة تحمل أساس تقدير موثقًا؟', true, 'Assumption register', function () {
          var est = App.Records.approved().filter(function (x) { return x.estimated; });
          var undoc = est.filter(function (x) { return !x.assumptions && !x.estimationMethod; });
          return r(undoc.length === 0, est.length + ' estimated records, ' + undoc.length + ' without a documented basis.', est.length + ' سجلًا مقدّرًا، منها ' + undoc.length + ' بلا أساس موثق.');
        }),
        ctl('RP-01-C3', 'Does every calculation method carry an independently computed worked example that reproduces?', 'هل كل طريقة حساب لها مثال محسوب مستقل يعيد إنتاج النتيجة؟', true, 'Calculation registry', function () {
          var st = App.Calculations.selfTest(), fail = st.filter(function (x) { return !x.pass; });
          return r(fail.length === 0, st.length - fail.length + ' of ' + st.length + ' methods reproduce their worked example.', (st.length - fail.length) + ' من ' + st.length + ' طريقة تعيد إنتاج مثالها.');
        }),
        ctl('RP-01-C4', 'Are all units validated against the unit registry?', 'هل تم التحقق من كل الوحدات مقابل سجل الوحدات؟', true, 'Unit registry', function () {
          var bad = App.Records.approved().filter(function (x) { return !App.Units.family(x.rawUnit); });
          return r(bad.length === 0, bad.length + ' approved records carry a unit outside the registry.', bad.length + ' سجلًا معتمدًا يحمل وحدة خارج السجل.');
        }),
        ctl('RP-01-C5', 'Is uncertainty recorded where a value is estimated?', 'هل يُسجَّل عدم اليقين عند التقدير؟', false, 'Record field', function () {
          var est = App.Records.approved().filter(function (x) { return x.estimated; });
          var none = est.filter(function (x) { return !x.uncertainty; });
          return r(none.length === 0, none.length + ' estimated records carry no uncertainty statement.', none.length + ' سجلًا مقدّرًا بلا بيان عدم يقين.');
        })
      ]
    },
    {
      id: 'RP-02', principle: 'Balance', principleAr: 'التوازن',
      requirement: 'Report information in an unbiased way and present both favourable and unfavourable performance.',
      owner: 'ESG Programme Manager', reviewer: 'Governance Approver',
      controls: [
        ctl('RP-02-C1', 'Are both negative and positive impacts assessed and ranked?', 'هل التأثيرات السلبية والإيجابية مُقيَّمة ومرتبة؟', true, 'Impact register', function () {
          var rk = App.Materiality.ranked();
          return r(rk.negative.length > 0 && rk.positive.length > 0, rk.negative.length + ' negative and ' + rk.positive.length + ' positive impacts assessed.', rk.negative.length + ' تأثيرًا سلبيًا و' + rk.positive.length + ' إيجابيًا مُقيَّمة.');
        }),
        ctl('RP-02-C2', 'Are negative impacts above the threshold carried into the material topic list rather than dropped?', 'هل التأثيرات السلبية فوق العتبة منقولة إلى قائمة الموضوعات وليست مُسقطة؟', true, 'Materiality decision', function () {
          var rk = App.Materiality.ranked();
          var mat = rk.negative.filter(function (i) { return i._material; });
          var topics = App.Materiality.proposedTopics().map(function (p) { return p.topic; });
          var dropped = mat.filter(function (i) { return topics.indexOf(i.topic) === -1; });
          return r(mat.length > 0 && dropped.length === 0, mat.length + ' material negative impacts, ' + dropped.length + ' not carried into a topic.', mat.length + ' تأثيرًا سلبيًا جوهريًا، منها ' + dropped.length + ' غير منقول.');
        }),
        ctl('RP-02-C3', 'Are excluded topics recorded with a rationale rather than silently removed?', 'هل الموضوعات المستبعدة مسجلة بمبرر؟', true, 'Exclusion register', function () {
          var ex = App.Materiality.excludedTopics();
          var noReason = ex.filter(function (x) { return !x.rationale; });
          return r(noReason.length === 0, ex.length + ' excluded topics, ' + noReason.length + ' without a rationale.', ex.length + ' موضوعًا مستبعدًا، منها ' + noReason.length + ' بلا مبرر.');
        }),
        ctl('RP-02-C4', 'Are open findings visible rather than suppressed before publication?', 'هل الملاحظات المفتوحة ظاهرة وليست مخفية قبل النشر؟', false, 'Finding register', function () {
          var open = App.State.findings.filter(function (f) { return f.status === 'OPEN'; });
          return r(true, open.length + ' findings are open and visible.', open.length + ' ملاحظة مفتوحة وظاهرة.');
        })
      ]
    },
    {
      id: 'RP-03', principle: 'Clarity', principleAr: 'الوضوح',
      requirement: 'Present information in a way that is accessible and understandable.',
      owner: 'ESG Programme Manager', reviewer: 'ESG Technical Reviewer',
      controls: [
        ctl('RP-03-C1', 'Is every reported figure expressed in a declared unit?', 'هل كل رقم مُبلَّغ مُعبَّر عنه بوحدة معلنة؟', true, 'Calculation run', function () {
          var runs = App.State.calcRuns, bad = runs.filter(function (x) { return !x.outputUnit; });
          return r(runs.length > 0 && bad.length === 0, runs.length + ' calculation runs, ' + bad.length + ' without an output unit.', runs.length + ' تشغيل حساب، منها ' + bad.length + ' بلا وحدة ناتج.');
        }),
        ctl('RP-03-C2', 'Is the content index generated with a location for every reported disclosure?', 'هل الفهرس مولّد بموقع لكل إفصاح مُبلَّغ؟', true, 'Content index', function () {
          var ci = App.GRI.contentIndex();
          return r(ci.rows.length > 0 && ci.missingLocation === 0, ci.missingLocation + ' of ' + ci.rows.length + ' index rows have no location.', ci.missingLocation + ' من ' + ci.rows.length + ' صفًا بلا موقع.');
        }),
        ctl('RP-03-C3', 'Is terminology approved in both working languages?', 'هل المصطلحات معتمدة باللغتين؟', true, 'Glossary', function () {
          var p = App.parity();
          return r(p.pct >= 100, 'Interface terminology parity ' + p.pct + '% (' + p.approved + '/' + p.total + ').', 'تكافؤ مصطلحات الواجهة ' + p.pct + '٪.');
        })
      ]
    },
    {
      id: 'RP-04', principle: 'Comparability', principleAr: 'القابلية للمقارنة',
      requirement: 'Select and report information consistently so that change over time can be analysed.',
      owner: 'ESG Technical Reviewer', reviewer: 'Methodology Owner',
      controls: [
        ctl('RP-04-C1', 'Is a comparative period available for the reported indicators?', 'هل تتوفر فترة مقارنة للمؤشرات المُبلَّغة؟', true, 'Prior cycle', function () {
          var prior = App.Data.demo.priorCycle;
          return r(!!prior, prior ? 'Prior cycle ' + prior.label + ' is available for comparison.' : 'No prior reporting cycle is loaded; the first cycle has no comparative.', prior ? 'دورة سابقة ' + prior.label + ' متاحة للمقارنة.' : 'لا توجد دورة سابقة محمّلة.');
        }),
        ctl('RP-04-C2', 'Are calculation methods versioned so that a method change is detectable?', 'هل طرق الحساب ذات إصدارات بحيث يُكتشف تغيّرها؟', true, 'Method registry', function () {
          var m = App.Data.calculationMethods, bad = m.filter(function (x) { return !x.version; });
          return r(bad.length === 0, m.length + ' methods, all versioned.', m.length + ' طريقة، جميعها ذات إصدار.');
        }),
        ctl('RP-04-C3', 'Does a change after period lock require a restatement rather than a silent edit?', 'هل التغيير بعد قفل الفترة يتطلب إعادة عرض بدل تعديل صامت؟', true, 'Workflow rule', function () {
          return r(App.Records.FLOW.APPROVED.length === 1 && App.Records.FLOW.APPROVED[0] === 'REOPENED',
            'An approved record can only move to REOPENED, which freezes the approved version.',
            'السجل المعتمد لا ينتقل إلا إلى إعادة الفتح، مع تجميد النسخة المعتمدة.');
        })
      ]
    },
    {
      id: 'RP-05', principle: 'Completeness', principleAr: 'الاكتمال',
      requirement: 'Provide sufficient information to assess impacts during the reporting period.',
      owner: 'ESG Programme Manager', reviewer: 'ESG Technical Reviewer',
      controls: [
        ctl('RP-05-C1', 'Is every in-boundary site covered by approved records?', 'هل كل موقع داخل الحدود مغطى بسجلات معتمدة؟', true, 'Boundary vs records', function () {
          var sites = App.Data.demo.sites.filter(function (s) { return s.inBoundary; });
          var covered = sites.filter(function (s) { return App.Records.approved().some(function (x) { return x.siteId === s.id; }); });
          return r(covered.length === sites.length, covered.length + ' of ' + sites.length + ' in-boundary sites have approved records.', covered.length + ' من ' + sites.length + ' موقعًا داخل الحدود لديه سجلات معتمدة.');
        }),
        ctl('RP-05-C2', 'Is every excluded site recorded with a rationale?', 'هل كل موقع مستبعد مسجل بمبرر؟', true, 'Boundary register', function () {
          var ex = App.Data.demo.sites.filter(function (s) { return !s.inBoundary; });
          var noReason = ex.filter(function (s) { return !s.exclusionRationale; });
          return r(noReason.length === 0, ex.length + ' excluded sites, ' + noReason.length + ' without a rationale.', ex.length + ' موقعًا مستبعدًا، منها ' + noReason.length + ' بلا مبرر.');
        }),
        ctl('RP-05-C3', 'Is every incomplete disclosure either closed or carried by an approved reason for omission?', 'هل كل إفصاح ناقص مُغلق أو مغطى بسبب حذف معتمد؟', true, 'Omission register', function () {
          var gaps = (App.State.gri2 || []).filter(function (d) { return d.status !== 'COMPLETE'; });
          var covered = gaps.filter(function (d) {
            return App.State.omissions.some(function (o) { return o.disclosure === d.code && o.status === 'APPROVED'; });
          });
          return r(gaps.length === covered.length, gaps.length + ' incomplete GRI 2 disclosures, ' + covered.length + ' covered by an approved omission.', gaps.length + ' إفصاحًا ناقصًا، منها ' + covered.length + ' مغطى بحذف معتمد.');
        }),
        ctl('RP-05-C4', 'Do all twelve months of the reporting period carry data for continuous activities?', 'هل كل شهور الفترة تحمل بيانات للأنشطة المستمرة؟', false, 'Period coverage', function () {
          var months = {};
          App.Records.approved().forEach(function (x) { if (x.periodLabel) months[String(x.periodLabel).slice(0, 7)] = 1; });
          var n = Object.keys(months).length;
          return r(n >= 12, n + ' distinct monthly periods carry approved records.', n + ' فترة شهرية تحمل سجلات معتمدة.');
        })
      ]
    },
    {
      id: 'RP-06', principle: 'Sustainability context', principleAr: 'سياق الاستدامة',
      requirement: 'Report information about impacts in the wider context of sustainable development.',
      owner: 'ESG Programme Manager', reviewer: 'Governance Approver',
      controls: [
        ctl('RP-06-C1', 'Are targets recorded with a base year and a target year?', 'هل الأهداف مسجلة بسنة أساس وسنة مستهدفة؟', true, 'Target register', function () {
          var tg = App.Data.demo.targets || [], bad = tg.filter(function (x) { return !x.baseYear || !x.targetYear; });
          return r(tg.length > 0 && bad.length === 0, tg.length + ' targets, ' + bad.length + ' without a base or target year.', tg.length + ' هدفًا، منها ' + bad.length + ' بلا سنة أساس أو سنة مستهدفة.');
        }),
        ctl('RP-06-C2', 'Are impacts positioned in the value chain rather than limited to own operations?', 'هل التأثيرات موضوعة في سلسلة القيمة وليست محصورة في العمليات الذاتية؟', true, 'Impact register', function () {
          var vs = {};
          App.State.impacts.forEach(function (i) { vs[i.valueChain] = 1; });
          var n = Object.keys(vs).length;
          return r(n >= 2, 'Impacts span ' + n + ' value-chain positions.', 'التأثيرات تغطي ' + n + ' موضعًا في سلسلة القيمة.');
        }),
        ctl('RP-06-C3', 'Is the threshold model bound to a declared sector and context?', 'هل نموذج العتبة مرتبط بقطاع وسياق معلنين؟', true, 'Threshold model', function () {
          var m = App.Materiality.model();
          return r(!!m.sector, 'Threshold model ' + m.id + ' v' + m.version + ' is bound to: ' + (m.sector || 'no declared sector'), 'نموذج العتبة مرتبط بـ: ' + (m.sector || 'لا يوجد قطاع معلن'));
        })
      ]
    },
    {
      id: 'RP-07', principle: 'Timeliness', principleAr: 'التوقيت',
      requirement: 'Report on a regular schedule and make information available in time for decisions.',
      owner: 'ESG Programme Manager', reviewer: 'Governance Approver',
      controls: [
        ctl('RP-07-C1', 'Is the reporting period defined with a start and an end?', 'هل فترة التقرير محددة ببداية ونهاية؟', true, 'Cycle record', function () {
          var c = App.Data.demo.cycle;
          return r(!!(c.periodStart && c.periodEnd), 'Period ' + c.periodStart + ' to ' + c.periodEnd + '.', 'الفترة من ' + c.periodStart + ' إلى ' + c.periodEnd + '.');
        }),
        ctl('RP-07-C2', 'Does every approved record fall inside the reporting period?', 'هل كل سجل معتمد يقع داخل فترة التقرير؟', true, 'Record period', function () {
          var c = App.Data.demo.cycle;
          var out = App.Records.approved().filter(function (x) { return x.periodStart < c.periodStart || x.periodEnd > c.periodEnd; });
          return r(out.length === 0, out.length + ' approved records fall outside the reporting period.', out.length + ' سجلًا معتمدًا خارج فترة التقرير.');
        }),
        ctl('RP-07-C3', 'Are there no overdue open findings blocking the schedule?', 'هل لا توجد ملاحظات متأخرة تعطل الجدول؟', false, 'Finding register', function () {
          var open = App.State.findings.filter(function (f) { return f.status === 'OPEN'; });
          return r(open.length === 0, open.length + ' findings remain open.', open.length + ' ملاحظة ما زالت مفتوحة.');
        })
      ]
    },
    {
      id: 'RP-08', principle: 'Verifiability', principleAr: 'القابلية للتحقق',
      requirement: 'Gather and record information so that it can be examined to establish its quality.',
      owner: 'ESG Technical Reviewer', reviewer: 'Assurance Reviewer',
      controls: [
        ctl('RP-08-C1', 'Does every approved record that requires evidence carry linked evidence?', 'هل كل سجل معتمد يتطلب دليلًا يحمل دليلًا مرتبطًا؟', true, 'Evidence links', function () {
          var need = App.Records.approved().filter(function (x) { var a = App.Records.activity(x.activityId); return !a || a.evidence_required; });
          var without = need.filter(function (x) { return !(x.evidenceIds || []).length; });
          return r(need.length > 0 && without.length === 0, without.length + ' of ' + need.length + ' evidence-requiring approved records have no linked evidence.', without.length + ' من ' + need.length + ' سجلًا معتمدًا بلا دليل مرتبط.');
        }),
        ctl('RP-08-C2', 'Does every calculation run preserve a full input-to-output trace?', 'هل كل تشغيل حساب يحفظ أثرًا كاملًا من المدخل إلى الناتج؟', true, 'Calculation lineage', function () {
          var runs = App.State.calcRuns, bad = runs.filter(function (x) { return !x.trace || !x.trace.length; });
          return r(runs.length > 0 && bad.length === 0, runs.length + ' runs, ' + bad.length + ' without a trace.', runs.length + ' تشغيلًا، منها ' + bad.length + ' بلا أثر.');
        }),
        ctl('RP-08-C3', 'Is the approval history preserved and immutable?', 'هل سجل الاعتمادات محفوظ وغير قابل للتعديل؟', true, 'Audit log', function () {
          var frozen = App.State.audit.length === 0 || Object.isFrozen(App.State.audit[0]);
          return r(frozen && typeof App.Audit.delete === 'undefined', 'Audit events are frozen on creation and the module exposes no delete path.', 'أحداث التدقيق مجمّدة عند الإنشاء ولا يوجد مسار حذف.');
        }),
        ctl('RP-08-C4', 'Are evidence digests real rather than presented as real when simulated?', 'هل بصمات الأدلة حقيقية أو معلنة كمحاكاة؟', true, 'Evidence model', function () {
          var e = App.State.evidence;
          var mislabelled = e.filter(function (x) { return x.hashMethod !== 'SHA-256' && !/^SIM-/.test(x.hash); });
          return r(mislabelled.length === 0, e.filter(function (x) { return x.hashMethod === 'SHA-256'; }).length + ' real SHA-256 digests, ' + e.filter(function (x) { return /^SIM-/.test(x.hash); }).length + ' declared simulated, ' + mislabelled.length + ' mislabelled.', mislabelled.length + ' بصمة غير معلنة بشكل صحيح.');
        })
      ]
    }
  ];

  var P = App.Principles = {
    register: function () { return REGISTER; },

    /* evaluate one principle; a principle passes only when every mandatory control passes */
    evaluate: function (id) {
      var p = REGISTER.filter(function (x) { return x.id === id; })[0];
      if (!p) return null;
      var controls = p.controls.map(function (c) {
        var out;
        try { out = c.test(); } catch (e) { out = r(false, 'Control could not be evaluated: ' + e.message, 'تعذّر تقييم الضابط.'); }
        return {
          id: c.id, question: c.question, questionAr: c.questionAr, mandatory: c.mandatory,
          evidenceType: c.evidenceType, pass: out.pass, found: out.found, foundAr: out.foundAr
        };
      });
      var mandatoryFailed = controls.filter(function (c) { return c.mandatory && !c.pass; });
      return {
        id: p.id, principle: p.principle, principleAr: p.principleAr, requirement: p.requirement,
        owner: p.owner, reviewer: p.reviewer, controls: controls,
        status: mandatoryFailed.length === 0 ? 'PASS' : 'FAIL',
        pass: mandatoryFailed.length === 0,
        failedMandatory: mandatoryFailed.length,
        remediation: mandatoryFailed.map(function (c) { return c.id + ' — ' + c.found; }),
        exception: null, approval: null,
        lastEvaluated: App.now()
      };
    },

    results: function () { return REGISTER.map(function (p) { return P.evaluate(p.id); }); },

    summary: function () {
      var res = P.results();
      return {
        total: res.length,
        passed: res.filter(function (x) { return x.pass; }).length,
        controls: res.reduce(function (n, x) { return n + x.controls.length; }, 0),
        controlsPassed: res.reduce(function (n, x) { return n + x.controls.filter(function (c) { return c.pass; }).length; }, 0)
      };
    }
  };
})(window.App)