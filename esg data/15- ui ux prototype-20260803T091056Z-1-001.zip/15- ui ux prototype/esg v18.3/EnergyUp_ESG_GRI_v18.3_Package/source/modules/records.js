/* CR-10 · modules/records.js
   Multi-record model: many records may exist for one activity across entity,
   site, period and any configured dimension. Approval is version-bound — an
   edit after approval preserves the approved version, creates a new one and
   sends it back through review.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  var FLOW = {
    DRAFT: ['VALIDATED', 'SUBMITTED'],
    VALIDATED: ['SUBMITTED', 'DRAFT'],
    SUBMITTED: ['UNDER_REVIEW', 'RETURNED'],
    UNDER_REVIEW: ['APPROVED', 'RETURNED'],
    RETURNED: ['DRAFT'],
    APPROVED: ['REOPENED'],
    REOPENED: ['DRAFT']
  };

  /* canonical audit verbs — the log vocabulary is fixed, not derived from a status string */
  var VERB = { VALIDATED: 'validate', SUBMITTED: 'submit', UNDER_REVIEW: 'review',
    APPROVED: 'approve', RETURNED: 'return', REOPENED: 'reopen', DRAFT: 'edit' };

  var R = App.Records = {
    FLOW: FLOW,

    all: function () { return App.State.records; },

    /* ---------- CR-10.1 · P0-02 — the form is generated from the activity ----------
       Each activity in the dictionary declares its own repeat dimensions, unit,
       evidence requirement, owner and reviewer. The New Record form reads that
       declaration; it does not carry a fixed field list. */
    DIMENSIONS: {
      site:              { key: 'siteId',           en: 'Site',              ar: 'الموقع',            type: 'site',   required: true },
      entity:            { key: 'entityId',         en: 'Legal entity',      ar: 'الكيان القانوني',    type: 'entity', required: true },
      facility:          { key: 'facility',         en: 'Facility',          ar: 'المنشأة',           type: 'text',   required: false },
      meter:             { key: 'meter',            en: 'Meter',             ar: 'العداد',            type: 'text',   required: true },
      tank:              { key: 'tank',             en: 'Tank',              ar: 'الخزان',            type: 'text',   required: true },
      equipment:         { key: 'equipment',        en: 'Equipment',         ar: 'المعدة',            type: 'text',   required: true },
      vehicle:           { key: 'vehicle',          en: 'Vehicle',           ar: 'المركبة',           type: 'text',   required: true },
      department:        { key: 'department',       en: 'Department',        ar: 'الإدارة',           type: 'text',   required: false },
      line:              { key: 'line',             en: 'Production line',   ar: 'خط الإنتاج',        type: 'text',   required: true },
      process:           { key: 'process',          en: 'Process',           ar: 'العملية',           type: 'text',   required: true },
      product:           { key: 'product',          en: 'Product',           ar: 'المنتج',            type: 'text',   required: true },
      material:          { key: 'material',         en: 'Material',          ar: 'المادة',            type: 'text',   required: true },
      packaging_type:    { key: 'packagingType',    en: 'Packaging type',    ar: 'نوع التعبئة',       type: 'text',   required: true },
      supplier:          { key: 'supplier',         en: 'Supplier',          ar: 'المورد',            type: 'text',   required: true },
      carrier:           { key: 'carrier',          en: 'Carrier',           ar: 'الناقل',            type: 'text',   required: true },
      route:             { key: 'route',            en: 'Route',             ar: 'المسار',            type: 'text',   required: true },
      mode:              { key: 'mode',             en: 'Transport mode',    ar: 'وسيلة النقل',       type: 'text',   required: true },
      class:             { key: 'travelClass',      en: 'Travel class',      ar: 'درجة السفر',        type: 'text',   required: false },
      gas:               { key: 'gas',              en: 'Gas',               ar: 'الغاز',             type: 'text',   required: true },
      fuel:              { key: 'fuel',             en: 'Fuel',              ar: 'الوقود',            type: 'text',   required: true },
      source:            { key: 'source',           en: 'Source',            ar: 'المصدر',            type: 'text',   required: true },
      destination:       { key: 'destination',      en: 'Destination',       ar: 'الوجهة',            type: 'text',   required: true },
      outfall:           { key: 'outfall',          en: 'Outfall',           ar: 'نقطة التصريف',      type: 'text',   required: true },
      stack:             { key: 'stack',            en: 'Stack',             ar: 'المدخنة',           type: 'text',   required: true },
      parameter:         { key: 'parameter',        en: 'Parameter',         ar: 'المعامل',           type: 'text',   required: true },
      pollutant:         { key: 'pollutant',        en: 'Pollutant',         ar: 'الملوث',            type: 'text',   required: true },
      waste_type:        { key: 'wasteType',        en: 'Waste type',        ar: 'نوع النفايات',      type: 'text',   required: true },
      hazard:            { key: 'hazard',           en: 'Hazard class',      ar: 'فئة الخطورة',       type: 'text',   required: true },
      route_:            { key: 'treatmentRoute',   en: 'Treatment route',   ar: 'مسار المعالجة',     type: 'text',   required: true },
      contractor:        { key: 'contractor',       en: 'Contractor',        ar: 'المقاول',           type: 'text',   required: true },
      gender:            { key: 'gender',           en: 'Gender',            ar: 'النوع',             type: 'text',   required: true },
      age_band:          { key: 'ageBand',          en: 'Age band',          ar: 'الفئة العمرية',     type: 'text',   required: true },
      category:          { key: 'employeeCategory', en: 'Employee category', ar: 'فئة العاملين',      type: 'text',   required: true },
      contract:          { key: 'contractType',     en: 'Contract type',     ar: 'نوع العقد',         type: 'text',   required: true },
      worker_type:       { key: 'workerType',       en: 'Worker type',       ar: 'نوع العامل',        type: 'text',   required: true },
      employee:          { key: 'employee',         en: 'Employee reference',ar: 'مرجع الموظف',       type: 'text',   required: false },
      course:            { key: 'course',           en: 'Course',            ar: 'الدورة',            type: 'text',   required: true },
      severity:          { key: 'severity',         en: 'Severity',          ar: 'الشدة',             type: 'text',   required: true },
      illness_type:      { key: 'illnessType',      en: 'Illness type',      ar: 'نوع الاعتلال',      type: 'text',   required: true },
      operation:         { key: 'operation',        en: 'Operation',         ar: 'العملية التشغيلية', type: 'text',   required: true },
      risk_type:         { key: 'riskType',         en: 'Risk type',         ar: 'نوع المخاطرة',      type: 'text',   required: true },
      case:              { key: 'caseRef',          en: 'Case reference',    ar: 'مرجع الحالة',       type: 'text',   required: true },
      case_type:         { key: 'caseType',         en: 'Case type',         ar: 'نوع الحالة',        type: 'text',   required: true },
      outcome:           { key: 'outcome',          en: 'Outcome',           ar: 'النتيجة',           type: 'text',   required: true },
      party_type:        { key: 'partyType',        en: 'Party type',        ar: 'نوع الطرف',         type: 'text',   required: true },
      status:            { key: 'dimStatus',        en: 'Status',            ar: 'الحالة',            type: 'text',   required: true },
      audience:          { key: 'audience',         en: 'Audience',          ar: 'الجمهور',           type: 'text',   required: true },
      region:            { key: 'region',           en: 'Region',            ar: 'المنطقة',           type: 'text',   required: true },
      country:           { key: 'country',          en: 'Country',           ar: 'الدولة',            type: 'text',   required: true },
      entity_:           { key: 'entityRef',        en: 'Entity',            ar: 'الكيان',            type: 'text',   required: true },
      tax_type:          { key: 'taxType',          en: 'Tax type',          ar: 'نوع الضريبة',       type: 'text',   required: true },
      component:         { key: 'component',        en: 'Component',         ar: 'المكوّن',           type: 'text',   required: true },
      member:            { key: 'member',           en: 'Member',            ar: 'العضو',             type: 'text',   required: true },
      committee:         { key: 'committee',        en: 'Committee',         ar: 'اللجنة',            type: 'text',   required: true },
      independence:      { key: 'independence',     en: 'Independence',      ar: 'الاستقلالية',       type: 'text',   required: false },
      criteria:          { key: 'criteria',         en: 'Criteria',          ar: 'المعايير',          type: 'text',   required: true },
      impact_type:       { key: 'impactType',       en: 'Impact type',       ar: 'نوع التأثير',       type: 'text',   required: true },
      action:            { key: 'action',           en: 'Action',            ar: 'الإجراء',           type: 'text',   required: true },
      stakeholder:       { key: 'stakeholder',      en: 'Stakeholder group', ar: 'فئة أصحاب المصلحة', type: 'text',   required: true },
      activity:          { key: 'activityRef',      en: 'Activity',          ar: 'النشاط',            type: 'text',   required: false },
      concern:           { key: 'concern',          en: 'Concern',           ar: 'الشاغل',            type: 'text',   required: true },
      nature:            { key: 'nature',           en: 'Nature',            ar: 'الطبيعة',           type: 'text',   required: true },
      instrument:        { key: 'instrument',       en: 'Instrument',        ar: 'الجهاز',            type: 'text',   required: true },
      permit:            { key: 'permit',           en: 'Permit',            ar: 'التصريح',           type: 'text',   required: true },
      requirement:       { key: 'requirement',      en: 'Requirement',       ar: 'المتطلب',           type: 'text',   required: true },
      issue:             { key: 'issue',            en: 'Issue',             ar: 'الموضوع',           type: 'text',   required: true },
      array:             { key: 'array',            en: 'Array',             ar: 'المصفوفة',          type: 'text',   required: true },
      invoice:           { key: 'invoice',          en: 'Invoice number',    ar: 'رقم الفاتورة',      type: 'text',   required: true },
      distance:          { key: 'distance',         en: 'Distance basis',    ar: 'أساس المسافة',      type: 'text',   required: false },
      days:              { key: 'days',             en: 'Days',              ar: 'الأيام',            type: 'text',   required: false },
      sample:            { key: 'sample',           en: 'Sample',            ar: 'العينة',            type: 'text',   required: false }
    },

    /* period dimensions are handled by the period fields, not as free dimensions */
    PERIOD_DIMS: ['month', 'quarter', 'year', 'date', 'due_date', 'reading_date', 'period'],

    fieldsFor: function (activityId) {
      var a = R.activity(activityId);
      if (!a) return { activity: null, dimensions: [], unit: '', evidenceRequired: true };
      var declared = String(a.dimensions || '').split(',').map(function (x) { return x.trim(); }).filter(Boolean);
      var dims = [];
      declared.forEach(function (d) {
        if (R.PERIOD_DIMS.indexOf(d) > -1) return;
        var def = R.DIMENSIONS[d] || R.DIMENSIONS[d + '_'];
        if (def) { if (dims.every(function (x) { return x.key !== def.key; })) dims.push(Object.assign({ dim: d }, def)); }
        else dims.push({ dim: d, key: d, en: d.replace(/_/g, ' '), ar: d.replace(/_/g, ' '), type: 'text', required: true });
      });
      return {
        activity: a, dimensions: dims, unit: a.unit || '',
        evidenceRequired: a.evidence_required !== false,
        ownerRole: a.owner_role || '', frequency: a.frequency || '',
        sourceType: a.source_type || '', sourceSystem: a.source_system || '',
        griMapping: a.gri_mapping || '', domain: a.domain || '',
        validationRule: a.validation_rule || '', assuranceRisk: a.assurance_risk || ''
      };
    },

    /* P0-03 — a true duplicate is the full dimensional key, not the activity id */
    findDuplicate: function (candidate) {
      var key = R.key(candidate);
      return App.State.records.filter(function (x) { return !x.frozen && R.key(x) === key; })[0] || null;
    },

    byId: function (id) { return App.State.records.filter(function (r) { return r.id === id; })[0] || null; },
    byActivity: function (a) { return App.State.records.filter(function (r) { return r.activityId === a; }); },
    approved: function () { return App.State.records.filter(function (r) { return r.status === 'APPROVED'; }); },
    byStatus: function (s) { return s === 'all' ? App.State.records : App.State.records.filter(function (r) { return r.status === s; }); },

    /* v18.3 — canonical business key over the COMPLETE dimensional key (P0-2 + P1-2).
       Includes datapointId; honours per-dimension case-sensitivity definitions
       (App.Data.dimensionDefinitions[key].caseSensitive); dates are parsed and
       re-emitted as ISO (invalid dates key as null, never as raw text).
       record id and record version are NEVER part of the duplicate key. */
    _norm: function (v, caseSensitive) {
      if (v === undefined || v === null || String(v).trim() === '') return null;
      var s = String(v).trim().normalize('NFC');
      return caseSensitive ? s : s.toUpperCase();
    },
    _isoDate: function (v) {
      if (!v) return null;
      var d = new Date(String(v).trim());
      if (isNaN(d.getTime())) return null;
      return d.toISOString().slice(0, 10);
    },
    businessKey: function (r) {
      var defs = (App.Data && App.Data.dimensionDefinitions) || {};
      var dims = {}, src = r.dimensions || {};
      Object.keys(src).sort().forEach(function (k) {
        var nk = k.normalize('NFC');
        dims[nk] = R._norm(src[k], defs[nk] && defs[nk].caseSensitive === true);
      });
      return JSON.stringify({
        t: R._norm(r.tenantId, true), o: R._norm(r.orgId, true), c: R._norm(r.cycleId, true),
        a: R._norm(r.activityId, true), dp: R._norm(r.datapointId, true),
        e: R._norm(r.entityId, true), s: R._norm(r.siteId, true),
        ps: R._isoDate(r.periodStart), pe: R._isoDate(r.periodEnd), d: dims
      });
    },
    /* legacy alias kept for findDuplicate and any external caller */
    key: function (r) { return R.businessKey(r); },
    duplicateOf: function (r) {
      var key = R.businessKey(r);
      return App.State.records.filter(function (x) {
        return x.id !== r.id && !x.frozen && x.status !== 'SUPERSEDED' && R.businessKey(x) === key;
      })[0] || null;
    },

    activity: function (id) {
      return App.Data.registry.activities.filter(function (a) { return a.activity_id === id; })[0] || null;
    },
    site: function (id) {
      return App.Data.demo.sites.filter(function (s) { return s.id === id; })[0] || null;
    },

    /* ---------------- validation ---------------- */
    validate: function (r, stage) {
      stage = stage || 'entry';
      var a = R.activity(r.activityId), out = [];
      function rule(id) { return App.Data.validationRules.filter(function (x) { return x.id === id; })[0]; }
      function push(id) { var x = rule(id); if (x) out.push({ id: x.id, severity: x.severity, message: App.L(x.en, x.ar) }); }

      if (r.rawValue === '' || r.rawValue === null || r.rawValue === undefined) push('VR-COM-001');
      else if (isNaN(Number(r.rawValue))) push('VR-LOG-003');
      else if (Number(r.rawValue) < 0) push('VR-LOG-005');

      if (!r.rawUnit) push('VR-UOM-004');
      else if (a && a.unit && !App.Units.compatible(r.rawUnit, a.unit)) push('VR-UOM-004');

      if (!r.periodStart || !r.periodEnd) push('VR-PER-001');
      else {
        var c = App.Data.demo.cycle;
        if (r.periodStart < c.periodStart || r.periodEnd > c.periodEnd) push('VR-PER-001');
      }

      var site = R.site(r.siteId);
      if (!site || !site.inBoundary) push('VR-SIT-002');

      if (r.estimated && !r.assumptions) push('VR-EST-001');

      if (stage === 'submit' && a && a.evidence_required && (!r.evidenceIds || !r.evidenceIds.length)) push('VR-EVD-001');

      if (R.duplicateOf(r)) push('VR-DUP-001');

      var prior = R.priorValue(r);
      if (prior && r.rawValue && Math.abs(Number(r.rawValue) - prior) / Math.max(1, prior) > 0.25 && !r.varianceExplanation) push('VR-TRD-001');

      return {
        blockers: out.filter(function (x) { return x.severity === 'BLOCKER'; }),
        errors: out.filter(function (x) { return x.severity === 'ERROR'; }),
        warnings: out.filter(function (x) { return x.severity === 'WARNING'; }),
        all: out,
        pass: out.filter(function (x) { return x.severity === 'BLOCKER'; }).length === 0
      };
    },

    priorValue: function (r) {
      var same = App.State.records.filter(function (x) {
        return x.activityId === r.activityId && x.siteId === r.siteId && x.id !== r.id && x.status === 'APPROVED';
      });
      if (!same.length) return null;
      return Number(same[same.length - 1].rawValue);
    },

    /* ---------------- transitions ---------------- */
    transition: function (id, to, opts) {
      opts = opts || {};
      var r = R.byId(id); if (!r) return fail('NOT_FOUND', 'Record not found.');
      var permMap = { VALIDATED: 'record.validate', SUBMITTED: 'record.submit', UNDER_REVIEW: 'record.review', APPROVED: 'record.approve', RETURNED: 'record.return', REOPENED: 'record.reopen' };
      var perm = permMap[to] || 'record.edit';

      var guard = App.Permissions.canPerformAction({ permission: perm, object: r });
      if (!guard.allowed) { App.Audit.write({ action: 'permission.denied', objectType: 'record', objectId: r.id, reason: guard.code, metadata: { attempted: to } }); return fail(guard.code, App.L(guard.reason.en, guard.reason.ar)); }

      if ((FLOW[r.status] || []).indexOf(to) === -1)
        return fail('ILLEGAL_TRANSITION', App.L('Transition ' + r.status + ' → ' + to + ' is not permitted.', 'الانتقال ' + r.status + ' ← ' + to + ' غير مسموح.'));

      if (to === 'VALIDATED' || to === 'SUBMITTED') {
        var v = R.validate(r, to === 'SUBMITTED' ? 'submit' : 'entry');
        if (!v.pass) return fail('VALIDATION_FAILED', App.L('Blocking validations are open.', 'توجد قواعد تحقق حاجبة مفتوحة.'), v);
      }
      if ((to === 'RETURNED' || to === 'REOPENED') && !opts.reason)
        return fail('REASON_REQUIRED', App.L('A reason is required.', 'السبب مطلوب.'));

      var prev = r.status;

      if (to === 'REOPENED') {
        /* preserve the approved version, open a new one */
        var frozen = App.clone(r);
        frozen.id = r.id + '-v' + r.version;
        frozen.status = 'APPROVED';
        frozen.frozen = true;
        App.State.records.push(frozen);
        r.version = r.version + 1;
        r.approvedAt = null; r.reviewedAt = null; r.submittedAt = null;
        r.reopenReason = opts.reason;
        r.status = 'REOPENED';
      } else {
        r.status = to;
      }

      r.updatedAt = App.now();
      /* A workflow transition is not an edit. Only edit() may set lastEditedBy —
         otherwise entering review would make the reviewer the last editor and
         SOD-01 would refuse every approval. */
      r.lastActionBy = App.State.user.id;
      if (to === 'SUBMITTED') r.submittedAt = App.now();
      if (to === 'UNDER_REVIEW') r.reviewer = App.State.role;
      if (to === 'APPROVED') { r.approvedAt = App.now(); r.approvedBy = App.State.user.id; r.approvedVersion = r.version; }
      if (to === 'RETURNED') { r.reviewedAt = App.now(); r.returnReason = opts.reason; }

      App.Audit.write({
        action: VERB[to] || 'edit', objectType: 'record', objectId: r.id,
        objectVersion: r.version, previousStatus: prev, newStatus: r.status, reason: opts.reason || null
      });
      App.save();
      return { ok: true, record: r };

      function fail(code, message, detail) { return { ok: false, code: code, message: message, detail: detail }; }
    },

    /* edit → if the record was approved, freeze the approved version and reopen */
    edit: function (id, patch) {
      var r = R.byId(id); if (!r) return { ok: false, code: 'NOT_FOUND' };
      if (r.status === 'APPROVED') {
        var re = R.transition(id, 'REOPENED', { reason: patch.__reason || App.L('Edit after approval', 'تعديل بعد الاعتماد') });
        if (!re.ok) return re;
        r = re.record;
      }
      if (!App.Permissions.guard('record.edit', r)) return { ok: false, code: 'DENIED' };
      Object.keys(patch).forEach(function (k) { if (k.indexOf('__') !== 0) r[k] = patch[k]; });
      if (r.status === 'REOPENED') r.status = 'DRAFT';
      if (r.status === 'RETURNED') r.status = 'DRAFT';
      if (r.status === 'VALIDATED') r.status = 'DRAFT';
      r.updatedAt = App.now();
      r.lastEditedBy = App.State.user.id;
      if (App.State.role === 'ESG_TECH_REVIEWER') r.editedByReviewer = true;   /* SOD-02 */
      App.Audit.write({ action: 'edit', objectType: 'record', objectId: r.id, objectVersion: r.version, newStatus: r.status, metadata: { fields: Object.keys(patch) } });
      App.save();
      return { ok: true, record: r };
    },

    create: function (data) {
      if (!App.Permissions.guard('record.create', null)) return { ok: false, code: 'DENIED' };
      var r = Object.assign({
        id: App.nextId('REC'), tenantId: App.State.tenantNamespace || 'TEN-EEG', orgId: (App.Data.demo.organization && App.Data.demo.organization.id) || 'ORG-DIG', cycleId: (App.Data.demo.cycle && App.Data.demo.cycle.id) || 'CYC-2025',
        dimensions: {}, evidenceIds: [], status: 'DRAFT', version: 1,
        createdAt: App.now(), updatedAt: App.now(), createdBy: App.State.user.id,
        owner: 'DATA_OWNER', contributor: App.State.role, method: 'Measured', estimated: false
      }, data);
      App.State.records.push(r);
      App.Audit.write({ action: 'create', objectType: 'record', objectId: r.id, objectVersion: 1, newStatus: 'DRAFT' });
      App.save();
      return { ok: true, record: r };
    },

    /* ---------------- read models ---------------- */
    stats: function () {
      var all = App.State.records.filter(function (r) { return !r.frozen; });
      function n(s) { return all.filter(function (r) { return r.status === s; }).length; }
      var withEvidence = all.filter(function (r) { return r.evidenceIds && r.evidenceIds.length; }).length;
      var validated = all.filter(function (r) { return R.validate(r, 'submit').pass; }).length;
      return {
        total: all.length, draft: n('DRAFT'), validated: n('VALIDATED'), submitted: n('SUBMITTED'),
        review: n('UNDER_REVIEW'), returned: n('RETURNED'), approved: n('APPROVED'), reopened: n('REOPENED'),
        completeness: pct(n('APPROVED') + n('UNDER_REVIEW') + n('SUBMITTED'), all.length),
        evidenceCoverage: pct(withEvidence, all.length),
        validationPass: pct(validated, all.length),
        estimated: all.filter(function (r) { return r.estimated; }).length
      };
    },

    myWork: function (role) {
      role = role || App.State.role;
      var out = [];
      App.State.records.filter(function (r) { return !r.frozen; }).forEach(function (r) {
        var a = R.activity(r.activityId);
        var item = {
          objectType: 'Record', objectId: r.id, org: 'Delta Industrial Group', site: r.siteId,
          period: r.periodLabel, status: r.status, owner: r.owner, assignee: r.contributor,
          due: '2026-03-31', priority: 'Normal', blocking: '', action: '',
          title: a ? App.L(a.name_en, a.name_ar) : r.activityId
        };
        var v = R.validate(r, 'submit');
        if (['DATA_CONTRIBUTOR', 'DATA_OWNER', 'CONSULTANT'].indexOf(role) > -1) {
          if (r.status === 'DRAFT') { item.action = App.t('validate'); item.priority = 'High'; out.push(item); }
          else if (r.status === 'RETURNED') { item.action = App.L('Correct and resubmit', 'صحّح وأعد الإرسال'); item.priority = 'High'; item.blocking = App.L('Blocks data completeness gate', 'يحجب بوابة اكتمال البيانات'); out.push(item); }
          else if (r.status === 'VALIDATED') { item.action = App.t('submit'); out.push(item); }
          else if (!v.pass && r.status !== 'APPROVED') { item.action = App.L('Fix validation failures', 'عالج قواعد التحقق'); item.priority = 'High'; out.push(item); }
        }
        if (['ESG_TECH_REVIEWER', 'ESG_PROGRAMME_MANAGER', 'DATA_OWNER'].indexOf(role) > -1) {
          if (r.status === 'SUBMITTED') { item.action = App.t('startReview'); out.push(item); }
          else if (r.status === 'UNDER_REVIEW') { item.action = App.t('approve'); item.priority = 'High'; out.push(item); }
        }
      });
      App.State.findings.filter(function (f) { return f.status === 'OPEN'; }).forEach(function (f) {
        out.push({ objectType: 'Finding', objectId: f.id, org: 'Delta Industrial Group', site: '—', period: 'FY2025', status: f.status, owner: f.owner, assignee: f.owner, due: '2026-03-20', priority: f.severity === 'MAJOR' ? 'High' : 'Normal', blocking: f.severity === 'MAJOR' ? App.L('Blocks technical review gate', 'يحجب بوابة المراجعة الفنية') : '', action: App.L('Respond and close', 'استجب وأغلق'), title: f.text });
      });
      App.State.evidence.filter(function (e) { return e.reviewStatus === 'Pending'; }).slice(0, 4).forEach(function (e) {
        out.push({ objectType: 'Evidence', objectId: e.id, org: 'Delta Industrial Group', site: '—', period: 'FY2025', status: 'Pending review', owner: e.uploader, assignee: 'DATA_OWNER', due: '2026-03-15', priority: 'Normal', blocking: '', action: App.L('Review evidence', 'راجع الدليل'), title: e.fileName });
      });
      return out;
    }
  };

  function pct(a, b) { return b ? Math.round(a / b * 1000) / 10 : 0; }
})(window.App)