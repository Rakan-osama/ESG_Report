/* CR-10 · modules/state.js
   Single state container + persistence. IndexedDB is used for the working
   dataset; localStorage carries only lightweight preferences. Stored data is
   stamped with a schema version and migrated on load.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  var SCHEMA_VERSION = 3;
  /* v18.2 — hard tenant isolation (P0-4): every tenant persists in its own
     IndexedDB database. TEN-EEG is the labelled demo sandbox; client tenants
     are TEN-CLIENT-XXXX created at "Start empty". Nothing migrates between them. */
  var NS = (function () { try { return localStorage.getItem('cr10.tenant') || 'TEN-EEG'; } catch (e) { return 'TEN-EEG'; } })();
  var DB = 'cr10-esg-gri--' + NS, STORE = 'state', PREF = 'cr10.prefs--' + NS;

  var S = App.State = {
    schemaVersion: SCHEMA_VERSION,
    /* session */
    authed: false, authStep: 'login',
    lang: 'en',
    user: { id: 'USR-001', name: 'Ahmed Ali', email: 'ahmed.ali@energyup.example', initials: 'AA' },
    role: 'ESG_PROGRAMME_MANAGER',
    demoMode: true,
    /* navigation */
    mode: 'product',            // product | build
    view: 'journey',
    workspace: null, screen: null, module: null,
    tab: null, sub: null, step: null, screen66: null,
    filters: { status: 'all', site: 'all', period: 'all', q: '' },
    page: 1,
    /* working data (hydrated from demo, then persisted) */
    records: [], evidence: [], findings: [], impacts: [], materialTopics: [],
    omissions: [], calcRuns: [], gateResults: [], audit: [], notes: {},
    tasks: [], assignments: [], engagements: [],
    favourites: [], gri2: [], claim: null
  };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  App.clone = clone;

  /* ---------- persistence ---------- */
  var IDB_OK = (function () { try { return !!window.indexedDB; } catch (e) { return false; } })();

  function openDb() {
    return new Promise(function (res, rej) {
      if (!IDB_OK) return rej(new Error('no-idb'));
      var r = indexedDB.open(DB, 1);
      r.onupgradeneeded = function () { r.result.createObjectStore(STORE); };
      r.onsuccess = function () { res(r.result); };
      r.onerror = function () { rej(r.error); };
    });
  }
  function idbGet(k) {
    if (!IDB_OK) return Promise.resolve(null);
    return openDb().then(function (db) {
      return new Promise(function (res, rej) {
        var t = db.transaction(STORE, 'readonly').objectStore(STORE).get(k);
        t.onsuccess = function () { res(t.result); }; t.onerror = function () { rej(t.error); };
      });
    });
  }
  function idbSet(k, v) {
    if (!IDB_OK) return Promise.resolve(false);
    return openDb().then(function (db) {
      return new Promise(function (res, rej) {
        var t = db.transaction(STORE, 'readwrite').objectStore(STORE).put(v, k);
        t.onsuccess = function () { res(true); }; t.onerror = function () { rej(t.error); };
      });
    });
  }

  var PERSIST = ['records', 'evidence', 'findings', 'impacts', 'materialTopics',
    'omissions', 'calcRuns', 'gateResults', 'audit', 'favourites', 'gri2', 'claim', 'notes',
    'tasks', 'assignments', 'engagements'];

  App.save = function () {
    var payload = { schemaVersion: SCHEMA_VERSION, savedAt: new Date().toISOString() };
    PERSIST.forEach(function (k) { payload[k] = S[k]; });
    if (S.isClientTenant) {
      var dd = App.Data.demo;
      payload.tenantSetup = { organization: dd.organization, cycle: dd.cycle,
        legalEntities: dd.legalEntities, sites: dd.sites, tenantOwned: !!S.tenantOwned };
    }
    idbSet('working', payload).catch(function () { /* storage unavailable — session only */ });
    try {
      localStorage.setItem(PREF, JSON.stringify({ lang: S.lang, role: S.role, mode: S.mode, favourites: S.favourites }));
    } catch (e) { /* preferences unavailable */ }
  };

  /* migration: v1 stored one record per activity, v2 had no evidence versions */
  function migrate(p) {
    if (!p || !p.schemaVersion) return null;
    var d = clone(p);
    if (d.schemaVersion === 1) {
      d.records = (d.records || []).map(function (r) {
        r.siteId = r.siteId || 'SITE-01';
        r.periodLabel = r.periodLabel || '2025';
        r.version = r.version || 1;
        return r;
      });
      d.schemaVersion = 2;
    }
    if (d.schemaVersion === 2) {
      d.evidence = (d.evidence || []).map(function (e) {
        e.version = e.version || 1; e.status = e.status || 'ACTIVE'; return e;
      });
      d.schemaVersion = 3;
    }
    return d.schemaVersion === SCHEMA_VERSION ? d : null;
  }

  S.tenantNamespace = NS;
  S.isClientTenant = NS.indexOf('TEN-CLIENT-') === 0;

  App.hydrate = function () {
    var d = App.Data.demo;
    if (S.isClientTenant) {
      /* v18.2 (P0-3/P0-4): a client tenant NEVER seeds from the demo dataset.
         It boots with no organization, no cycle, no records, no evidence —
         the first action is Create Organization & Reporting Cycle. */
      d.organization = { id: 'ORG-PENDING', name_en: '', name_ar: '', sector: '', hq: '', country: '', employees: 0, contact: '', contactEmail: '', pending: true };
      d.cycle = { id: 'CYC-PENDING', label: '', periodStart: '', periodEnd: '', publicationTarget: '2100-12-31', publicationDate: '', gri1Version: 'GRI 1: Foundation 2021', sectorStandards: [], targetApproach: 'UNDECIDED', pending: true };
      d.legalEntities = []; d.sites = [];
      S.records = []; S.evidence = []; S.findings = []; S.impacts = [];
      S.materialTopics = []; S.omissions = []; S.calcRuns = []; S.gateResults = [];
      S.tasks = []; S.assignments = []; S.engagements = [];
      S.gri2 = clone(App.Data.registry.gri2);
      S.gri2.forEach(function (g) { g.status = 'MISSING'; g.evidence = 0; g.gap = 'Not started'; });
      S.claim = null; S.audit = []; S.tenantOwned = false;
      try {
        var pref0 = JSON.parse(localStorage.getItem(PREF) || '{}');
        if (pref0.lang) S.lang = pref0.lang;
        if (pref0.role) S.role = pref0.role;
      } catch (e) { }
      return idbGet('working').then(function (p) {
        var m = migrate(p);
        if (m) { PERSIST.forEach(function (k) { if (m[k] !== undefined) S[k] = m[k]; }); if (m.tenantSetup) { d.organization = m.tenantSetup.organization; d.cycle = m.tenantSetup.cycle; d.legalEntities = m.tenantSetup.legalEntities || []; d.sites = m.tenantSetup.sites || []; S.tenantOwned = !!m.tenantSetup.tenantOwned; } return 'restored'; }
        return 'seeded-empty';
      }).catch(function () { return 'seeded-empty'; });
    }
    /* demo sandbox (TEN-EEG): seed the labelled demonstration dataset */
    S.records = clone(d.records);
    S.evidence = clone(d.evidence);
    S.findings = clone(d.findings);
    S.impacts = clone(App.Data.registry.impacts);
    S.gri2 = clone(App.Data.registry.gri2);
    S.audit = [];

    try {
      var pref = JSON.parse(localStorage.getItem(PREF) || '{}');
      if (pref.lang) S.lang = pref.lang;
      if (pref.role) S.role = pref.role;
      if (pref.favourites) S.favourites = pref.favourites;
    } catch (e) { }

    return idbGet('working').then(function (p) {
      var m = migrate(p);
      if (m) { PERSIST.forEach(function (k) { if (m[k] !== undefined) S[k] = m[k]; }); return 'restored'; }
      return 'seeded';
    }).catch(function () { return 'seeded'; });
  };

  App.resetData = function () {
    return idbSet('working', null).catch(function () { }).then(function () {
      try { localStorage.removeItem(PREF); } catch (e) { }
      location.reload();
    });
  };

  /* v18.3 (P1-1) — collision-proof deterministic ids, never Math.random.
     The floor is the max numeric suffix across EVERY object collection
     (records, evidence, entities, sites, findings, impacts, topics, omissions,
     calc runs, engagements) AND a per-namespace persisted counter, so ids stay
     unique across page reloads and freshly hydrated sessions. */
  var SEQ_KEY = 'cr10.seq--' + NS;
  function seqLoad() { try { return JSON.parse(localStorage.getItem(SEQ_KEY) || '{}'); } catch (e) { return {}; } }
  function seqStore(m) { try { localStorage.setItem(SEQ_KEY, JSON.stringify(m)); } catch (e) { } }
  App.nextId = function (prefix) {
    var d = App.Data.demo || {};
    var pools = [S.records, S.evidence, S.findings, S.impacts, S.materialTopics,
      S.omissions, S.calcRuns, S.engagements, S.tasks, S.assignments,
      d.legalEntities || [], d.sites || []];
    var floor = 0, re = new RegExp('^' + prefix + '-(\\d+)');
    pools.forEach(function (pool) {
      (pool || []).forEach(function (x) {
        var m = re.exec(String(x && x.id || ''));
        if (m) { var v = parseInt(m[1], 10); if (v > floor) floor = v; }
      });
    });
    var persisted = seqLoad();
    if ((persisted[prefix] || 0) > floor) floor = persisted[prefix];
    var next = Math.max(floor + 1, 9001);
    persisted[prefix] = next; seqStore(persisted);
    return prefix + '-' + String(next);
  };

  /* Separation of duties is identity-based, not role-based. A demonstration
     that switched role while keeping one identity could never approve anything,
     so each simulated role carries its own identity. Every switch is logged. */
  App.setRole = function (code, opts) {
    opts = opts || {};
    var previous = S.role;
    var def = (App.Data && App.Data.roles || []).filter(function (r) { return r.code === code; })[0];
    var name = opts.name || (def ? def.en : code);
    S.role = code;
    S.user = {
      id: 'USR-' + code,
      name: name,
      email: code.toLowerCase().replace(/_/g, '.') + '@delta.example',
      initials: name.replace(/[^A-Za-z\u0600-\u06FF ]/g, '').split(/\s+/)
        .filter(Boolean).map(function (x) { return x.charAt(0); }).slice(0, 2).join('').toUpperCase() || 'EU'
    };
    return previous;
  };

  /* a role code rendered in the reader's language, wherever a role is named */
  App.roleLabelOf = function (code) {
    if (!code) return '—';
    var r = (App.Data && App.Data.roles || []).filter(function (x) { return x.code === code; })[0];
    return r ? App.L(r.en, r.ar) : code;
  };

  App.esc = App.esc || function (v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, function (m) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m];
    });
  };

  /* engine-level lookups the views used to own — a UI layer must not be required */
  App.siteName = function (id) {
    var s = ((App.Data && App.Data.demo && App.Data.demo.sites) || []).filter(function (x) { return x.id === id; })[0];
    return s ? App.L(s.name_en, s.name_ar) : (id || '—');
  };
  App.entityName = function (id) {
    var e = ((App.Data && App.Data.demo && App.Data.demo.legalEntities) || []).filter(function (x) { return x.id === id; })[0];
    return e ? App.L(e.name_en, e.name_ar) : (id || '—');
  };
  App.fmtNum = App.fmtNum || function (n) {
    return (typeof n === 'number' && isFinite(n)) ? n.toLocaleString('en-US') : String(n == null ? '' : n);
  };

  App.now = function () { return new Date().toISOString(); };
})(window.App)