/* CR-11 · modules/tenant.js
   The difference between a demonstration and a tool.

   Until now the organization, its entities, its sites, its cycle and its
   emission factors were fixed demonstration data. A user could look at the
   engines but could not put their own company in, could not legitimately
   calculate, and could not take anything out.

   This module owns three things:
     1. YOUR DATA      — create and edit the organization, entities, sites, cycle
     2. YOUR FACTORS   — approve an emission factor with the fields GRI and the
                         GHG Protocol require, so a calculation can run for real
     3. YOUR OUTPUT    — download the report, the content index, the assurance
                         pack and a full backup; restore from that backup

   Everything still passes through the same permission engine, the same audit
   trail and the same gates. Nothing here bypasses a control.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  /* ------------------------------------------------------------- 1. data -- */
  var T = App.Tenant = {

    isDemo: function () { return App.Data.demo.organization.id === 'ORG-DIG' && !App.State.tenantOwned; },

    /* replace the demonstration organization with the user's own */
    createOrganization: function (o) {
      if (!App.Permissions.guard('org.manage', null)) return { ok: false, code: 'DENIED' };
      var missing = ['name_en', 'sector', 'hq'].filter(function (k) { return !o[k]; });
      if (missing.length) return { ok: false, code: 'INCOMPLETE', message: App.L('Missing: ' + missing.join(', '), 'ناقص: ' + missing.join('، ')) };

      var d = App.Data.demo;
      d.organization = {
        id: o.id || App.nextId('ORG'),
        name_en: o.name_en, name_ar: o.name_ar || o.name_en,
        sector: o.sector, hq: o.hq, country: o.country || '',
        employees: Number(o.employees) || 0,
        contact: o.contact || '', contactEmail: o.contactEmail || '', pending: false
      };
      /* the user's own tenant starts empty — no borrowed rows */
      if (o.replaceData) {
        d.legalEntities = []; d.sites = [];
        App.State.records = []; App.State.evidence = []; App.State.impacts = [];
        App.State.materialTopics = []; App.State.omissions = []; App.State.calcRuns = [];
        App.State.findings = []; App.State.claim = null;
        (App.State.gri2 || []).forEach(function (g) { g.status = 'MISSING'; g.evidence = 0; });
      }
      App.State.tenantOwned = true;
      App.Audit.write({ action: 'create', objectType: 'organization', objectId: d.organization.id, newStatus: 'ACTIVE' });
      App.Gates._cache = null; App.save();
      return { ok: true, organization: d.organization };
    },

    addEntity: function (e) {
      if (!App.Permissions.guard('org.manage', null)) return { ok: false, code: 'DENIED' };
      if (!e.name_en) return { ok: false, code: 'INCOMPLETE', message: App.L('A legal name is required.', 'الاسم القانوني مطلوب.') };
      var rec = { id: e.id || App.nextId('LE'), name_en: e.name_en, name_ar: e.name_ar || e.name_en,
        country: e.country || '', consolidation: e.consolidation || 'Full', ownership: Number(e.ownership) || 100 };
      App.Data.demo.legalEntities.push(rec);
      App.Audit.write({ action: 'create', objectType: 'legal-entity', objectId: rec.id, newStatus: 'ACTIVE' });
      App.Gates._cache = null; App.save();
      return { ok: true, entity: rec };
    },

    addSite: function (s) {
      if (!App.Permissions.guard('org.manage', null)) return { ok: false, code: 'DENIED' };
      if (!s.name_en) return { ok: false, code: 'INCOMPLETE', message: App.L('A site name is required.', 'اسم الموقع مطلوب.') };
      if (!s.entity) return { ok: false, code: 'INCOMPLETE', message: App.L('Select the legal entity that controls this site.', 'اختر الكيان القانوني المسيطر على الموقع.') };
      var inB = s.inBoundary !== false;
      if (!inB && !s.exclusionRationale)
        return { ok: false, code: 'RATIONALE_REQUIRED', message: App.L('A site outside the boundary requires a recorded rationale.', 'الموقع خارج الحدود يتطلب مبررًا مسجلًا.') };
      var rec = { id: s.id || App.nextId('SITE'), name_en: s.name_en, name_ar: s.name_ar || s.name_en,
        entity: s.entity, type: s.type || 'Operational', country: s.country || '',
        inBoundary: inB, exclusionRationale: s.exclusionRationale || null };
      App.Data.demo.sites.push(rec);
      App.Audit.write({ action: 'create', objectType: 'site', objectId: rec.id, newStatus: 'ACTIVE' });
      App.Gates._cache = null; App.save();
      return { ok: true, site: rec };
    },

    setCycle: function (c) {
      if (!App.Permissions.guard('cycle.manage', null)) return { ok: false, code: 'DENIED' };
      var missing = ['label', 'periodStart', 'periodEnd'].filter(function (k) { return !c[k]; });
      if (missing.length) return { ok: false, code: 'INCOMPLETE', message: App.L('Missing: ' + missing.join(', '), 'ناقص: ' + missing.join('، ')) };
      if (c.periodEnd <= c.periodStart) return { ok: false, code: 'PERIOD_INVALID', message: App.L('The period end must fall after the period start.', 'نهاية الفترة يجب أن تلي بدايتها.') };
      var d = App.Data.demo;
      d.cycle = Object.assign({}, d.cycle, {
        id: c.id || d.cycle.id, label: c.label, periodStart: c.periodStart, periodEnd: c.periodEnd,
        gri1Version: c.gri1Version || 'GRI 1: Foundation 2021',
        sectorStandards: c.sectorStandards || [],
        targetApproach: c.targetApproach || 'IN_ACCORDANCE',
        publicationDate: c.publicationDate || '',
        publicationTarget: c.publicationTarget || c.publicationDate || c.periodEnd,
        pending: false
      });
      App.Audit.write({ action: 'edit', objectType: 'reporting-cycle', objectId: d.cycle.id, newStatus: 'OPEN' });
      App.Gates._cache = null; App.GRI.evaluateClaim(); App.save();
      return { ok: true, cycle: d.cycle };
    },

    approveBoundary: function (which, o) {
      if (!App.Permissions.guard('boundary.approve', null)) return { ok: false, code: 'DENIED' };
      var b = App.Data.demo.boundaries[which];
      if (!b) return { ok: false, code: 'NOT_FOUND' };
      if (!o.basis) return { ok: false, code: 'INCOMPLETE', message: App.L('State the basis on which the boundary is drawn.', 'اذكر الأساس الذي رُسمت عليه الحدود.') };
      b.basis = o.basis; b.approved = true;
      b.approvedOn = new Date().toISOString().slice(0, 10); b.approvedBy = App.State.user.id;
      App.Audit.write({ action: 'approve', objectType: 'boundary', objectId: which, newStatus: 'APPROVED' });
      App.Gates._cache = null; App.save();
      return { ok: true, boundary: b };
    },

    /* ---------------------------------------------------------- 2. factors -- */
    approveFactor: function (o) {
      if (!App.Permissions.guard('methodology.manage', null)) return { ok: false, code: 'DENIED',
        message: App.L('Only the methodology owner may approve an emission factor.', 'اعتماد عامل الانبعاث من صلاحية مالك المنهجية وحده.') };
      var required = ['factorId', 'value', 'unit', 'source', 'sourcePublication', 'geography', 'year', 'gwpSet'];
      var missing = required.filter(function (k) { return o[k] === undefined || o[k] === '' || o[k] === null; });
      if (missing.length) return { ok: false, code: 'FACTOR_INCOMPLETE',
        message: App.L('An emission factor cannot be approved without: ' + missing.join(', ') + '.',
                       'لا يمكن اعتماد عامل انبعاث بدون: ' + missing.join('، ') + '.'), missing: missing };
      if (!(Number(o.value) > 0)) return { ok: false, code: 'VALUE_INVALID', message: App.L('The factor value must be greater than zero.', 'قيمة العامل يجب أن تكون أكبر من صفر.') };

      var f = App.Data.factorSets.filter(function (x) { return x.factorId === o.factorId; })[0];
      if (!f) { f = { factorId: o.factorId }; App.Data.factorSets.push(f); }
      Object.assign(f, {
        value: Number(o.value), unit: o.unit, source: o.source, sourcePublication: o.sourcePublication,
        geography: o.geography, year: Number(o.year), gwpSet: o.gwpSet,
        effectiveFrom: o.effectiveFrom || App.Data.demo.cycle.periodStart,
        version: (Number(f.version) || 0) + 1,
        approval: 'APPROVED', approvedBy: App.State.user.id,
        approvedOn: new Date().toISOString().slice(0, 10),
        supersededBy: null, notes: o.notes || ''
      });
      App.Audit.write({ action: 'approve', objectType: 'emission-factor', objectId: f.factorId,
        previousStatus: 'DEMO_ONLY', newStatus: 'APPROVED', reason: o.source + ' ' + o.year });
      App.Gates._cache = null; App.save();
      return { ok: true, factor: f };
    },

    /* ---------------------------------------------------------- 3. output -- */
    download: function (name, mime, content) {
      try {
        var blob = new Blob([content], { type: mime + ';charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url; a.download = name; document.body.appendChild(a); a.click();
        setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 400);
        App.Audit.write({ action: 'export', objectType: 'file', objectId: name });
        return { ok: true, file: name };
      } catch (e) { return { ok: false, code: 'DOWNLOAD_FAILED', message: String(e && e.message || e) }; }
    },

    csv: function (rows) {
      return rows.map(function (r) {
        return r.map(function (c) {
          var v = c == null ? '' : String(c);
          return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
        }).join(',');
      }).join('\r\n');
    },

    /* the GRI content index as a spreadsheet-ready file */
    exportContentIndex: function () {
      var ci = App.GRI.contentIndex();
      var rows = [['GRI content index'], [ci.statementOfUse.text], ['GRI 1 used', ci.gri1],
        ['Sector standards', (ci.sectorStandards || []).join('; ') || 'none applicable'], [],
        ['Standard', 'Code', 'Disclosure', 'Location', 'Omission reason', 'Omission explanation',
         'Source records', 'Assurance', 'Status']];
      ci.rows.forEach(function (r) {
        rows.push([r.standard, r.code, r.title, r.location || '', r.omission || '', r.omissionExplanation || '',
          (r.sourceRecordIds || []).join('; '), r.assurance, r.status]);
      });
      if (ci.sectorNotMaterial.length) {
        rows.push([], ['Sector topics determined not material'], ['Standard', 'Ref', 'Topic', 'Rationale']);
        ci.sectorNotMaterial.forEach(function (x) { rows.push([x.standard, x.ref, x.topic, x.rationale]); });
      }
      return T.download('GRI-content-index-' + App.Data.demo.cycle.label.replace(/\s+/g, '-') + '.csv',
        'text/csv', '\ufeff' + T.csv(rows));
    },

    /* every approved record, for the accountant and the verifier */
    exportDataset: function () {
      var rows = [['Record ID', 'Version', 'Activity', 'Legal entity', 'Site', 'Period start', 'Period end',
        'Value', 'Unit', 'Measured/estimated', 'Estimation method', 'Assumptions', 'Uncertainty',
        'Data source', 'Evidence IDs', 'Status', 'Approved at']];
      App.State.records.filter(function (r) { return !r.frozen; }).forEach(function (r) {
        var a = App.Records.activity(r.activityId);
        rows.push([r.id, r.version, (a ? a.name_en : r.activityId), r.entityId, r.siteId, r.periodStart, r.periodEnd,
          r.rawValue, r.rawUnit, r.estimated ? 'Estimated' : 'Measured', r.estimationMethod || '',
          r.assumptions || '', r.uncertainty || '', r.dataSource || '', (r.evidenceIds || []).join('; '),
          r.status, r.approvedAt || '']);
      });
      return T.download('ESG-dataset-' + App.Data.demo.cycle.label.replace(/\s+/g, '-') + '.csv',
        'text/csv', '\ufeff' + T.csv(rows));
    },

    /* the report itself: a self-contained, print-ready document */
    exportReport: function () {
      var d = App.Data.demo, c = d.cycle, o = d.organization;
      var claim = App.State.claim || App.GRI.evaluateClaim();
      var ci = App.GRI.contentIndex();
      var mt = App.Materiality.approved();
      /* self-contained: this generator must not depend on a UI layer */
      var esc = App.esc || function (v) {
        return String(v == null ? '' : v).replace(/[&<>"']/g, function (m) {
          return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m];
        });
      };

      function section(title, body) { return '<section><h2>' + esc(title) + '</h2>' + body + '</section>'; }
      function table(head, rows) {
        return '<table><thead><tr>' + head.map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('') +
          '</tr></thead><tbody>' + rows.map(function (r) {
            return '<tr>' + r.map(function (c2) { return '<td>' + esc(c2 == null ? '' : c2) + '</td>'; }).join('') + '</tr>';
          }).join('') + '</tbody></table>';
      }

      var domains = {};
      App.State.calcRuns.forEach(function (r) {
        if (!r.reportable === false) { }
        if (r.sandbox) return;                       /* sandbox output never reaches a report */
        domains[r.domain] = domains[r.domain] || { total: 0, unit: r.outputUnit, n: 0 };
        domains[r.domain].total = Math.round((domains[r.domain].total + r.output) * 100) / 100;
        domains[r.domain].n++;
      });

      var html = '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">' +
        '<title>' + esc(o.name_en) + ' — Sustainability Report ' + esc(c.label) + '</title><style>' +
        'body{font:14px/1.6 Inter,"Segoe UI",Tahoma,Arial,sans-serif;color:#171b21;max-width:900px;margin:0 auto;padding:48px 32px}' +
        'h1{font-size:30px;margin:0 0 4px}h2{font-size:19px;margin:34px 0 10px;color:#236b66;border-bottom:2px solid #eaf6f4;padding-bottom:6px}' +
        'table{width:100%;border-collapse:collapse;margin:12px 0;font-size:12px}' +
        'th,td{border:1px solid #e5e8eb;padding:7px 9px;text-align:start;vertical-align:top}' +
        'th{background:#eaf6f4;color:#236b66;font-weight:600}' +
        '.cover{background:#2c817b;color:#fff;padding:40px;border-radius:12px;margin-bottom:28px}' +
        '.cover h1{color:#fff}.muted{color:#68717c;font-size:12px}' +
        '.claim{border:1px solid #2c817b;background:#eaf6f4;padding:14px 16px;border-radius:10px;margin:14px 0}' +
        '@media print{body{padding:0}section{break-inside:avoid}}' +
        '</style></head><body>' +
        '<div class="cover"><p style="opacity:.85;margin:0">' + esc(c.label) + '</p><h1>' + esc(o.name_en) + '</h1>' +
        '<p style="margin:6px 0 0">Sustainability Report · ' + esc(c.periodStart) + ' → ' + esc(c.periodEnd) + '</p></div>' +
        '<div class="claim"><b>Statement of use.</b> ' + esc(ci.statementOfUse.text) + '<br>' +
        '<span class="muted">Computed result: ' + esc(claim.result) + ' — ' + claim.passed + ' of 9 requirements satisfied. ' +
        'This statement is generated by the reporting engine and cannot be set by any user.</span></div>' +

        section('1. About this report', table(['Field', 'Value'], [
          ['Reporting organization', o.name_en], ['Sector', o.sector], ['Headquarters', o.hq],
          ['Employees', o.employees], ['Reporting period', c.periodStart + ' → ' + c.periodEnd],
          ['GRI 1 used', c.gri1Version], ['Sector standards', (c.sectorStandards || []).join('; ') || 'none applicable'],
          ['Contact', (o.contact || '') + ' ' + (o.contactEmail || '')]
        ])) +

        section('2. Reporting boundary', table(['Boundary', 'Basis', 'Approved'], [
          ['Reporting entities', d.boundaries.entities.basis, d.boundaries.entities.approvedOn || 'not approved'],
          ['Impact and value chain', (d.boundaries.impact.affectedStakeholders || []).join('; '), d.boundaries.impact.approved ? 'approved' : 'not approved'],
          ['GHG organizational', d.boundaries.ghg.approach, d.boundaries.ghg.approvedOn || 'not approved']
        ]) + table(['Entity / site', 'Type', 'Country', 'In boundary', 'Exclusion rationale'],
          d.legalEntities.map(function (e) { return [e.name_en, 'Legal entity', e.country, 'Yes', '']; })
            .concat(d.sites.map(function (s) { return [s.name_en, s.type, s.country, s.inBoundary ? 'Yes' : 'No', s.exclusionRationale || '']; })))) +

        section('3. Material topics', '<p>Material topics were determined from an impact-based process: context, ' +
          'stakeholder engagement evidence, impact identification, severity and likelihood assessment, ranking against ' +
          'an approved threshold model, and governance approval. Positive and negative impacts were never netted.</p>' +
          (mt.length ? table(['Topic', 'Impacts', 'Highest significance', 'Approved on'],
            mt.map(function (x) { return [x.topic, (x.impacts || []).length, x.maxSignificance || '', (x.approvedOn || '').slice(0, 10)]; }))
            : '<p><b>No material topic list has been approved.</b> This report cannot present material topics until governance approves the list.</p>')) +

        section('4. Performance', Object.keys(domains).length
          ? table(['Indicator domain', 'Reported value', 'Unit', 'Calculation runs'],
              Object.keys(domains).map(function (k) { return [k, domains[k].total, domains[k].unit, domains[k].n]; })) +
            '<p class="muted">Every figure is the sum of approved records for the period, calculated with an approved method ' +
            'and an approved emission factor. Each domain carries its own unit; nothing outside the GHG domain is expressed in tCO2e.</p>'
          : '<p><b>No reportable figure is available.</b> The calculation engine refuses to compute where no approved ' +
            'emission factor exists, so no performance figure may be presented.</p>') +

        section('5. GRI content index', table(['Standard', 'Code', 'Disclosure', 'Location', 'Omission', 'Status'],
          ci.rows.map(function (r) { return [r.standard, r.code, r.title, r.location || '—', r.omission || '—', r.status]; }))) +

        section('6. Basis of preparation', '<p>Data was collected against a controlled activity dictionary, validated ' +
          'against a rule catalogue, reviewed by a role independent of the preparer, and approved. Every approved value ' +
          'is bound to a version; editing an approved value freezes it and opens a new version for re-review. Evidence is ' +
          'linked at record level and retained on supersession. A complete audit trail is available on request.</p>' +
          table(['Control', 'Position'], [
            ['Records approved', App.Records.approved().length],
            ['Evidence objects', App.State.evidence.length],
            ['Calculation runs', App.State.calcRuns.length],
            ['Publication gates passed', App.Gates.summary().passed + ' of ' + App.Gates.summary().total],
            ['Open findings', App.State.findings.filter(function (f) { return f.status === 'OPEN'; }).length]
          ])) +

        '<p class="muted" style="margin-top:36px;border-top:1px solid #e5e8eb;padding-top:12px">' +
        'Generated ' + new Date().toISOString().slice(0, 10) + ' by the EnergyUp ESG &amp; GRI module. ' +
        'This document makes no claim of GRI certification, approval, rating or scoring — GRI does not certify reports. ' +
        'Where a figure is absent, the engine refused to compute it rather than present an unsupported number.</p>' +
        '</body></html>';

      return T.download('Sustainability-Report-' + c.label.replace(/\s+/g, '-') + '.html', 'text/html', html);
    },

    /* a full, restorable backup — the user's data is theirs */
    exportBackup: function () {
      var payload = {
        format: 'energyup-esg-backup', formatVersion: 1, appVersion: App.VERSION,
        exportedAt: new Date().toISOString(),
        organization: App.Data.demo.organization,
        legalEntities: App.Data.demo.legalEntities,
        sites: App.Data.demo.sites,
        cycle: App.Data.demo.cycle,
        boundaries: App.Data.demo.boundaries,
        factorSets: App.Data.factorSets,
        state: {}
      };
      ['records', 'evidence', 'impacts', 'materialTopics', 'omissions', 'calcRuns',
       'findings', 'gri2', 'claim', 'notes', 'audit'].forEach(function (k) {
        payload.state[k] = App.clone(App.State[k]);
      });
      return T.download('esg-backup-' + new Date().toISOString().slice(0, 10) + '.json',
        'application/json', JSON.stringify(payload, null, 2));
    },

    importBackup: function (text) {
      var p;
      try { p = JSON.parse(text); } catch (e) { return { ok: false, code: 'NOT_JSON', message: App.L('That file is not valid JSON.', 'هذا الملف ليس JSON صالحًا.') }; }
      if (p.format !== 'energyup-esg-backup') return { ok: false, code: 'WRONG_FORMAT', message: App.L('That is not an ESG backup file.', 'هذا ليس ملف نسخة احتياطية.') };
      App.Data.demo.organization = p.organization;
      App.Data.demo.legalEntities = p.legalEntities || [];
      App.Data.demo.sites = p.sites || [];
      App.Data.demo.cycle = p.cycle;
      if (p.boundaries) App.Data.demo.boundaries = p.boundaries;
      if (p.factorSets) App.Data.factorSets = p.factorSets;
      Object.keys(p.state || {}).forEach(function (k) { App.State[k] = p.state[k]; });
      App.State.tenantOwned = true;
      App.Gates._cache = null; App.GRI.evaluateClaim(); App.save();
      return { ok: true, organization: p.organization, exportedAt: p.exportedAt };
    }
  };
})(window.App)