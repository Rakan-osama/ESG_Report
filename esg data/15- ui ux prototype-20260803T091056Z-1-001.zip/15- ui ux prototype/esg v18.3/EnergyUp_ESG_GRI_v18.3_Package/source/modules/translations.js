/* CR-10 · modules/translations.js
   Bilingual dictionary. Each entry carries a review state so the product never
   presents an unreviewed string as approved terminology:
     hr  = human reviewed      mr = methodology reviewed
     ap  = approved terminology (both reviews passed)
   Strings without hr are rendered normally but reported as unreviewed in the
   Administration → Translation parity view.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';
  var T = {
    /* shell */
    app:            ['ESG & GRI Reporting', 'الإفصاح والاستدامة وفق GRI', 'ap'],
    home:           ['Home', 'الرئيسية', 'ap'],
    mywork:         ['My Work', 'مهامي', 'ap'],
    modules:        ['ESG Modules', 'وحدات الاستدامة', 'ap'],
    requests:       ['Requests', 'الطلبات', 'ap'],
    collection:     ['Data Collection', 'جمع البيانات', 'ap'],
    evidence:       ['Evidence', 'الأدلة', 'ap'],
    reviews:        ['Reviews', 'المراجعات', 'ap'],
    compliance:     ['GRI Compliance', 'امتثال GRI', 'ap'],
    reporting:      ['Reporting', 'التقرير', 'ap'],
    assurance:      ['Assurance', 'التأكيد', 'ap'],
    admin:          ['Administration', 'الإدارة', 'ap'],
    support:        ['Support', 'الدعم', 'ap'],
    settings:       ['Settings', 'الإعدادات', 'ap'],
    search:         ['Search records, evidence, disclosures…', 'ابحث في السجلات والأدلة والإفصاحات…', 'ap'],
    signout:        ['Sign out', 'تسجيل الخروج', 'ap'],

    /* auth */
    welcome:        ['Welcome Back!', 'مرحبًا بعودتك!', 'ap'],
    welcomeSub:     ['Welcome back! Please enter your details.', 'مرحبًا بعودتك! من فضلك أدخل بياناتك.', 'ap'],
    username:       ['Username', 'اسم المستخدم', 'ap'],
    enterName:      ['Enter your name', 'أدخل اسمك', 'ap'],
    role:           ['Role', 'الدور', 'ap'],
    selectRole:     ['Select Role', 'اختر الدور', 'ap'],
    password:       ['Password', 'كلمة المرور', 'ap'],
    remember:       ['Remember for 30 days', 'تذكرني لمدة 30 يومًا', 'ap'],
    forgot:         ['Forgot password', 'نسيت كلمة المرور', 'ap'],
    signin:         ['Sign in', 'تسجيل الدخول', 'ap'],
    orContinue:     ['Or continue with', 'أو تابع باستخدام', 'ap'],
    sso:            ['Sign In with SSO', 'الدخول عبر SSO', 'ap'],
    forgotTitle:    ['Forgot password?', 'نسيت كلمة المرور؟', 'ap'],
    forgotSub:      ['No worries, we\u2019ll send you reset instructions.', 'لا تقلق، سنرسل لك تعليمات إعادة التعيين.', 'ap'],
    email:          ['Email', 'البريد الإلكتروني', 'ap'],
    enterEmail:     ['Enter your email', 'أدخل بريدك الإلكتروني', 'ap'],
    resetPw:        ['Reset password', 'إعادة تعيين كلمة المرور', 'ap'],
    backLogin:      ['Back to log in', 'العودة لتسجيل الدخول', 'ap'],
    otpTitle:       ['Enter Verification Code', 'أدخل رمز التحقق', 'ap'],
    otpSub:         ['We sent a verification link to', 'أرسلنا رابط تحقق إلى', 'ap'],
    confirm:        ['Confirm', 'تأكيد', 'ap'],
    resend:         ['Didn\u2019t receive the email?', 'لم يصلك البريد؟', 'ap'],
    clickResend:    ['Click to resend', 'اضغط لإعادة الإرسال', 'ap'],
    setPw:          ['Set new password', 'تعيين كلمة مرور جديدة', 'ap'],
    setPwSub:       ['Your new password must be different to previously used passwords.', 'يجب أن تختلف كلمة المرور الجديدة عن السابقة.', 'ap'],
    confirmPw:      ['Confirm password', 'تأكيد كلمة المرور', 'ap'],
    pw8:            ['Must be at least 8 characters', 'يجب ألا تقل عن 8 أحرف', 'ap'],
    pwSpecial:      ['Must contain one special character', 'يجب أن تحتوي على رمز خاص', 'ap'],
    pwDone:         ['Password reset', 'تم تعيين كلمة المرور', 'ap'],
    pwDoneSub:      ['Your password has been successfully reset.', 'تم تعيين كلمة المرور بنجاح.', 'ap'],
    continue:       ['Continue', 'متابعة', 'ap'],

    /* generic */
    filters:        ['Filters', 'عوامل التصفية', 'ap'],
    exportW:        ['Export', 'تصدير', 'ap'],
    newItem:        ['New', 'جديد', 'ap'],
    open:           ['Open', 'فتح', 'ap'],
    view:           ['View', 'عرض', 'ap'],
    save:           ['Save', 'حفظ', 'ap'],
    cancel:         ['Cancel', 'إلغاء', 'ap'],
    close:          ['Close', 'إغلاق', 'ap'],
    all:            ['All', 'الكل', 'ap'],
    status:         ['Status', 'الحالة', 'ap'],
    site:           ['Site', 'الموقع', 'ap'],
    period:         ['Period', 'الفترة', 'ap'],
    owner:          ['Owner', 'المالك', 'ap'],
    value:          ['Value', 'القيمة', 'ap'],
    unit:           ['Unit', 'الوحدة', 'ap'],
    activity:       ['Activity', 'النشاط', 'ap'],
    version:        ['Version', 'الإصدار', 'ap'],
    reason:         ['Reason', 'السبب', 'ap'],
    required:       ['Required', 'مطلوب', 'ap'],
    prev:           ['Previous', 'السابق', 'ap'],
    next:           ['Next', 'التالي', 'ap'],
    noResults:      ['No results found', 'لا توجد نتائج', 'ap'],
    noResultsSub:   ['Adjust the filters or create a new record.', 'عدّل عوامل التصفية أو أنشئ سجلًا جديدًا.', 'ap'],
    demoData:       ['Demo data', 'بيانات تجريبية', 'ap'],
    simulated:      ['Simulated', 'محاكاة', 'ap'],
    journey:        ['My path', 'مساري', 'ap'],
    setup:          ['My organization', 'منظمتي', 'ap'],
    output:         ['Output', 'المخرجات', 'ap'],
    open:           ['Open', 'افتح', 'ap'],

    /* workflow statuses */
    DRAFT:          ['Draft', 'مسودة', 'ap'],
    VALIDATED:      ['Validated', 'تم التحقق', 'ap'],
    SUBMITTED:      ['Submitted', 'مُرسل', 'ap'],
    UNDER_REVIEW:   ['Under review', 'قيد المراجعة', 'ap'],
    RETURNED:       ['Returned', 'مُعاد', 'ap'],
    APPROVED:       ['Approved', 'معتمد', 'ap'],
    REOPENED:       ['Reopened', 'أُعيد فتحه', 'ap'],

    /* actions */
    validate:       ['Validate', 'تحقق', 'ap'],
    submit:         ['Submit', 'إرسال', 'ap'],
    startReview:    ['Start review', 'بدء المراجعة', 'ap'],
    approve:        ['Approve', 'اعتماد', 'ap'],
    returnRec:      ['Return', 'إعادة', 'ap'],
    reopen:         ['Reopen', 'إعادة فتح', 'ap'],
    addRecord:      ['New record', 'سجل جديد', 'ap'],

    /* dashboard */
    dashTitle:      ['ESG Reporting Dashboard', 'لوحة إعداد تقرير الاستدامة', 'ap'],
    welcomeBack:    ['Welcome back', 'مرحبًا بعودتك', 'ap'],
    cycleProgress:  ['Reporting cycle progress', 'تقدم دورة التقرير', 'ap'],
    dataCompleteness: ['Data completeness', 'اكتمال البيانات', 'ap'],
    evidenceCompleteness: ['Evidence completeness', 'اكتمال الأدلة', 'ap'],
    validationPass: ['Validation pass rate', 'نسبة اجتياز التحقق', 'ap'],
    materialTopics: ['Material topics', 'الموضوعات الجوهرية', 'ap'],
    gri2progress:   ['GRI 2 progress', 'تقدم GRI 2', 'ap'],
    openFindings:   ['Open findings', 'ملاحظات مفتوحة', 'ap'],
    overdue:        ['Overdue requests', 'طلبات متأخرة', 'ap'],
    gatesPassed:    ['Publication gates passed', 'بوابات النشر المجتازة', 'ap'],
    claimEligibility: ['Claim eligibility', 'أهلية الادعاء', 'ap'],
    assuranceStatus: ['Assurance status', 'حالة التأكيد', 'ap'],
    recentActivity: ['Recent activity', 'النشاط الأخير', 'ap'],
    deadlines:      ['Upcoming deadlines', 'المواعيد القادمة', 'ap'],
    phaseProgress:  ['Phase progress', 'تقدم المراحل', 'ap'],
    recordStatus:   ['Approved vs submitted vs returned', 'المعتمد مقابل المرسل والمعاد', 'ap'],

    /* claim */
    claimInAcc:     ['Eligible for reporting in accordance with the GRI Standards', 'مؤهل للإبلاغ وفقًا لمعايير GRI', 'ap'],
    claimRef:       ['Eligible for reporting with reference to the GRI Standards', 'مؤهل للإبلاغ بالرجوع إلى معايير GRI', 'ap'],
    claimNot:       ['Not eligible', 'غير مؤهل', 'ap'],
    claimBlocked:   ['Blocked', 'محجوب', 'ap'],
    claimComputed:  ['This claim is computed from the nine GRI requirements and cannot be set by any user.', 'يُحتسب هذا الادعاء من متطلبات GRI التسعة ولا يمكن لأي مستخدم تعيينه.', 'ap'],
    targetApproach: ['Target reporting approach', 'المسار المستهدف للتقرير', 'ap']
  };

  App.T = T;
  App.t = function (k) {
    var e = T[k]; if (!e) return k;
    return App.State.lang === 'ar' ? e[1] : e[0];
  };
  App.L = function (en, ar) { return App.State.lang === 'ar' ? ar : en; };
  App.parity = function () {
    var keys = Object.keys(T), ap = keys.filter(function (k) { return T[k][2] === 'ap'; }).length;
    return { total: keys.length, approved: ap, pct: Math.round(ap / keys.length * 1000) / 10 };
  };
})(window.App)