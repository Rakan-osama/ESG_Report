/* CR-10 · modules/units.js
   Controlled unit conversion. Conversion happens inside a family only. A
   cross-family request returns an error object — it is never silently
   multiplied. Every conversion returns its own trace.
   ========================================================================== */
window.App = window.App || {};
(function (App) {
  'use strict';

  var U = App.Units = {

    familyOf: function (u) { return App.Data.units.familyOf(u); },

    /* convert(120000,'kWh','MWh') → {ok:true, value:120, trace:[...]} */
    convert: function (value, from, to) {
      var fam = U.familyOf(from), famTo = U.familyOf(to);
      if (fam === null) return { ok: false, code: 'UNKNOWN_UNIT', message: 'Unit "' + from + '" is not in the unit registry.' };
      if (famTo === null) return { ok: false, code: 'UNKNOWN_UNIT', message: 'Unit "' + to + '" is not in the unit registry.' };
      if (fam !== famTo) return { ok: false, code: 'FAMILY_MISMATCH', message: 'Refused: "' + from + '" (' + fam + ') cannot be converted to "' + to + '" (' + famTo + ').' };
      var f = App.Data.units.families[fam].units;
      /* CR-10.1 · P0-09 — a currency conversion needs an approved, dated,
         versioned rate. None is registered, so it is refused rather than
         silently multiplied by a hard-coded number. */
      if (fam === 'currency' && from !== to) {
        var cnv = U.conversion(from, to);
        if (!cnv || cnv.approval !== 'APPROVED')
          return { ok: false, code: 'CONVERSION_NOT_APPROVED',
            message: 'CONVERSION BLOCKED — no approved, dated and versioned rate exists for ' + from + ' → ' + to + '.' };
      }
      var base = value * f[from];
      var out = base / f[to];
      var reg = U.conversion(from, to);
      return {
        ok: true, value: out, family: fam, conversionId: reg ? reg.id : null,
        conversionVersion: reg ? reg.version : null,
        trace: [
          { step: 'to base', expression: value + ' ' + from + ' × ' + f[from] + ' = ' + round(base) + ' ' + App.Data.units.families[fam].base },
          { step: 'to target', expression: round(base) + ' ÷ ' + f[to] + ' = ' + round(out) + ' ' + to }
        ]
      };
    },

    /* apply a factor whose unit is written as "<out>/<in>" */
    applyFactor: function (value, valueUnit, factor) {
      var parts = String(factor.unit).split('/');
      if (parts.length !== 2) return { ok: false, code: 'FACTOR_UNIT_MALFORMED', message: 'Factor unit "' + factor.unit + '" is not of the form output/input.' };
      var outUnit = parts[0], inUnit = parts[1];
      var conv = U.convert(value, valueUnit, inUnit);
      if (!conv.ok) return conv;
      var result = conv.value * factor.value;
      return {
        ok: true, value: result, unit: outUnit,
        trace: conv.trace.concat([{ step: 'factor', expression: round(conv.value) + ' ' + inUnit + ' × ' + factor.value + ' ' + factor.unit + ' = ' + round(result) + ' ' + outUnit + '  [factor ' + factor.factorId + ', ' + factor.geography + ' ' + factor.year + ']' }])
      };
    },

    /* look the conversion up in the controlled registry */
    conversion: function (from, to) {
      var list = App.Data.conversions || [];
      return list.filter(function (c) { return c.from === from && c.to === to; })[0] ||
             list.filter(function (c) { return c.from === to && c.to === from; })[0] || null;
    },
    family: function (u) { return App.Data.units.familyOf(u); },

    compatible: function (a, b) { return U.familyOf(a) !== null && U.familyOf(a) === U.familyOf(b); },
    listFamilies: function () { return Object.keys(App.Data.units.families); },
    unitsIn: function (fam) { return Object.keys(App.Data.units.families[fam].units); }
  };

  function round(n) { return Math.round(n * 10000) / 10000; }
})(window.App)