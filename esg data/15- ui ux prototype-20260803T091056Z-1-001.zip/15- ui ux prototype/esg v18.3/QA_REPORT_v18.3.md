# v18 QA Report (Node/jsdom)

- Date: 2026-08-03T07:32:54.031Z
- Total steps: 136
- Passed: 136
- Failed: 0
- QA_STATE_MUTATION_COUNT: **0**

> Environment note: no Chromium/Playwright is available in this build sandbox; the browser UI/screenshot suite is replaced by a jsdom harness executing the same domain assertions. Recorded in the Design Deviation Register.

## Boot, login & demo mode — PASS

| Step | Result | Detail |
|---|---|---|
| App engines loaded | ✅ |  |
| V41 base exposed | ✅ |  |
| V18 overlay loaded | ✅ |  |
| login overlay present | ✅ |  |
| mode chooser shown on first login | ✅ |  |
| demo mode stored | ✅ | demo |
| permanent demo banner visible | ✅ |  |
| banner offers Reset Demo Data | ✅ |  |
| banner rendered at TOP (body class v18-banner-top) | ✅ |  |
| banner collapsible to pill | ✅ |  |
| banner expandable again | ✅ |  |
| demo tenant namespace = TEN-EEG | ✅ | TEN-EEG |
| demo dataset labelled sandbox (isDemo) | ✅ |  |

## Domain end-to-end · run 1 (50 steps) — PASS

| Step | Result | Detail |
|---|---|---|
| record create | ✅ |  |
| evidence create | ✅ |  |
| evidence link | ✅ |  |
| record validate | ✅ |  |
| record submit | ✅ |  |
| SoD: contributor cannot approve own record | ✅ | NO_GRANT |
| start review | ✅ |  |
| return with reason | ✅ |  |
| return without reason rejected | ✅ | STATUS_INVALID |
| edit returned | ✅ |  |
| revalidate | ✅ |  |
| resubmit | ✅ |  |
| review after resubmit | ✅ |  |
| independent approval | ✅ |  |
| approved status | ✅ | APPROVED |
| duplicate draft detected | ✅ |  |
| identical full key blocked at validation gate | ✅ | VALIDATION_FAILED |
| meter A and meter B are distinct records | ✅ |  |
| meter A validates | ✅ |  |
| meter B validates (P0-2 fixed) | ✅ |  |
| normalized dimension detected as duplicate | ✅ |  |
| superseded record excluded from duplicate key | ✅ |  |
| different datapointId => distinct records (P1-2) | ✅ |  |
| same datapointId + short date (2025-10-1) normalized => duplicate detected | ✅ |  |
| identifier ids are case-exact (dp-b != DP-B by design) | ✅ |  |
| case-sensitive dimension definition honoured (abc != ABC) | ✅ |  |
| nextId never re-issues an existing entity id (P1-1) | ✅ | LE-9002 |
| nextId monotonic within session | ✅ | LE-9003 |
| demo factor blocked in product | ✅ | FACTOR_NOT_APPROVED |
| approved factor calculation | ✅ |  |
| calculation output unit | ✅ | tCO2e |
| calculation lineage | ✅ | trace |
| evidence supersede | ✅ |  |
| old evidence preserved | ✅ | SUPERSEDED |
| new evidence linked | ✅ |  |
| simulated hash classified | ✅ | SIMULATED_PROTOTYPE_DIGEST |
| browser SHA classified | ✅ | VERIFIED_BROWSER_SHA256 |
| human rights override | ✅ | true |
| prohibited omission blocked | ✅ | OMISSION_BLOCKED |
| nine GRI requirements | ✅ | 9 |
| claim computed read-only | ✅ | NOT_ELIGIBLE |
| content index generated | ✅ | 32 |
| fifteen gates | ✅ | 15 |
| failed gates actionable | ✅ | 0 |
| viewer read only | ✅ | READ_ONLY_ROLE |
| cross tenant blocked | ✅ | TENANT_ISOLATION |
| assurance cannot edit source | ✅ | SOD-04 |
| calculation self tests pass | ✅ | 0 |
| self test does not add audit | ✅ |  |
| self test does not add calc runs | ✅ |  |

## Domain end-to-end · run 2 (50 steps) — PASS

| Step | Result | Detail |
|---|---|---|
| record create | ✅ |  |
| evidence create | ✅ |  |
| evidence link | ✅ |  |
| record validate | ✅ |  |
| record submit | ✅ |  |
| SoD: contributor cannot approve own record | ✅ | NO_GRANT |
| start review | ✅ |  |
| return with reason | ✅ |  |
| return without reason rejected | ✅ | STATUS_INVALID |
| edit returned | ✅ |  |
| revalidate | ✅ |  |
| resubmit | ✅ |  |
| review after resubmit | ✅ |  |
| independent approval | ✅ |  |
| approved status | ✅ | APPROVED |
| duplicate draft detected | ✅ |  |
| identical full key blocked at validation gate | ✅ | VALIDATION_FAILED |
| meter A and meter B are distinct records | ✅ |  |
| meter A validates | ✅ |  |
| meter B validates (P0-2 fixed) | ✅ |  |
| normalized dimension detected as duplicate | ✅ |  |
| superseded record excluded from duplicate key | ✅ |  |
| different datapointId => distinct records (P1-2) | ✅ |  |
| same datapointId + short date (2025-10-1) normalized => duplicate detected | ✅ |  |
| identifier ids are case-exact (dp-b != DP-B by design) | ✅ |  |
| case-sensitive dimension definition honoured (abc != ABC) | ✅ |  |
| nextId never re-issues an existing entity id (P1-1) | ✅ | LE-9004 |
| nextId monotonic within session | ✅ | LE-9005 |
| demo factor blocked in product | ✅ | FACTOR_NOT_APPROVED |
| approved factor calculation | ✅ |  |
| calculation output unit | ✅ | tCO2e |
| calculation lineage | ✅ | trace |
| evidence supersede | ✅ |  |
| old evidence preserved | ✅ | SUPERSEDED |
| new evidence linked | ✅ |  |
| simulated hash classified | ✅ | SIMULATED_PROTOTYPE_DIGEST |
| browser SHA classified | ✅ | VERIFIED_BROWSER_SHA256 |
| human rights override | ✅ | true |
| prohibited omission blocked | ✅ | OMISSION_BLOCKED |
| nine GRI requirements | ✅ | 9 |
| claim computed read-only | ✅ | NOT_ELIGIBLE |
| content index generated | ✅ | 32 |
| fifteen gates | ✅ | 15 |
| failed gates actionable | ✅ | 0 |
| viewer read only | ✅ | READ_ONLY_ROLE |
| cross tenant blocked | ✅ | TENANT_ISOLATION |
| assurance cannot edit source | ✅ | SOD-04 |
| calculation self tests pass | ✅ | 0 |
| self test does not add audit | ✅ |  |
| self test does not add calc runs | ✅ |  |

## QA state isolation — PASS

| Step | Result | Detail |
|---|---|---|
| QA_STATE_MUTATION_COUNT = 0 across both runs | ✅ | 0 |

## Empty first-use · isolated client tenant — PASS

| Step | Result | Detail |
|---|---|---|
| client tenant namespace active | ✅ | TEN-CLIENT-QA01 |
| no organization (pending sentinel) | ✅ |  |
| no reporting cycle (pending sentinel) | ✅ |  |
| no records | ✅ | 0 |
| no evidence | ✅ |  |
| no impacts / topics / findings | ✅ |  |
| GRI 2 reset to MISSING | ✅ |  |
| claim guard: NOT_EVALUATED / PRECONDITION_ORG_CYCLE | ✅ | {"result":"NOT_EVALUATED","reason":"PRECONDITION_ORG_CYCLE"} |
| gates guard: not evaluated pre-setup | ✅ | 0 |
| content index guard pre-setup | ✅ | NOT_GENERATED |
| routed to organization setup (X-SETUP) | ✅ | X-SETUP |
| DOM contains zero demo text (Delta/FY2025/demonstration) | ✅ |  |
| data screens gated pre-setup (NO_ORGANIZATION card) | ✅ |  |
| gated screen leaks no demo text | ✅ |  |
| empty-workspace banner with tenant id | ✅ |  |
| cross-tenant object refused (TENANT_ISOLATION) | ✅ | TENANT_ISOLATION |
| create organization succeeds | ✅ |  |
| tenant owned after creation | ✅ |  |
| create reporting cycle succeeds | ✅ |  |
| claim evaluates for real after setup | ✅ | NOT_ELIGIBLE |
| fifteen gates evaluate after setup | ✅ | 15 |
| new records carry client tenant id | ✅ | TEN-CLIENT-QA01 |

